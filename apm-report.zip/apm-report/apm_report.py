#!/usr/bin/env python3
"""
apm_report.py - aggregate N Datadog APM trace CSV extracts into one report.

Reads any number of CSV extracts (files, globs, or directories), normalizes the
mixed-unit Duration column to milliseconds, and emits:

  * an .xlsx workbook with one tab per view
  * a self-contained .html dashboard (Plotly)

Usage
-----
    python apm_report.py -i "extracts/*.csv" -o ./out
    python apm_report.py -i extracts/ -o ./out --top 20 --tz America/New_York
    python apm_report.py -i a.csv b.csv -o ./out --dedupe --no-html

Run with --help for the full flag list.
"""

from __future__ import annotations

import argparse
import glob
import os
import re
import sys
import warnings
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore", category=FutureWarning)

# --------------------------------------------------------------------------
# Duration parsing
# --------------------------------------------------------------------------

# Everything is normalized to milliseconds.
UNIT_TO_MS = {
    "ns": 1e-6,
    "nsec": 1e-6,
    "us": 1e-3,
    "\u00b5s": 1e-3,   # micro sign
    "\u03bcs": 1e-3,   # greek mu
    "usec": 1e-3,
    "ms": 1.0,
    "msec": 1.0,
    "millis": 1.0,
    "s": 1000.0,
    "sec": 1000.0,
    "secs": 1000.0,
    "second": 1000.0,
    "seconds": 1000.0,
    "m": 60_000.0,
    "min": 60_000.0,
    "mins": 60_000.0,
    "minute": 60_000.0,
    "minutes": 60_000.0,
    "h": 3_600_000.0,
    "hr": 3_600_000.0,
    "hrs": 3_600_000.0,
    "hour": 3_600_000.0,
    "hours": 3_600_000.0,
    "d": 86_400_000.0,
    "day": 86_400_000.0,
    "days": 86_400_000.0,
}

_DUR_RE = re.compile(
    r"^\s*([0-9][0-9,_]*\.?[0-9]*(?:[eE][-+]?[0-9]+)?)\s*([A-Za-z\u00b5\u03bc]*)\s*$"
)


def parse_duration_series(s: pd.Series, bare_unit: str = "ms") -> tuple[pd.Series, pd.Series]:
    """Return (duration_ms float Series, boolean Series marking unparsed rows).

    Handles '10.01ms', '10.09s', '677.72 ms', '1,234us', bare numbers, and
    values already stored as numbers by Excel.
    """
    raw = s.astype("string")

    # Rows Excel already coerced to a number carry no unit - apply bare_unit.
    numeric_direct = pd.to_numeric(raw, errors="coerce")

    extracted = raw.str.extract(_DUR_RE)
    nums = pd.to_numeric(
        extracted[0].str.replace(",", "", regex=False).str.replace("_", "", regex=False),
        errors="coerce",
    )
    units = extracted[1].fillna("").str.lower().str.strip()

    # Blank unit means the value was bare -> caller-chosen default.
    units = units.mask(units == "", bare_unit.lower())
    factors = units.map(UNIT_TO_MS)

    out = nums * factors
    # Fall back to the direct numeric read where the regex path failed.
    out = out.fillna(numeric_direct * UNIT_TO_MS[bare_unit.lower()])

    unparsed = out.isna() & raw.notna() & (raw.str.strip() != "")
    return out.astype("float64"), unparsed


# --------------------------------------------------------------------------
# Column detection
# --------------------------------------------------------------------------

CANON = {
    "date": ["date", "timestamp", "time", "start", "start_time", "@timestamp"],
    "service": ["service", "service_name", "svc"],
    "resource": ["resource", "resource_name", "endpoint", "operation", "path"],
    "duration": ["duration", "latency", "elapsed", "response_time", "duration_ms"],
    "method": ["method", "http_method", "http.method", "verb"],
    "status": ["status code", "status_code", "status", "http.status_code",
               "http_status", "statuscode", "response_code"],
    "env": ["env", "environment"],
    "host": ["host", "hostname"],
    "trace_id": ["trace_id", "traceid", "trace id"],
}


def _norm(c: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", str(c).strip().lower()).strip("_")


def map_columns(cols) -> dict[str, str]:
    """Map canonical names -> actual column names present in the file."""
    norm_to_actual: dict[str, str] = {}
    for c in cols:
        norm_to_actual.setdefault(_norm(c), c)

    found: dict[str, str] = {}
    for canon, aliases in CANON.items():
        for alias in aliases:
            key = _norm(alias)
            if key in norm_to_actual:
                found[canon] = norm_to_actual[key]
                break
        if canon not in found:
            # loose contains-match as a fallback
            for nk, actual in norm_to_actual.items():
                if any(_norm(a) in nk for a in aliases):
                    found[canon] = actual
                    break
    return found


# --------------------------------------------------------------------------
# Loading
# --------------------------------------------------------------------------

@dataclass
class LoadReport:
    files: list[dict] = field(default_factory=list)
    unparsed_durations: int = 0
    duplicate_rows: int = 0
    missing_columns: set = field(default_factory=set)


def discover_files(inputs: list[str]) -> list[str]:
    out: list[str] = []
    for item in inputs:
        if os.path.isdir(item):
            out.extend(sorted(glob.glob(os.path.join(item, "**", "*.csv"), recursive=True)))
        elif any(ch in item for ch in "*?["):
            out.extend(sorted(glob.glob(item, recursive=True)))
        elif os.path.isfile(item):
            out.append(item)
        else:
            print(f"  ! no match for input: {item}", file=sys.stderr)
    # de-dupe while preserving order
    seen, uniq = set(), []
    for f in out:
        rp = os.path.realpath(f)
        if rp not in seen:
            seen.add(rp)
            uniq.append(f)
    return uniq


def load_all(paths: list[str], bare_unit: str, dedupe: bool, tz: str) -> tuple[pd.DataFrame, LoadReport]:
    rep = LoadReport()
    frames = []

    for p in paths:
        try:
            df = pd.read_csv(p, dtype=str, keep_default_na=False, na_values=[""],
                             engine="python", on_bad_lines="warn")
        except Exception as e:  # noqa: BLE001
            print(f"  ! skipping {p}: {e}", file=sys.stderr)
            continue

        if df.empty:
            print(f"  ! {os.path.basename(p)} has no rows", file=sys.stderr)
            continue

        cmap = map_columns(df.columns)
        missing = {k for k in ("date", "service", "duration") if k not in cmap}
        rep.missing_columns |= missing

        out = pd.DataFrame(index=df.index)
        out["service"] = df[cmap["service"]] if "service" in cmap else "(unknown)"
        out["resource"] = df[cmap["resource"]] if "resource" in cmap else "(none)"
        out["method"] = df[cmap["method"]] if "method" in cmap else "(none)"
        out["status_raw"] = df[cmap["status"]] if "status" in cmap else np.nan
        for opt in ("env", "host", "trace_id"):
            if opt in cmap:
                out[opt] = df[cmap[opt]]

        if "duration" in cmap:
            dur_ms, bad = parse_duration_series(df[cmap["duration"]], bare_unit)
            out["duration_ms"] = dur_ms
            out["duration_raw"] = df[cmap["duration"]]
            n_bad = int(bad.sum())
            rep.unparsed_durations += n_bad
        else:
            out["duration_ms"] = np.nan
            out["duration_raw"] = np.nan
            n_bad = 0

        if "date" in cmap:
            ts = pd.to_datetime(df[cmap["date"]], errors="coerce", utc=True, format="mixed")
        else:
            ts = pd.Series(pd.NaT, index=df.index, dtype="datetime64[ns, UTC]")
        out["ts_utc"] = ts

        out["source_file"] = os.path.basename(p)
        frames.append(out)

        rep.files.append({
            "File": os.path.basename(p),
            "Rows": len(out),
            "First Event": ts.min(),
            "Last Event": ts.max(),
            "Services": out["service"].nunique(),
            "Unparsed Durations": n_bad,
        })
        print(f"  + {os.path.basename(p):<48} {len(out):>8,} rows"
              + (f"  ({n_bad} unparsed durations)" if n_bad else ""))

    if not frames:
        raise SystemExit("No readable CSV files found.")

    data = pd.concat(frames, ignore_index=True)

    if dedupe:
        key = [c for c in ("trace_id", "ts_utc", "service", "resource", "method",
                           "duration_raw", "status_raw") if c in data.columns]
        before = len(data)
        data = data.drop_duplicates(subset=key, keep="first").reset_index(drop=True)
        rep.duplicate_rows = before - len(data)

    # status -> int + class
    status = pd.to_numeric(data["status_raw"], errors="coerce")
    data["status"] = status
    data["status_class"] = np.select(
        [status < 200, status < 300, status < 400, status < 500, status >= 500],
        ["1xx", "2xx", "3xx", "4xx", "5xx"],
        default="unknown",
    )
    data["is_error"] = status >= 400
    data["is_server_error"] = status >= 500

    # local-time buckets
    local = data["ts_utc"].dt.tz_convert(tz)
    data["ts_local"] = local
    data["date_local"] = local.dt.date
    data["hour_local"] = local.dt.floor("h")
    data["minute_local"] = local.dt.floor("min")

    data["service"] = data["service"].fillna("(unknown)")
    data["resource"] = data["resource"].fillna("(none)")
    data["method"] = data["method"].fillna("(none)")

    return data, rep


# --------------------------------------------------------------------------
# Aggregation
# --------------------------------------------------------------------------

def _pct(q):
    def f(x):
        return np.nanpercentile(x, q) if x.notna().any() else np.nan
    f.__name__ = f"p{q}"
    return f


def summarize(df: pd.DataFrame, keys: list[str]) -> pd.DataFrame:
    g = df.groupby(keys, dropna=False)
    out = g.agg(
        calls=("duration_ms", "size"),
        total_time_s=("duration_ms", lambda x: np.nansum(x) / 1000.0),
        mean_ms=("duration_ms", "mean"),
        p50_ms=("duration_ms", _pct(50)),
        p90_ms=("duration_ms", _pct(90)),
        p95_ms=("duration_ms", _pct(95)),
        p99_ms=("duration_ms", _pct(99)),
        max_ms=("duration_ms", "max"),
        errors=("is_error", "sum"),
        server_errors=("is_server_error", "sum"),
    ).reset_index()

    out["error_rate_pct"] = np.where(out["calls"] > 0, out["errors"] / out["calls"] * 100, 0.0)
    out["pct_of_total_time"] = np.where(
        out["total_time_s"].sum() > 0,
        out["total_time_s"] / out["total_time_s"].sum() * 100,
        0.0,
    )
    return out.sort_values("total_time_s", ascending=False).reset_index(drop=True)


def status_matrix(df: pd.DataFrame) -> pd.DataFrame:
    m = pd.crosstab(df["service"], df["status"].astype("Int64"), dropna=False)
    m.columns = [str(c) for c in m.columns]
    m.insert(0, "total", m.sum(axis=1))
    return m.sort_values("total", ascending=False).reset_index()


def build_views(df: pd.DataFrame, top: int) -> dict[str, pd.DataFrame]:
    views: dict[str, pd.DataFrame] = {}

    views["By Service"] = summarize(df, ["service"])
    views["By Service+Resource"] = summarize(df, ["service", "resource", "method"]).head(
        max(top * 20, 500)
    )
    views["By Method"] = summarize(df, ["method"])
    views["By Day"] = summarize(df, ["date_local"])
    views["By Service+Day"] = summarize(df, ["service", "date_local"])
    views["By Hour"] = summarize(df, ["hour_local"])
    views["Status by Service"] = status_matrix(df)

    errs = df[df["is_error"]]
    if len(errs):
        views["Errors Detail"] = summarize(errs, ["service", "resource", "method", "status"]).head(
            max(top * 20, 500)
        )

    slow = df.nlargest(min(1000, len(df)), "duration_ms")[
        ["ts_local", "service", "resource", "method", "duration_ms",
         "duration_raw", "status", "source_file"]
    ]
    views["Slowest Calls"] = slow.reset_index(drop=True)

    return views


# --------------------------------------------------------------------------
# Excel output
# --------------------------------------------------------------------------

NUM_FORMATS = {
    "calls": "#,##0",
    "total_time_s": "#,##0.0",
    "mean_ms": "#,##0.00",
    "p50_ms": "#,##0.00",
    "p90_ms": "#,##0.00",
    "p95_ms": "#,##0.00",
    "p99_ms": "#,##0.00",
    "max_ms": "#,##0.00",
    "duration_ms": "#,##0.00",
    "errors": "#,##0",
    "server_errors": "#,##0",
    "error_rate_pct": "0.00",
    "pct_of_total_time": "0.0",
}


def write_excel(views: dict[str, pd.DataFrame], rep: LoadReport, path: str, top: int) -> None:
    with pd.ExcelWriter(path, engine="xlsxwriter",
                        datetime_format="yyyy-mm-dd hh:mm:ss",
                        date_format="yyyy-mm-dd") as xw:
        wb = xw.book
        hdr = wb.add_format({"bold": True, "font_name": "Arial", "font_size": 10,
                             "bg_color": "#1F3864", "font_color": "white",
                             "align": "left", "valign": "vcenter", "border": 1})
        base = wb.add_format({"font_name": "Arial", "font_size": 10})

        # Summary tab first
        files_df = pd.DataFrame(rep.files)
        for c in ("First Event", "Last Event"):
            if c in files_df.columns:
                files_df[c] = pd.to_datetime(files_df[c], utc=True).dt.tz_localize(None)

        notes = pd.DataFrame({
            "Metric": ["Files loaded", "Total rows", "Durations that failed to parse",
                       "Duplicate rows removed", "Note"],
            "Value": [
                len(rep.files),
                sum(f["Rows"] for f in rep.files),
                rep.unparsed_durations,
                rep.duplicate_rows,
                "All *_ms columns are milliseconds; total_time_s is seconds. "
                "Durations parsed from mixed units (ms/s/us/ns) in the source.",
            ],
        })
        notes.to_excel(xw, sheet_name="Summary", index=False, startrow=0)
        files_df.to_excel(xw, sheet_name="Summary", index=False, startrow=len(notes) + 3)

        for name, df in views.items():
            sheet = name[:31]
            out = df.copy()
            for c in out.columns:
                if pd.api.types.is_datetime64_any_dtype(out[c]):
                    try:
                        out[c] = out[c].dt.tz_localize(None)
                    except (TypeError, AttributeError):
                        pass
            out.to_excel(xw, sheet_name=sheet, index=False)

        # formatting pass
        for sheet_name in xw.sheets:
            ws = xw.sheets[sheet_name]
            df = views.get(sheet_name)
            if df is None and sheet_name != "Summary":
                df = next((v for k, v in views.items() if k[:31] == sheet_name), None)

            ws.freeze_panes(1, 0)
            if df is not None:
                ws.autofilter(0, 0, len(df), max(len(df.columns) - 1, 0))
                for j, col in enumerate(df.columns):
                    q = df[col].astype(str).str.len().quantile(0.95) if len(df) else np.nan
                    q = 10 if pd.isna(q) else float(q)
                    width = max(len(str(col)) + 4, int(q) + 2)
                    fmt_str = NUM_FORMATS.get(col)
                    fmt = wb.add_format({"font_name": "Arial", "font_size": 10,
                                         "num_format": fmt_str}) if fmt_str else base
                    ws.set_column(j, j, min(width, 60), fmt)
                    ws.write(0, j, col, hdr)

                if "total_time_s" in df.columns:
                    k = df.columns.get_loc("total_time_s")
                    ws.conditional_format(1, k, len(df), k,
                                          {"type": "data_bar", "bar_color": "#5B9BD5"})
                if "error_rate_pct" in df.columns:
                    k = df.columns.get_loc("error_rate_pct")
                    ws.conditional_format(1, k, len(df), k,
                                          {"type": "3_color_scale",
                                           "min_color": "#FFFFFF",
                                           "mid_color": "#FFD966",
                                           "max_color": "#E06666"})

        # native chart on the service tab
        svc = views.get("By Service")
        if svc is not None and len(svc):
            ws = xw.sheets["By Service"]
            n = min(top, len(svc))
            chart = wb.add_chart({"type": "bar"})
            chart.add_series({
                "name": "Total time (s)",
                "categories": ["By Service", 1, 0, n, 0],
                "values": ["By Service", 1, svc.columns.get_loc("total_time_s"),
                           n, svc.columns.get_loc("total_time_s")],
                "fill": {"color": "#1F3864"},
            })
            chart.set_title({"name": f"Top {n} services by total time (s)"})
            chart.set_legend({"none": True})
            chart.set_size({"width": 720, "height": 28 * n + 80})
            ws.insert_chart(1, len(svc.columns) + 1, chart)


# --------------------------------------------------------------------------
# HTML dashboard
# --------------------------------------------------------------------------

def write_html(df: pd.DataFrame, views: dict[str, pd.DataFrame], path: str,
               top: int, embed_js: bool) -> None:
    import plotly.graph_objects as go
    import plotly.io as pio

    PALETTE = ["#1F3864", "#5B9BD5", "#E06666", "#F0A202", "#70AD47", "#7D4CDB"]
    figs: list[tuple[str, str, go.Figure]] = []

    svc = views["By Service"].head(top).iloc[::-1]

    # 1. total time + p95
    f = go.Figure()
    f.add_bar(y=svc["service"], x=svc["total_time_s"], orientation="h",
              name="Total time (s)", marker_color=PALETTE[0],
              hovertemplate="%{y}<br>%{x:,.1f} s total<extra></extra>")
    f.add_bar(y=svc["service"], x=svc["calls"], orientation="h",
              name="Calls", marker_color=PALETTE[1], visible="legendonly",
              hovertemplate="%{y}<br>%{x:,.0f} calls<extra></extra>")
    f.update_layout(title=f"Top {len(svc)} services by total time consumed",
                    xaxis_title="seconds (toggle 'Calls' in the legend)",
                    barmode="overlay", height=max(420, 26 * len(svc) + 160))
    figs.append(("total-time", "Where the time actually goes", f))

    # 2. volume vs p95 scatter
    sr = views["By Service+Resource"].head(400)
    f = go.Figure()
    f.add_scatter(
        x=sr["calls"], y=sr["p95_ms"], mode="markers",
        marker=dict(size=np.clip(np.sqrt(sr["total_time_s"].clip(lower=0.01)) * 3, 5, 45),
                    color=sr["error_rate_pct"], colorscale="OrRd", cmin=0,
                    cmax=max(sr["error_rate_pct"].max(), 1),
                    colorbar=dict(title="err %"), line=dict(width=0.5, color="#333")),
        text=sr["service"] + " — " + sr["resource"].astype(str).str.slice(0, 60),
        customdata=np.stack([sr["total_time_s"], sr["error_rate_pct"]], axis=-1),
        hovertemplate=("%{text}<br>%{x:,.0f} calls · p95 %{y:,.1f} ms"
                       "<br>%{customdata[0]:,.1f} s total · %{customdata[1]:.1f}% errors<extra></extra>"),
    )
    f.update_layout(title="Call volume vs p95 latency — the upper-right corner is the fix list",
                    xaxis=dict(title="calls", type="log"),
                    yaxis=dict(title="p95 latency (ms)", type="log"), height=560)
    figs.append(("scatter", "Volume against tail latency, per endpoint", f))

    # 3. latency distribution (ECDF, log x)
    f = go.Figure()
    for i, s in enumerate(views["By Service"].head(6)["service"]):
        d = df.loc[df["service"] == s, "duration_ms"].dropna()
        d = d[d > 0]
        if d.empty:
            continue
        d = np.sort(d.values)
        y = np.arange(1, len(d) + 1) / len(d) * 100
        if len(d) > 5000:
            idx = np.linspace(0, len(d) - 1, 5000).astype(int)
            d, y = d[idx], y[idx]
        f.add_scatter(x=d, y=y, mode="lines", name=str(s)[:40],
                      line=dict(color=PALETTE[i % len(PALETTE)], width=2),
                      hovertemplate="%{x:,.2f} ms<br>%{y:.1f}% of calls faster<extra></extra>")
    f.update_layout(title="Latency distribution by service (log scale)",
                    xaxis=dict(title="duration (ms)", type="log"),
                    yaxis=dict(title="% of calls at or below", range=[0, 100]), height=520)
    figs.append(("ecdf", "How latency is distributed, not just its average", f))

    # 4. volume over time by status class
    tb = "minute_local" if df["minute_local"].nunique() <= 3000 else "hour_local"
    vol = df.groupby([tb, "status_class"], dropna=False).size().reset_index(name="calls")
    f = go.Figure()
    colors = {"2xx": PALETTE[4], "3xx": PALETTE[1], "4xx": PALETTE[3],
              "5xx": PALETTE[2], "1xx": "#999999", "unknown": "#cccccc"}
    for cls in ["2xx", "3xx", "4xx", "5xx", "1xx", "unknown"]:
        part = vol[vol["status_class"] == cls]
        if part.empty:
            continue
        f.add_scatter(x=part[tb], y=part["calls"], mode="lines", stackgroup="one",
                      name=cls, line=dict(width=0.5, color=colors[cls]),
                      fillcolor=colors[cls])
    f.update_layout(title=f"Request volume over time by status class (per {tb.split('_')[0]})",
                    xaxis_title="", yaxis_title="calls", height=460)
    figs.append(("volume", "Traffic shape and where errors cluster", f))

    # 5. error-rate heatmap, service x hour
    hm = df.groupby(["service", "hour_local"])["is_error"].mean().mul(100).reset_index()
    keep = views["By Service"].head(top)["service"]
    hm = hm[hm["service"].isin(keep)]
    if len(hm):
        piv = hm.pivot(index="service", columns="hour_local", values="is_error").fillna(0)
        f = go.Figure(go.Heatmap(z=piv.values, x=piv.columns, y=piv.index,
                                 colorscale="OrRd", colorbar=dict(title="err %"),
                                 hovertemplate="%{y}<br>%{x}<br>%{z:.1f}% errors<extra></extra>"))
        f.update_layout(title="Error rate by service and hour",
                        height=max(360, 24 * len(piv) + 160))
        figs.append(("heatmap", "When each service degrades", f))

    # 6. per-day trend
    day = views["By Day"].sort_values("date_local")
    f = go.Figure()
    f.add_bar(x=day["date_local"], y=day["calls"], name="Calls", marker_color=PALETTE[1],
              hovertemplate="%{x}<br>%{y:,.0f} calls<extra></extra>")
    f.add_scatter(x=day["date_local"], y=day["p95_ms"], name="p95 (ms)", yaxis="y2",
                  mode="lines+markers", line=dict(color=PALETTE[2], width=2))
    f.update_layout(title="Daily volume and p95 latency",
                    yaxis=dict(title="calls"),
                    yaxis2=dict(title="p95 (ms)", overlaying="y", side="right"),
                    height=440)
    figs.append(("daily", "Day-over-day trend across all extracts", f))

    for _, _, fig in figs:
        fig.update_layout(template="plotly_white",
                          font=dict(family="Segoe UI, Arial, sans-serif", size=12),
                          margin=dict(l=70, r=40, t=70, b=50),
                          hoverlabel=dict(font_size=12))

    blocks = []
    for i, (anchor, subtitle, fig) in enumerate(figs):
        html = pio.to_html(fig, include_plotlyjs=(("True" if embed_js else "cdn") if i == 0 else False),
                           full_html=False, config={"displaylogo": False})
        if i == 0 and embed_js:
            html = pio.to_html(fig, include_plotlyjs=True, full_html=False,
                               config={"displaylogo": False})
        blocks.append(f'<section id="{anchor}"><p class="sub">{subtitle}</p>{html}</section>')

    total_rows = len(df)
    span = f"{df['ts_local'].min():%Y-%m-%d %H:%M} to {df['ts_local'].max():%Y-%m-%d %H:%M}"
    files_n = df["source_file"].nunique()

    stats = [
        ("Traces", f"{total_rows:,}"),
        ("Services", f"{df['service'].nunique():,}"),
        ("Files", f"{files_n}"),
        ("Total time", f"{df['duration_ms'].sum()/1000:,.0f} s"),
        ("p95", f"{np.nanpercentile(df['duration_ms'].dropna(), 95):,.1f} ms"),
        ("Error rate", f"{df['is_error'].mean()*100:.2f}%"),
    ]
    cards = "".join(f'<div class="card"><span class="k">{k}</span>'
                    f'<span class="v">{v}</span></div>' for k, v in stats)

    doc = f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>APM trace report</title>
<style>
  :root {{ --ink:#1a1f2b; --muted:#5c6678; --line:#e3e7ee; --accent:#1F3864; }}
  * {{ box-sizing:border-box; }}
  body {{ margin:0; background:#f6f8fb; color:var(--ink);
         font:14px/1.55 "Segoe UI",Arial,sans-serif; }}
  header {{ background:var(--accent); color:#fff; padding:28px 32px 24px; }}
  header h1 {{ margin:0 0 4px; font-size:22px; font-weight:600; letter-spacing:-.01em; }}
  header p {{ margin:0; opacity:.8; font-size:13px; }}
  .cards {{ display:flex; flex-wrap:wrap; gap:12px; padding:20px 32px 4px; }}
  .card {{ background:#fff; border:1px solid var(--line); border-radius:8px;
           padding:12px 18px; min-width:120px; }}
  .card .k {{ display:block; font-size:11px; text-transform:uppercase;
              letter-spacing:.06em; color:var(--muted); }}
  .card .v {{ display:block; font-size:20px; font-weight:600; margin-top:2px; }}
  section {{ background:#fff; border:1px solid var(--line); border-radius:10px;
             margin:20px 32px; padding:14px 18px 6px; }}
  .sub {{ margin:2px 4px 0; color:var(--muted); font-size:12.5px; }}
  footer {{ padding:8px 32px 40px; color:var(--muted); font-size:12px; }}
</style></head><body>
<header>
  <h1>APM trace report</h1>
  <p>{files_n} extract(s) · {total_rows:,} traces · {span}</p>
</header>
<div class="cards">{cards}</div>
{''.join(blocks)}
<footer>Durations normalized to milliseconds from mixed source units. Generated by apm_report.py.</footer>
</body></html>"""

    with open(path, "w", encoding="utf-8") as fh:
        fh.write(doc)


# --------------------------------------------------------------------------
# Console
# --------------------------------------------------------------------------

def print_console(views: dict[str, pd.DataFrame], top: int) -> None:
    svc = views["By Service"].head(top)
    cols = ["service", "calls", "total_time_s", "mean_ms", "p50_ms",
            "p95_ms", "p99_ms", "max_ms", "error_rate_pct"]
    view = svc[cols].copy()
    view.columns = ["service", "calls", "total(s)", "mean", "p50", "p95", "p99", "max", "err%"]
    print("\n" + "=" * 100)
    print(f"TOP {len(view)} SERVICES BY TOTAL TIME (latency in ms)")
    print("=" * 100)
    with pd.option_context("display.width", 200, "display.max_colwidth", 34,
                           "display.float_format", lambda v: f"{v:,.2f}"):
        print(view.to_string(index=False))


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        description="Aggregate N Datadog APM CSV extracts into an xlsx + html report.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    ap.add_argument("-i", "--input", nargs="+", required=True,
                    help="CSV files, glob patterns, or directories")
    ap.add_argument("-o", "--out", default="./apm_out", help="output directory")
    ap.add_argument("--top", type=int, default=15, help="rows/bars in top-N views")
    ap.add_argument("--tz", default="UTC", help="timezone for day/hour buckets, e.g. America/New_York")
    ap.add_argument("--bare-unit", default="ms", choices=sorted(UNIT_TO_MS),
                    help="unit to assume when a duration has no suffix")
    ap.add_argument("--dedupe", action="store_true",
                    help="drop rows duplicated across overlapping extracts")
    ap.add_argument("--service", help="only include services matching this regex")
    ap.add_argument("--since", help="drop events before this ISO timestamp")
    ap.add_argument("--until", help="drop events after this ISO timestamp")
    ap.add_argument("--no-html", action="store_true")
    ap.add_argument("--no-xlsx", action="store_true")
    ap.add_argument("--plotly-cdn", action="store_true",
                    help="link plotly.js from CDN instead of embedding (smaller file, needs internet)")
    ap.add_argument("--parquet", action="store_true",
                    help="also write the normalized rows as parquet for ad hoc querying")
    args = ap.parse_args(argv)

    paths = discover_files(args.input)
    if not paths:
        print("No CSV files matched the input.", file=sys.stderr)
        return 1

    print(f"Reading {len(paths)} file(s):")
    df, rep = load_all(paths, args.bare_unit, args.dedupe, args.tz)

    if args.service:
        df = df[df["service"].astype(str).str.contains(args.service, case=False, regex=True, na=False)]
    if args.since:
        df = df[df["ts_utc"] >= pd.Timestamp(args.since, tz="UTC")]
    if args.until:
        df = df[df["ts_utc"] <= pd.Timestamp(args.until, tz="UTC")]
    if df.empty:
        print("No rows left after filters.", file=sys.stderr)
        return 1

    os.makedirs(args.out, exist_ok=True)
    views = build_views(df, args.top)

    print(f"\nLoaded {len(df):,} traces · {df['service'].nunique()} services · "
          f"{df['resource'].nunique()} resources")
    if rep.duplicate_rows:
        print(f"Removed {rep.duplicate_rows:,} duplicate rows")
    if rep.unparsed_durations:
        print(f"WARNING: {rep.unparsed_durations:,} durations could not be parsed "
              f"(excluded from latency stats, still counted as calls)")
    if rep.missing_columns:
        print(f"WARNING: columns not found in some files: {sorted(rep.missing_columns)}")

    print_console(views, args.top)

    if not args.no_xlsx:
        xp = os.path.join(args.out, "apm_report.xlsx")
        write_excel(views, rep, xp, args.top)
        print(f"\nxlsx  -> {xp}")
    if not args.no_html:
        hp = os.path.join(args.out, "apm_report.html")
        write_html(df, views, hp, args.top, embed_js=not args.plotly_cdn)
        print(f"html  -> {hp}")
    if args.parquet:
        pp = os.path.join(args.out, "traces.parquet")
        try:
            df.to_parquet(pp, index=False)
            print(f"parquet -> {pp}")
        except ImportError:
            pp = os.path.join(args.out, "traces_normalized.csv")
            df.to_csv(pp, index=False)
            print(f"parquet engine missing (pip install pyarrow); wrote CSV instead -> {pp}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
