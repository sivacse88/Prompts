# APM Trace Report

Aggregates any number of Datadog APM trace CSV extracts into a single Excel workbook and a
self-contained HTML dashboard. Handles the mixed duration units (`10.01ms`, `10.09s`, `14.34us`)
that Datadog emits in a single column.

---

## Contents

| File | What it is |
|---|---|
| `apm_report.py` | The script. This is the only file you need. |
| `requirements.txt` | Pinned-minimum dependency list. |
| `samples/apm_report.xlsx` | Example output, generated from 18,684 synthetic rows across 3 days. |
| `samples/apm_report.html` | Example dashboard from the same run. Open it in a browser. |
| `README.md` | This file. |

The two files in `samples/` are **demo output only** — synthetic service names and latencies, not
your data. They exist so you can see the shape of the result before running anything. Delete them
once you've looked.

---

## 1. Install

Python 3.9 or newer. Check with `python --version`.

```bash
pip install pandas plotly xlsxwriter
```

Or from the included file:

```bash
pip install -r requirements.txt
```

If you are on a locked-down corporate machine and `pip` is blocked, see
[Corporate environment notes](#7-corporate-environment-notes) below.

To confirm the install worked:

```bash
python apm_report.py --help
```

---

## 2. Export your CSVs from Datadog

1. APM → Traces (Trace Explorer)
2. Set your query and time range. Keep each export to a single day if you can — it keeps
   file sizes manageable and makes the date obvious from the filename.
3. Add these columns to the table before exporting: **Date, Service, Resource, Duration,
   Method, Status Code**. Optionally also **Env, Host, Trace ID** — the script uses them if
   present and ignores them if not.
4. Export to CSV. Datadog names the file something like
   `extract-2026-09-11T00_43_34.443Z.csv`.
5. Drop all the CSVs into one folder.

Datadog caps CSV exports per request, so a busy day may need several exports. That's fine —
the script reads all of them and de-duplicates on request.

---

## 3. Run it

Point `-i` at a folder, a glob, or a list of files. All three work:

```bash
# everything in a folder (searches subfolders too)
python apm_report.py -i ./extracts -o ./out

# a glob
python apm_report.py -i "./extracts/*.csv" -o ./out

# specific files
python apm_report.py -i day1.csv day2.csv day3.csv -o ./out
```

A realistic invocation:

```bash
python apm_report.py -i ./extracts -o ./out --tz America/New_York --top 15 --dedupe
```

**Windows note:** quote the glob (`-i "C:\extracts\*.csv"`) or CMD will not expand it the way
you expect. Forward slashes work fine in paths on Windows too.

### What you get

Console prints the top-N services immediately. Then:

```
out/
├── apm_report.xlsx     the workbook
└── apm_report.html     the dashboard — double-click to open
```

---

## 4. Flags

| Flag | Default | What it does |
|---|---|---|
| `-i`, `--input` | *required* | Files, globs, or directories. Accepts multiple values. |
| `-o`, `--out` | `./apm_out` | Output directory. Created if missing. |
| `--top` | `15` | How many rows/bars appear in the top-N views. |
| `--tz` | `UTC` | Timezone for day and hour buckets, e.g. `America/New_York`. Raw timestamps stay UTC. |
| `--bare-unit` | `ms` | Unit to assume when a duration has no suffix. See warnings below. |
| `--dedupe` | off | Drop rows duplicated across overlapping extracts. |
| `--service` | — | Regex filter on service name, e.g. `--service "cgf-(web\|api)"`. |
| `--since` / `--until` | — | ISO timestamp bounds, e.g. `--since 2026-09-02T00:00:00Z`. |
| `--no-html` / `--no-xlsx` | off | Skip one output format. |
| `--plotly-cdn` | off | Link plotly.js from CDN instead of embedding it. Shrinks the HTML from ~4.5 MB to ~250 KB, but the file then needs internet to render. |
| `--parquet` | off | Also write the normalized rows for ad hoc SQL/pandas work. Falls back to CSV if `pyarrow` isn't installed. |

---

## 5. What's in the output

### Excel tabs

| Tab | Contents |
|---|---|
| **Summary** | Files loaded, row counts, date range per file, parse warnings. **Read this first.** |
| **By Service** | The headline view. Calls, total time, mean, p50/p90/p95/p99, max, errors, error rate. Includes a bar chart. |
| **By Service+Resource** | Same metrics at endpoint level. This is usually where the actionable finding is. |
| **By Method** | GET vs POST split. |
| **By Day** | Daily rollup across all extracts. |
| **By Service+Day** | Day-over-day per service — use this to spot a regression. |
| **By Hour** | Hourly buckets in your `--tz`. |
| **Status by Service** | Crosstab of every status code seen per service. |
| **Errors Detail** | 4xx/5xx only, broken out by service + resource + method + code. |
| **Slowest Calls** | The 1000 slowest individual traces, with the original duration string kept alongside the parsed value. |

Every tab has frozen headers and autofilter. `total_time_s` carries data bars; `error_rate_pct`
carries a white→amber→red scale.

**Column units:** anything ending `_ms` is milliseconds. `total_time_s` is seconds.

### HTML dashboard

Six charts, all interactive — hover for values, drag to zoom, click legend entries to toggle
series, and use the camera icon to save a PNG for a deck.

1. **Top services by total time.** Total time (calls × latency) is usually more actionable than
   either number alone. Toggle the "Calls" series in the legend to compare.
2. **Volume vs p95 scatter**, log-log, one dot per service+resource. Dot size is total time,
   color is error rate. The upper-right corner is your fix list.
3. **Latency distribution (ECDF)** on a log x-axis. Your data spans microseconds to minutes —
   on a linear axis everything collapses into the first bucket.
4. **Request volume over time**, stacked by status class.
5. **Error rate heatmap**, service × hour. Shows *when* something degrades.
6. **Daily volume with p95 overlay.**

---

## 6. Things to check on your first run

**The unparsed-duration count.** The script prints a warning and records the number on the
Summary tab. Anything it can't parse is still counted as a call but excluded from latency stats.
If that number isn't zero, look at the `Duration` column in your CSV and tell me the format —
the parser is a dict at the top of the script and is trivial to extend.

**Bare numbers.** If your export has durations with no unit suffix, the script assumes
milliseconds. If they're actually seconds or nanoseconds, pass `--bare-unit s` or
`--bare-unit ns`. Getting this wrong silently scales your averages by 1000x. Recognized units:
`ns us µs ms s sec min h d` and their plural/spelled-out forms.

**Whether to use `--dedupe`.** If your export windows overlap, the same trace appears in two
files and gets double-counted. `--dedupe` keys on trace ID + timestamp + service + resource +
method + duration + status. If your extracts are cleanly partitioned by day, leave it off.

**Timezone.** Buckets default to UTC. Datadog timestamps are UTC, but you probably think in
Eastern — pass `--tz America/New_York` so "the 2pm spike" means 2pm to you.

---

## 7. Corporate environment notes

**pip is blocked / behind a proxy.** Try your internal index:

```bash
pip install pandas plotly xlsxwriter --index-url https://<your-internal-pypi>/simple
```

**Can't install plotly at all.** The script still works — run with `--no-html` and you get the
full Excel workbook, including the native bar chart, with only `pandas` and `xlsxwriter`.

**HTML file size.** Default embeds plotly.js so the dashboard opens with no network access,
which matters if you're mailing it to someone. That's the 4.5 MB. If your mail gateway balks,
use `--plotly-cdn` for a ~250 KB file — but it renders blank without internet.

**Sharing.** The HTML is a single file with no external dependencies (in default mode). Attach
it, drop it in Teams, or put it on a share — it opens in any browser.

---

## 8. Troubleshooting

| Symptom | Fix |
|---|---|
| `No CSV files matched the input` | Check the path. Quote globs on Windows. Directories are searched recursively for `*.csv`. |
| `WARNING: columns not found` | Header names differ from what's expected. The script matches loosely (`Status Code`, `status_code`, `http.status_code` all work), but if yours is unusual, add it to the `CANON` dict near the top of the script. |
| All latencies look 1000x off | Wrong `--bare-unit`, or a unit suffix the parser doesn't know. Check the Summary tab. |
| Empty or near-empty charts | Timestamps failed to parse. Check the `Date` column format and look at First/Last Event on the Summary tab. |
| `MemoryError` on very large inputs | Run in chunks with `--since` / `--until`, or filter with `--service` first. |
| Excel says the file is corrupt | Usually an antivirus scanner mid-write. Re-run to a different `-o` folder. |

---

## 9. Extending it

The script is one file and deliberately linear:

- `UNIT_TO_MS` — add duration units here.
- `CANON` — add column-name aliases here.
- `summarize()` — add or change metrics; it's a single `groupby().agg()`.
- `build_views()` — add a tab. Anything returned in that dict becomes an Excel sheet.
- `write_html()` — add a chart. Append to the `figs` list.

To schedule it, wrap the invocation in a `.bat` or shell script and point it at a folder your
export drops into. The script is idempotent — it reads, it never modifies your CSVs.
