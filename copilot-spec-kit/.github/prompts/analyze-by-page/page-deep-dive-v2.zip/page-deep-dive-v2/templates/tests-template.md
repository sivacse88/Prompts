# Verification test suite — {{PAGE_TITLE}}

> Generated from `workbook.md` by P8. Run once against legacy (baseline),
> once against the new page. Parity: MUST-MATCH = identical; MAY-DIFFER =
> record only; MUST-FIX = legacy defect, new page must differ.

## Fixtures
See `test-data.md` (DS##).

## Summary
| Category | Count | Types covered |
|---|---|---|
| A Reaching the page | | |
| B Rendering per type | | |
| C Field population | | |
| D Business rules | | |
| E Behaviour rules | | |
| F Actions — happy path | | |
| G Actions — other exits | | |
| H Data integrity | | |
| I Cross-type isolation | | |
| J Leftover branch points | | |

## Tests

### TC-001 — <title>
category: A · types: ALL · priority: P2 · parity: MUST-MATCH
traces: <ids> · cite: path:line
fixture: DS01
preconditions: <plain language + technical state>
steps:
  1. …
expected:
  - UI: …
  - data: …
  - navigation: …
  - side effects: …
legacy result: ☐ PASS ☐ FAIL   notes:
new page result: ☐ PASS ☐ FAIL   notes:

(repeat)

## Coverage matrix
| Category | T1 | T2 | … | ALL | Total |
|---|---|---|---|---|---|

## Traceability
| Source id | Kind | Tests |
|---|---|---|

## Uncovered
| Id | Kind | Reason |
|---|---|---|

## Priority summary
P1 (data written / money moved): n · P2 (validation, rendering): n · P3 (formatting): n
