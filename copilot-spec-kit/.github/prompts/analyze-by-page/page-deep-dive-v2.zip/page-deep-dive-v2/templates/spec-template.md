# Page Specification — {{PAGE_TITLE}}

> Generated from `workbook.md` — every claim cites `path:line` or is marked
> UNKNOWN. Every item carries a `types:` tag. Do not edit by hand; re-run the
> pipeline instead.

## Gaps
(verification failures from P7, or "none")

## 1. Executive summary
~10 lines, business language: what the page is for, who uses it, which
contribution types it serves, what it can read and change in the system.

## 2. Contribution types
| Id | Value | Label | What it is (plain language) | Defined at | Entry notes |
|---|---|---|---|---|---|
Followed by the per-type business summaries (workbook 9G).
Discriminator: `<TYPE_FIELD>` — written by … (cited), read by … (cited).

## 3. Identity
| | |
|---|---|
| JSP | |
| Fragments included | |
| Tiles definition | |
| Prepare handler | |
| Process handler(s) | |
| Public URL(s) | |
| Legacy `.do` aliases | |
| Data-access profile | (JDBC / MyBatis / JPA / proc / Mongo / API — from 6a) |

## 4. How this page is reached
# | from | user trigger | mechanism (cited) | preconditions | data carried in | types.
End with the **direct-entry verdict** and the prepare-side per-type list.

## 5. Business rules catalogue
BR## | rule as a requirement | fields | types | enforced (client / server / both / BYPASSABLE) | source ids.
The product team signs this section off.

## 6. Applicability matrix
Rows = F-ids, columns = T-ids: ✓ editable · R read-only · H hidden · – absent
· ? unverified. Plus `required-by-type` and `classification`
(COMMON / TYPE-SPECIFIC / VARIANT).

---

# PART A — COMMON (applies to all contribution types)

## A.1 States (common)
name | condition (verbatim, cited) | meaning | visual change. Default state.

## A.2 Fields (common)
Per field, in this order:
- **F## — label** — `business:` meaning + `populated-when:` sentence
  (kind, control, binds-to, shown-in states, display condition plain + verbatim)
- `origin:` terminal source
- `chain:` numbered class#method list with citations
- `query:` fenced block, verbatim, with bind parameters and their sources
- `transforms:` · `options-origin:` (+query) · `submit-target:`
Hidden fields in their own subsection.

## A.3 Client-side rules (common)
Grouped by trigger. R## | fields | check (verbatim + plain) | message |
server twin or **BYPASSABLE**. Then behaviour, formatting, AJAX, navigation.

## A.4 Actions — common server logic
One subsection per A##: **business summary** | trigger | rules applied (BR ids)
| client gate | request | **numbered server steps** (each: business phrase +
class#method + citation) marked `[COMMON]` (with citations and write statements verbatim) |
outcome table | side effects. `[VARIANT]`/`[T#]` steps are referenced by
step number here and written out in Part B.

## A.5 Data sources (common)
table / collection / API | store | read/written | used by (F/A ids).

---

# PART B — PER CONTRIBUTION TYPE
(repeat the block below once per T-id)

## B.T# — {{TYPE_LABEL}}
### Entry & default state
### Fields — type-specific and variant
Full detail (origin, chain, query, transforms) for every TYPE-SPECIFIC field
and for the type's variant of every VARIANT field. Common fields: id list only.
### Rules — type-specific and variant
### Actions — type-specific and variant steps
Per A##: the `[T#]` steps and the type's side of each `[VARIANT]` step, with
citations and verbatim SQL; this type's outcome table.
### Data sources touched by this type
### Branch points justifying this section (B## ids)

---

## 7. Classification table
item id | kind | classification | types | justification (B## ids)

## 8. Notes for the rewrite
Shared component vs per-type slices; non-obvious behaviours to preserve
(sticky state, implicit filters, token guards, ordering, back-button
tolerance); BYPASSABLE client-only rules that must become server-side;
dead or unreferenced type branches.

## 9. Open questions
**For the product team:** every UNCLEAR business line and each BR to confirm.
**Technical:** everything UNKNOWN or UNVERIFIED, grouped by type, with what would resolve it.
