# P8 — Verification test cases for the page *(Opus, cap 0 source, fresh chat)*

Purpose: derive, from the finished workbook only, the complete set of test
cases that prove a **newly built version of this page behaves exactly like
the legacy page**. The suite is run twice — once against legacy to record the
baseline, once against the new page — and both result columns must match.

Placeholders: `<slug>` as used by P0–P7. Outputs go to `docs/page-specs/<slug>/`:
`tests.md` (readable suite), `tests.csv` (import into a test-management tool),
`test-data.md` (fixtures the suite depends on).

---

> Read ONLY `docs/page-specs/<slug>/workbook.md` (all sections, status must be
> P6 or DONE) and `templates/tests-template.md`. Do not open source. If the
> workbook lacks what a test needs, write the test anyway with the missing
> part as `UNKNOWN (workbook gap: <section>)` — a test with a gap is better
> than a missing test, because it tells the tester what to go and confirm.
>
> **Ground rules for every test case**
> - One observable behaviour per test. If a test would have two "expected"
>   sentences joined by "and also", split it.
> - Every test traces to workbook ids: the F/R/A/BR/B/T ids that justify it,
>   and at least one citation. A test with no traceability is a guess — delete
>   it.
> - Expected outcomes are written so a tester can mark PASS/FAIL without
>   interpretation: exact message text (resolved from the bundle), exact
>   field states (visible / hidden / read-only / value), exact destination
>   page, exact data written (table/collection, key columns, values).
> - Types are explicit: `types: ALL` or the T-ids. A behaviour that differs by
>   type gets one test per type, never one test with "depending on type".
> - Mark each test's **parity rule**: `MUST-MATCH` (new page must behave
>   identically), `MAY-DIFFER` (legacy behaviour is an artefact of the old
>   stack — page reloads, `.do` URLs, session-key names — record the legacy
>   result but do not fail the new page on it), or `MUST-FIX` (a legacy defect
>   the workbook flagged, e.g. a BYPASSABLE client-only rule: the new page
>   must enforce it server-side, so legacy and new are expected to differ).
>
> **Step 1 — Test data fixtures (`test-data.md`).**
> Derive from the origin chains and queries (workbook sections 4 and 6a)
> every distinct precondition the page can observe: an existing record in
> each state that changes rendering, a record per contribution type, empty
> vs populated lookups, boundary values for every validated field, the
> session/request state each inbound path requires, and each role. Name them
> `DS01, DS02…` with: description in plain language | the data condition in
> technical terms (table/column values, session attributes, request params —
> from the queries' bind parameters) | which tests use it. Do not invent
> columns that are not in the workbook.
>
> **Step 2 — Generate the suite (`tests.md`).** Work through the categories
> below in order, numbering `TC-001…`. For each category, walk the relevant
> workbook section row by row and ask "what would a tester have to do to
> prove this row is true, and what would they see if it were false?"
>
> **A. Reaching the page** — one test per inbound path (section 2): arrive
> via that path with its preconditions → page renders in the expected default
> state with the carried-in data shown. Plus: direct entry with the required
> session state absent (direct-entry verdict), wrong role, expired token.
>
> **B. Rendering per type** — for each T-id, one test that asserts the exact
> field set from the applicability matrix (section 9A): every ✓/R/H/– cell
> becomes an assertion line. Plus one test per state (section 3): trigger the
> state's condition → listed elements appear/disappear.
>
> **C. Field population** — one test per field with a traced origin
> (section 4): set up the fixture so the source has a known value → the
> field shows that value after the documented transforms (formatting,
> masking, defaulting). Include: empty source → documented default; each
> `type-variance` line → one test per type; select/radio option lists → the
> exact option set and order from `options-origin`. Hidden fields: assert
> presence and value in the rendered markup/request payload.
>
> **D. Business rules** — one test per BR (section 9F) per type it applies
> to, in three flavours where applicable: (1) boundary pass (smallest valid
> value), (2) boundary fail (just outside), (3) blank/absent. Expected
> outcome names the exact message and where it appears, whether submission
> is blocked, and which field keeps focus. For BYPASSABLE rules add a fourth
> test: submit the invalid value with client validation disabled → expected
> legacy result (the workbook says what the server does) with parity
> `MUST-FIX`.
>
> **E. Behaviour rules** — one test per show/hide/enable/recalculate rule
> (section 7): change the driver field → affected fields change as
> documented. Type-switch behaviour: change the type field on the page (if
> possible) → the field set becomes the target type's matrix column.
>
> **F. Actions, happy path** — one test per action (section 8) per type:
> valid input → expected request, expected persistence (each write
> statement's effect as a data assertion: row exists with these key values),
> expected destination, expected confirmation text, expected side effects
> (audit row, email, session cleared).
>
> **G. Actions, every other exit** — one test per row of each outcome table
> (section 8 step 5) that is not the happy path: validation failure (what
> is preserved on the form, what is not), business rejection, exception
> path, concurrent edit, double submit, browser back then resubmit.
>
> **H. Data integrity** — for each table/collection written: nothing is
> written when validation fails; the correct row is updated (not a new one)
> on edit; deletes remove only the targeted key; the type discriminator
> stored matches the type used.
>
> **I. Cross-type isolation** — for each pair of types where a field or
> rule is TYPE-SPECIFIC: prove it is absent/not enforced for the other type.
>
> **J. Sanity-check leftovers** — every branch point in section 0 not
> covered by a test above gets a test or an explicit `NOT-TESTABLE: <why>`.
>
> **Per test, use exactly this block** (from the template):
> ```
> ### TC-014 — <short title>
> category: D · types: T1 · priority: P1 · parity: MUST-MATCH
> traces: BR03, F07, R04, A01-step5 · cite: path:line
> fixture: DS02
> preconditions: <plain language + the technical state>
> steps:
>   1. …
>   2. …
> expected:
>   - UI: <exact visible result — message text, field states>
>   - data: <exact rows/values written or not written>
>   - navigation: <exact destination or "stays on page">
>   - side effects: <or "none">
> legacy result: ☐ PASS ☐ FAIL   notes:
> new page result: ☐ PASS ☐ FAIL   notes:
> ```
>
> **Step 3 — Coverage and traceability.** End `tests.md` with:
> - Coverage matrix: rows = categories A–J, columns = T-ids, cell = test
>   count, plus a total row.
> - Traceability index: every BR → TC ids; every A → TC ids; every F with an
>   origin → TC ids. Any BR, action, or origin-traced field with zero tests
>   is listed under `## Uncovered` with the reason.
> - Priority summary: P1 = data written or money moved; P2 = validation and
>   rendering; P3 = cosmetic/formatting.
>
> **Step 4 — `tests.csv`** with columns:
> `id,title,category,types,priority,parity,traces,fixture,preconditions,steps,expected_ui,expected_data,expected_navigation,side_effects,legacy_result,new_result,notes`
> — one row per test, steps and expectations joined with ` | `.
>
> **Verify before finishing**: every TC has a category, types, parity,
> ≥1 trace id, a fixture, and all four expected sub-lines (or "none");
> every type has tests in categories B, C, D, F; no test says "depending on"
> or "appropriate"; every BYPASSABLE rule has a MUST-FIX test. Update the
> workbook header `tests: <count>` and `status: P8`.
> Reply only: test count by category and type, uncovered list, count of
> tests containing UNKNOWN.

---

## Using the suite

1. Run against legacy first; fill the `legacy result` column. A FAIL there
   means the workbook is wrong — fix the workbook (re-run the producing
   prompt), regenerate the suite, do not "fix" the test.
2. Run against the new page; fill `new page result`. Compare: `MUST-MATCH`
   must be equal, `MUST-FIX` must be FAIL on legacy and PASS on new,
   `MAY-DIFFER` is recorded only.
3. Segregate by type for the modernization slices: filter `tests.csv` on
   `types` containing the slice's T-id or `ALL`; category B–J for that type
   is the slice's acceptance suite.
