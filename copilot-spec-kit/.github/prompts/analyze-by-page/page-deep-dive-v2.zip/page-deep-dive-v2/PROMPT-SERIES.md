# Page Deep-Dive v2 — prompt series (contribution-type aware)

Run in Copilot Chat **agent mode** (or Claude Code), one prompt per **fresh
chat**, in order. Fill the placeholders once and reuse them in every prompt:

| Placeholder | Meaning | Example |
|---|---|---|
| `<JSP>` | path of the page | `src/main/webapp/contrib/pgModify.jsp` |
| `<slug>` | kebab-case business name you choose | `modify-contribution` |
| `<TYPE_FIELD>` | where the page reads the contribution type (form-bean property, session attribute, or request parameter — give the exact name) | `contributionForm.contributionType` |
| `<TYPES>` | the contribution-type values you already know (leave blank to let P0 discover them) | `CASH, STOCK, MUTUAL_FUND, WIRE` |

All output goes to `docs/page-specs/<slug>/`. Never use `@workspace`; use
targeted search and explicit `#file:` attachments. If
`docs/encyclopedia/_raw/*.csv` exists, the prompts say how to use it.

## What changed from v1

1. **New P0** — contribution-type discovery. Finds every value of the type
   and every place the code branches on it *before* any field is analyzed.
2. **Every fact carries a `types:` tag** (fields, states, rules, action steps).
3. **P3 captures the complete query text**, not just `table.column`, and
   writes the call chain as a numbered class#method list.
4. **P5 splits each action's server logic into common steps and type-specific
   steps**, with an outcome table per type where behaviour differs.
5. **New P6** — consolidation into COMMON / TYPE-SPECIFIC / VARIANT, producing
   the applicability matrix.
6. **P7 compiles** `spec.md` + `page.html` as one document with a common
   section followed by one section per type, plus a type filter in the HTML.
7. **Dual audience.** Every item has a `business:` line in plain language;
   the HTML has a Product / Developer view toggle. Product view shows
   meanings, conditions in plain English, business rules and outcomes;
   Developer view adds citations, call chains, queries and step lists.

## Pipeline

| Prompt | Concern | Model | Cap (file opens) |
|---|---|---|---|
| P0 | Contribution-type discovery & branch index | **Opus** | 12 |
| P1 | Identity & entry map | Sonnet | 12 |
| P2 | States, fields, display conditions (type-tagged) | Sonnet / Opus if JSP >1,500 lines | 10 |
| P3 | Field lineage: call chain + full query text (2–3 runs) | **Opus** | 12 / run |
| P4 | Client-side rules (type-tagged) | Sonnet | 10 |
| P5 | Actions: client gate + server logic, common vs per-type | **Opus** | 12 |
| P6 | Consolidation: common / specific / variant + matrices | **Opus** | 0 source |
| P7 | Compile spec.md + page.html; verify | Sonnet | 0 source |
| P8 | Verification test suite (tests.md / tests.csv / test-data.md) — see `P8-TEST-CASES.md` | **Opus** | 0 source |

## Standing rules (apply to every prompt)

- **Evidence or UNKNOWN.** Every claim cites `path:line`. Never infer from
  naming. Unresolvable = `UNKNOWN — <why>`.
- **The workbook is the memory.** Read `docs/page-specs/<slug>/workbook.md`
  first; append your section; update `status:`. Never rewrite earlier sections.
- **Budgets are hard.** Searches are free; file opens are not. Out of budget →
  write what you have, add `INCOMPLETE: <what remains>`, stop.
- **Type tags are mandatory.** Every field, state, rule, action step and data
  source line ends with `types: ALL` or `types: T1,T3` (ids from section 0).
  If applicability could not be determined write `types: UNVERIFIED`. Never
  omit the tag.
- **Terminal origin required.** A service method is not an origin. Keep
  walking to `table.column`, `collection.field`, an API response field, a
  session attribute (plus its writer), a request parameter (plus its sender),
  a constant, or a `computed:` expression with inputs.
- **Two audiences, one workbook.** Every field, rule, action and outcome
  carries BOTH a technical record (citation, query, chain) AND a
  `business:` line — one or two plain sentences a product owner can read
  without knowing the code: what it means to the user, when it is
  populated/shown, and why. No class names, table names or file paths in a
  `business:` line; say "the donor's account number" not "ACCT.ACCT_NBR".
  If the business meaning is not evident from the code write
  `business: UNCLEAR — <what a product SME should confirm>`.
- **Reply in chat with a short completion report only.** Findings go to disk.

---

## P0 — Contribution-type discovery & branch index *(Opus, cap 12, fresh chat)*

> You are starting a deep-dive of one JSP page in a legacy Java web
> application (Spring Boot serving JSPs via Tiles, Struts-era idioms:
> prepare/process controller pairs, forward maps, `.do` URLs, token guards).
> The page serves several **contribution types**, and the analysis must later
> separate common behaviour from type-specific behaviour. Your job in this
> prompt is ONLY to establish the type dimension.
>
> Target JSP: `<JSP>`. Type discriminator as understood by the team:
> `<TYPE_FIELD>`. Known values: `<TYPES>` (may be incomplete or empty).
> Create `docs/page-specs/<slug>/workbook.md` with this header:
> ```
> # Workbook — <business page name>
> jsp: <JSP>
> slug: <slug>
> type-field: <TYPE_FIELD>
> sanitize: false
> status: P0
> ```
>
> **Step 1 — Confirm the discriminator.** Find where `<TYPE_FIELD>` is
> declared (form bean / session attribute / request param), where it is SET
> (search the setter, the `model.addAttribute`, `session.setAttribute`, hidden
> input, or URL parameter — cite each writer), and where the page's prepare
> controller READS it. If the code uses a different or additional
> discriminator (e.g. a second flag, a subtype, a product code that maps to a
> type), record it as `type-field-2:` in the header and treat both as the
> type key.
>
> **Step 2 — Enumerate the values.** Find the authoritative value list: an
> enum, a constants class, a properties file, a lookup table (`SELECT` from a
> reference/code table — record the query and cite the DAO), or a hardcoded
> list in the JSP/JS. Assign stable ids `T1, T2, …` in the order found.
> Reconcile with `<TYPES>`: values in the code but not in the list, and
> values in the list but not in the code, are both reported explicitly.
>
> **Step 3 — Branch index.** Search the entire repo (JSP + fragments + tag
> files, JS, controllers, services, validators/validation XML, DAO/mapper
> XML, SQL, properties/message bundles) for every place the type value is
> compared, switched on, used as a map key, used in an EL/JSTL condition,
> used in a JS condition, or interpolated into a query or message key. Use
> the enum/constant names AND the raw literal values in searches. Record one
> row per branch point: `B##` | file:line | layer (jsp/js/controller/
> service/validation/dao/sql/config) | branch expression verbatim | types it
> selects | one-line meaning. This index is what P2–P5 use to assign
> `types:` tags — be exhaustive within budget. Also record any place the type
> is *derived* (e.g. inferred from an amount, an account kind, or a
> predecessor page) as `derived-from:` rows.
>
> Append `## 0. Contribution types` with: (a) the type table
> `T## | value | label (resolve message key) | defined at (cite) | business:
> what this contribution type is, in one sentence (from labels, help text,
> comments, or UNCLEAR)`,
> (b) the discriminator write/read table, (c) the branch index, (d) a
> `Type-entry notes:` line — do all types enter the page the same way, or
> does the type get fixed before arrival (say where). Update `status: P0`.
> Reply only: type count with ids, discriminator write points, branch-point
> count by layer, and any INCOMPLETE markers.

---

## P1 — Identity & entry map *(Sonnet, cap 12, fresh chat)*

> Continue the deep-dive. Read `docs/page-specs/<slug>/workbook.md`
> (section 0 gives the type ids and discriminator). Now establish how the
> page is reached.
>
> **Step 1 — Render chain.** Search the active Tiles XML for the definition
> whose template/attribute references `<JSP>` (if the JSP is only a fragment,
> say so and list its consumer definitions). Find every controller/forward
> name resolving to that definition (search Java for the definition name and
> for `forwardTo("...")` values; open the forward-map to resolve). Find the
> public URL(s): `@RequestMapping`-family annotations AND any URL-rewrite
> rules mapping legacy `.do` paths. Record the full chain, each hop cited:
> `URL(s) → rewrite rule → controller#method (prepare) / (process) → forward
> name → Tiles definition → JSP + fragments`. With encyclopedia CSVs, use
> `_raw/tiles.csv`, `_raw/spring_mvc.csv`, `_raw/forwards.csv`.
>
> **Step 2 — Every inbound path.** Search the whole repo for: (1) links/
> redirects to its URLs or forward names (`href=`, `action=`, `sendRedirect`,
> `redirect:`); (2) JSP/taglib links; (3) JS navigation (`location.href`,
> `window.open`, `form.action=` + `submit()`, AJAX loads); (4) menu/nav
> config (XML, DB-driven, properties); (5) validation-failure and error
> routes that RETURN to it; (6) direct entry — what the prepare controller
> assumes is already in session, and whether a cold bookmark hit works;
> (7) other apps/emails (search properties/templates for its URL). With CSVs:
> `_raw/taglib_links.csv`, `_raw/js_nav.csv`.
> For every path record: from-where | user trigger | mechanism (cite) |
> preconditions (role, session state, flags) | parameters/data carried in |
> **`types:`** (which contribution types arrive via this path — use the
> section 0 discriminator writers and branch index; a predecessor page that
> only handles stock contributions is a `T2`-only path).
>
> **Step 3 — Prepare-side type handling.** Read the prepare controller
> method once and note, with citations, everything it does differently per
> type (attributes added, services called, defaults set). This is a preview
> for P3/P5; keep it to a bulleted list.
>
> Append `## 1. Identity & render chain`, `## 2. Inbound paths` (table + a
> `Direct-entry verdict:` line + the prepare-side type list). Update
> `status: P1`. Reply only: the render chain, inbound path count by type,
> and any INCOMPLETE markers.

---

## P2 — Content inventory: states, fields, display conditions
*(Sonnet; **Opus if the JSP exceeds 1,500 lines**; cap 10, fresh chat)*

> Continue the deep-dive. Read the workbook (sections 0–2). Open: the JSP,
> its included fragments/tag files, and the message bundle(s) its label keys
> come from. Nothing else. If the JSP is >1,500 lines, read it in passes —
> (a) includes/taglib header + top scriptlet block, (b) form and input
> markup, (c) conditional structure, (d) inline scripts — citing line ranges.
>
> **A. Page states.** Enumerate every visually/functionally distinct
> rendering (each with a `business:` sentence — "shown when the donor is
> editing an existing contribution"): JSTL `<c:if>/<c:choose>`, scriptlet `if/else` around markup,
> feature flags, mode attributes (create/edit/view), role checks,
> empty-vs-results, error rendering, **and every type branch from section 0
> that lives in this JSP (reference the B## id)**. For each state: name |
> EXACT condition expression (verbatim, cited) | plain-language meaning |
> what appears/disappears | `types:`. Record the DEFAULT state on first
> entry per type if it differs.
>
> **B. Field inventory.** Walk the markup top-to-bottom and register EVERY
> content element, ids F01, F02…:
> - inputs (text/select/radio/checkbox/textarea/file/date) with control
>   attributes (maxlength, readonly, disabled, pattern) and the
>   `name`/`path`/property they bind to;
> - hidden fields (they carry keys, tokens and the type itself — never skip);
> - display-only dynamic values (EL, `<bean:write>`-alikes, `out.print`,
>   formatted dates/amounts);
> - select/radio OPTION SOURCES (static in JSP? model attribute? lookup?);
> - grid/table components: column set, bindings, sort/page/export config;
> - static content: headings, instructional text, labels — resolve every
>   message-bundle key to its text; note hardcoded vs bundled; **note
>   labels or help text that vary by type (different key per type)**;
> - images/links whose target or visibility is dynamic.
> For each: id | label (resolved) | kind | control | binds-to | shown-in
> states (section A names) | field-level display condition (verbatim + plain
> language) | **`types:`** (derive from the enclosing state conditions and
> the branch index; a field inside no type branch is `ALL`) | **`required:`**
> (as far as the markup shows — asterisk, `required` attribute, or
> validator hint; P4/P5 finalise this per type) | **`business:`** (plain
> language: what the field means to the user and when they see it — draw on
> the resolved label, help text, tooltips, HTML comments; do not guess from
> variable names) | citation. Leave empty `origin:`, `query:`, `chain:`
> slots for P3.
>
> **C. Static structure.** Layout skeleton (Tiles slots/fragments rendering
> header/menu/body) plus anything in HTML comments revealing intent or dead
> markup.
>
> Append `## 3. States`, `## 4. Fields`, `## 5. Static structure`; update
> `status: P2`. Reply only: state count, field count, count of fields by
> `types:` value, and the 3 most complex display conditions.

---

## P3 — Field lineage: call chain + complete query
*(**Opus**, cap 12 per run, 2–3 runs for big pages, fresh chat each)*

> Continue the deep-dive. Read the workbook; section 4 lists fields with
> empty `origin:`/`query:`/`chain:` slots; section 1 gives the controller
> pair; section 0 the type branch index. Fill all three slots for every
> field, walking to the TERMINAL source.
>
> **Run 1 only — data-access profile.** Before tracing, spend up to 3 opens
> establishing how data access works in this app, because the query capture
> rule depends on it: (a) raw JDBC / `JdbcTemplate` with SQL strings in Java;
> (b) iBATIS/MyBatis mapper XML; (c) JPA/Hibernate (`@Query`, JPQL, derived
> `findBy…` methods, Criteria); (d) stored procedures / callable statements;
> (e) Mongo; (f) an external API. Record `## 6a. Data-access profile` with
> one line per mechanism found and the file pattern that identifies it. Later
> runs read this and skip the step.
>
> **Method.** Group fields by their backing model attribute (the prepare
> controller's `model.addAttribute`/form-bean population gives the grouping —
> one read serves many fields). Per group open, in order: prepare controller
> method → concrete service class (resolve interfaces through Spring wiring;
> never stop at an interface or an AOP proxy) → repository/DAO/mapper →
> entity/SQL. Record per field:
>
> - `origin:` terminal source — `TABLE.COL`, `collection.field`, API field
>   (name the integration point), session attribute (plus who writes it),
>   request parameter (plus which referring page sends it, using section 2),
>   constant/config (cite the properties file), or `computed: <formula>` with
>   the F-ids it depends on.
> - `chain:` a **numbered list, top-down, one line per hop**:
>   `1. Controller#prepare(...) path:line → 2. XService#loadY(...) path:line →
>   3. XServiceImpl#loadY path:line → 4. YDao#findZ path:line → 5. <query>`.
>   Include every class/method actually invoked, including mappers/converters
>   /formatters between DAO and screen, and note transactional or caching
>   annotations on the way.
> - `query:` the **complete query text, verbatim**, in a fenced block, with
>   citation. Rules by mechanism: JDBC/JdbcTemplate — the full SQL string as
>   assembled (if built dynamically, reproduce the assembly with each
>   conditional fragment and the condition that adds it); MyBatis/iBATIS — the
>   full mapped statement from the XML including `<if>/<choose>` fragments;
>   JPA `@Query`/JPQL — the JPQL verbatim PLUS the resolved SQL-equivalent
>   using the entity's `@Table`/`@Column` mapping (mark `resolved: medium-
>   confidence`); derived `findBy…` methods — the parsed predicate and the
>   SQL-equivalent (mark `derived`); Criteria/Specification — the predicates
>   and the SQL-equivalent; stored procedure — the procedure name, parameter
>   list, and the body if it is in the repo, else `body: UNKNOWN — not in
>   repo`; Mongo — the filter/projection document; API — endpoint, method,
>   request fields, response path to the field. Always list the bind
>   parameters and where each parameter value comes from (F-id, session
>   attribute, or constant).
> - `transforms:` formatting, masking, defaulting, concatenation, currency/
>   date formatting applied between origin and screen, each cited.
> - `options-origin:` (+ its own `query:`) for select/radio fields.
> - `submit-target:` for INPUT fields — form property → handler that consumes
>   it (write-side persistence is completed in P5).
> - `populated-when:` one plain sentence completing the field's `business:`
>   line with WHERE the value comes from and WHEN it is filled, in product
>   language ("pre-filled from the donor's profile; blank for a new donor;
>   recalculated after the amount changes"). Update the field's `business:`
>   line if P2's version was UNCLEAR and the trace made it clear.
> - `type-variance:` if any hop, query, parameter, default or transform
>   differs by contribution type (use the B## ids). Write one sub-line per
>   type that differs, or `none`. This is where "populated only for stock
>   contributions" or "different lookup query per type" gets captured.
>
> Budget 12 opens per run. When spent, mark remaining fields `origin:
> PENDING`, set `status: P3-partial`, reply with the count remaining — the
> next run continues from the PENDING list. When done set `status: P3`.
> Reply only: resolved / pending / UNKNOWN counts, distinct tables/
> collections/APIs touched, and the count of fields with `type-variance`.

---

## P4 — Client-side rules *(Sonnet, cap 10, fresh chat)*

> Continue the deep-dive. Read the workbook (sections 0, 3–4). Open: the
> JSP's inline `<script>` blocks (cite line ranges), every page-specific
> `.js` file it references, and shared JS files ONLY for the functions it
> calls. With CSVs, `_raw/js_nav.csv` locates navigation calls.
>
> Catalogue with ids R01, R02…, each tagged `types:` and each carrying a
> `business:` line stating the rule as a product requirement ("Amount must
> be at least $50 for cash contributions; the user is told immediately on
> leaving the field"):
> - **Validation rules**: verbatim condition + plain language, fields
>   (F-ids), EXACT trigger (onsubmit / onchange / onblur / keyup / load /
>   timer), user-visible message (resolve keys), and whether a server-side
>   twin exists (check validation config / controller / validator classes —
>   if client-only, flag `BYPASSABLE`). **Where the rule's condition or
>   message depends on the contribution type, record one row per type
>   variant** (e.g. minimum amount differs by type).
> - **Behaviour rules**: show/hide/enable/disable/recalculate — driver
>   fields → affected fields, event. Type-switch behaviour (changing the
>   type field re-renders sections) gets its own rows.
> - **Formatting/masks**: input restriction, auto-format, focus control.
> - **AJAX**: endpoint, trigger, params, DOM updated, error behaviour.
> - **Navigation JS**: confirms, popups (and opener/child exchange), double-
>   submit guards, back-button handling, unload warnings.
> - **Framework-generated JS**: emitted by taglibs/validator plugins — name
>   the config that generates it.
>
> Also produce **per-button client gates**: for every submit button/action
> link, the ordered list of R-ids that run before the request leaves the
> browser, per type.
>
> Order rules by trigger. Append `## 7. Client-side rules` (+ trigger-order
> table + per-button gate table); update `status: P4`. Reply only: rule
> count by category, BYPASSABLE list, and rules with per-type variants.

---

## P5 — Actions: server-side logic end to end, common vs per-type
*(**Opus**, cap 12, fresh chat)*

> Continue the deep-dive. Read the whole workbook. Enumerate every ACTION a
> user can take: submit buttons, action links, grid row click/sort/export,
> AJAX triggers, popup launchers (sections 4 and 7 list the triggers —
> consolidate, assign A01, A02…). For EACH action, citing every hop:
>
> 0. **Business summary** — 2–4 plain sentences: what the user is trying to
>    do, what must be true for it to succeed, what changes in the system
>    (in product terms: "records the contribution and reserves the shares"),
>    and what the user sees next.
> 1. **Trigger** — element (F-id), label, states where available, `types:`.
> 2. **Client gate** — the R-ids from section 7's per-button table.
> 3. **Request** — URL, method, parameters actually sent (hidden fields and
>    tokens included; note which parameter carries the type).
> 4. **Server handling — written as a numbered step list**, one line per
>    class#method with citation, top-down, **each step followed by a
>    `business:` phrase** ("checks the form was not submitted twice",
>    "validates the amount against the type minimum", "saves the
>    contribution record"): handler method → token/double-
>    submit check → binding/conversion → server-side validation (each rule
>    with its condition, message key, and failure destination) → business
>    rules → service sequence → DAO/mapper calls → **persistence effects**
>    (every table/collection written, insert/update/delete, key columns, the
>    **full write statement verbatim** by the same capture rules as P3) →
>    downstream calls. **Mark each step `[COMMON]` or `[T#]`** using the
>    branch index; where a step exists for all types but its content differs
>    (different validator, different SQL, different service impl chosen by a
>    factory/strategy map), write it once as `[VARIANT]` followed by one
>    sub-line per type.
> 5. **Outcomes** — EVERY exit: success (forward name → next page/state,
>    flash/session data carried), each validation failure (what the user sees,
>    what is preserved), business-rule rejections (messages), exceptions
>    (error page/mapping), concurrent-edit behaviour. Present as an outcome
>    table: condition (plain language) → condition (technical, cited) →
>    destination → user sees (resolved message text) → `types:`. If outcomes
>    differ by type, one table per type.
> 6. **Side effects** — session attributes written/cleared, audit records,
>    emails/notifications, downstream services, cache effects, `types:`.
>
> Open only: the process controller(s), the concrete services (and any
> strategy/factory that selects an implementation by type), validators, and
> the DAOs/mappers for the write paths (≤12; prefer files already cited).
> Append `## 8. Actions`; update `status: P5`. Reply only: the action list
> with one-line outcomes, the count of `[VARIANT]` steps, and any UNKNOWNs.

---

## P6 — Consolidation: common vs type-specific *(Opus, cap 0 source, fresh chat)*

> Finish the analysis layer. Read ONLY the workbook. Do not open source — a
> gap here is `UNKNOWN (workbook gap)`, never improvised.
>
> Build `## 9. Type consolidation` with:
>
> **A. Applicability matrix (fields).** One row per F-id, one column per
> T-id, cells `✓` (shown and editable), `R` (read-only/display), `H`
> (hidden field present), `–` (absent), `?` (UNVERIFIED). Extra columns:
> `required-by-type` (from R-rules and server validation) and `classification`.
>
> **B. Classification of every item** (fields, states, rules, action steps,
> data sources) into exactly one of:
> - `COMMON` — identical for all types;
> - `TYPE-SPECIFIC` — exists only for a subset of types (list them);
> - `VARIANT` — exists for all (or several) types but behaves differently
>   (different condition, query, default, message, service impl) — list the
>   variants by type.
> Justify each non-COMMON classification with the B## branch id(s).
>
> **C. Per-type profiles.** For each T-id: the fields it uses, its
> default/entry state, its rule set (common + its own), its action steps and
> outcomes, and the tables/queries it touches. Reference ids only; do not
> duplicate the workbook detail.
>
> **D. Common core.** The list of everything classified COMMON — this is the
> shared module in the modernization.
>
> **F. Business-rules catalogue.** Merge every `business:` line from rules
> (R##), server validation steps and business-rule rejections into ONE
> numbered list `BR01, BR02…` in product language, each with: the rule
> stated as a requirement | where it is enforced (client / server / both;
> BYPASSABLE flag if client-only) | fields involved (F-ids) | types |
> source ids (R##/A##-step). Deduplicate client/server twins into one BR.
> This list is what the product team reviews and signs off.
>
> **G. Per-type business summary.** For each T-id, 4–6 plain sentences: what
> this type of contribution is, what extra information the user must give,
> what extra rules apply, and how the outcome differs. Written for a product
> owner; no ids in the prose (ids go in a trailing "refs:" line).
>
> **E. Sanity checks.** Flag: branch points from section 0 that no field/
> rule/step references (possible dead branch or missed coverage); types with
> zero TYPE-SPECIFIC items (possible under-analysis); fields tagged
> UNVERIFIED.
>
> Update `status: P6`. Reply only: counts by classification, per-type
> field counts, and the sanity-check flags.

---

## P7 — Compile spec.md and page.html *(Sonnet, cap 0 source, fresh chat)*

> Read ONLY `docs/page-specs/<slug>/workbook.md`, `templates/spec-template.md`
> and `templates/page-spec-template.html` from the skill folder. Do not open
> source; gaps are `UNKNOWN (workbook gap)`.
>
> **1. `spec.md`** — follow the spec template: a 10-line business executive
> summary; identity; how the page is reached; then a **Common** part
> (common states, fields, rules, action logic, data sources) followed by
> **one part per contribution type** (its profile from section 9C, with the
> type-specific and variant items written out in full — fields with origin
> chain and complete query, rules, action steps with SQL, outcome tables).
> Keep every F/R/A/B/T id and every citation. Fenced query blocks are copied
> verbatim from the workbook. Include the applicability matrix and the
> classification table. End with rewrite notes, and open questions grouped
> by type.
>
> **2. `page.html`** — fill the HTML template: single self-contained file,
> no external resources, **two audiences**. The template has a view toggle
> (Product / Developer); everything technical — citations, `<code>` paths,
> call chains, queries, step lists, request parameters — goes inside
> elements with class `dev`, which the Product view hides. Everything with a
> `business:` line is rendered as visible plain text in BOTH views: the
> field's meaning and populated-when sentence, the state's meaning, each
> rule as a requirement, each action's business summary, plain-language
> outcome conditions, the per-type business summaries (section 9G) and the
> business-rules catalogue (9F) as its own section. Populate the overview,
> entry table, the **type
> filter bar** (one chip per T-id plus "All"), states, the fields table with
> `data-types` set on every row so the filter works, origin rendered as a
> breadcrumb `screen ← service ← DAO ← TABLE.COL` with the full query in a
> collapsible `<details>` under the row, client rules grouped by trigger,
> one collapsible panel per action whose server steps are a numbered list
> with `[COMMON]/[T#]/[VARIANT]` badges and per-type outcome tables, the
> applicability matrix, the data-sources summary, and the common-vs-specific
> section. Preserve the template's search and filter script.
> If `sanitize: true`, strip repo paths and class names from BOTH outputs,
> keeping ids and workbook section references.
>
> **3. Verify before finishing**: every field has origin+query+chain or
> UNKNOWN; every field, state, rule, action and BR has a non-empty
> `business:` line (or UNCLEAR) and none of them contains a path, class
> name, or table name; the Product view reads coherently on its own (skim it
> with all `.dev` elements hidden); every field, rule, step has a `types:` tag; every rule has a
> trigger; every action has ≥2 outcomes or a note why not; every T-id has a
> per-type section; every state referenced by a field exists; the matrix
> row count equals the field count. List failures under `## Gaps` at the
> top of spec.md. Update `status: DONE`.
> Reply only: files written, field/rule/action/BR counts, per-type counts,
> count of UNCLEAR business lines, gap list.

---

## Running order & practical notes

- 8 chats for a normal page; 9–10 for a monster JSP (extra P3 runs).
- P0 and P1 need only the JSP path and type field. Everything else reads the
  workbook first, so you can pause between prompts.
- Parallel pages never conflict — one folder per page. If several pages
  share the same type discriminator, copy section 0 of the first workbook
  into the next page's workbook and run P0 in "reconcile only" mode: ask it
  to verify the branch index for the new page rather than rediscover types.
- After P7, spot-check 5 citations AND 3 fenced queries against the source
  before circulating page.html. More than one wrong → re-run the producing
  prompt (the workbook section tells you which).
- Feed `spec.md` per-type sections directly into the modernization backlog:
  the Common part is the shared component; each type part is a slice.
- Review loop: send `page.html` in Product view to the product team first;
  every `UNCLEAR` business line and every BR is a question for them. Their
  answers go into the workbook as `[SME]`-tagged lines, then re-run P7.
