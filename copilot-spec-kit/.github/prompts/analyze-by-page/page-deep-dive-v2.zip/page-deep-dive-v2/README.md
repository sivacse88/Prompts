# page-deep-dive v2 — contribution-type aware

Deep-research analysis of ONE JSP page that serves several contribution
types. Output, per page, in `docs/page-specs/<slug>/`:

- `workbook.md` — evidence, built by P0–P6
- `spec.md` — markdown spec: Part A common, Part B one section per type
- `page.html` — self-contained reference page with a contribution-type
  filter, applicability matrix, call chains and verbatim queries

Prompts: `PROMPT-SERIES.md` (P0–P7). Templates: `templates/`.

## Before you start, fill in
- `<JSP>` and `<slug>`
- `<TYPE_FIELD>` — exact name of the form-bean / session / request field
  that carries the contribution type
- `<TYPES>` — known values (optional; P0 discovers and reconciles)

## What v2 adds over v1
| v1 | v2 |
|---|---|
| No type dimension | P0 builds a type table + branch index (B##); every item tagged `types:` |
| Origin = `table.column` | Origin + numbered class#method chain + complete query text, per data-access mechanism (JDBC/MyBatis/JPA/proc/Mongo/API), incl. bind-param sources |
| Server flow as prose | Numbered steps marked `[COMMON]/[T#]/[VARIANT]`, write statements verbatim |
| Single spec | P6 consolidation: applicability matrix, COMMON / TYPE-SPECIFIC / VARIANT classification, per-type profiles |
| Static HTML | Type filter chips, matrix, collapsible query panels, common-vs-specific section |
| Developer-only | Product / Developer view toggle; every item has a plain-language `business:` line; business-rules catalogue (BR##) for product sign-off |

## Model guidance
Opus for P0, P3, P5, P6 (judgement: branch discovery, lineage across
proxies/dynamic SQL, per-type action logic, classification). Sonnet elsewhere.
