---
name: parity-check
description: Compare a legacy JSP page (already analyzed with the page-deep-dive skill) against its modernized Angular page and Spring Boot APIs. Extracts the Angular page's fields, validations, and API calls; traces each API to its underlying tables; then produces a field-by-field, rule-by-rule, data-origin parity report highlighting what is missing, added, changed, or served from different data. Use when asked to compare legacy vs modernized pages, verify migration parity, or find gaps between old and new implementations.
---

# Parity Check

## Purpose

Answer four questions with evidence, for one page:

1. What did the modernized page accomplish (fields, rules, actions)?
2. What exists in legacy but is missing or weakened in the new stack?
3. What was added or changed in the new stack?
4. Is any field served from / written to **different underlying data** than
   legacy? (the highest-risk difference — always highlighted)

## Inputs

- Legacy artifacts from `page-deep-dive`: `docs/page-specs/<slug>/workbook.md`
  and `spec.md` (must exist — run that skill first).
- The Angular repo (page identified by route or component).
- The Spring Boot backend repo(s) serving the APIs the page calls.

## Outputs (all in `docs/page-specs/<slug>/parity/`)

- `angular-workbook.md` — evidence from the Angular repo (C1)
- `api-workbook.md` — evidence from the backend repo(s) (C2)
- `comparison.md` — the matched matrices and classifications (C3)
- `parity-report.md` + `parity.html` — the deliverables (C4)

## Operating rules

1. **Workbooks are the memory; comparison never opens source.** C1 and C2
   gather evidence with hard file budgets. C3 works from the three workbooks
   only. C4 renders. Fresh chat per prompt.
2. **Match by meaning, not by name.** Field names differ across stacks. The
   matching key is the legacy F-id, matched via label/business meaning first,
   binding names second. Any uncertain match is `AMBIGUOUS — needs human
   confirmation`, never silently paired.
3. **Classifications are fixed vocabulary**: `MATCH`, `CHANGED(<what>)`,
   `MISSING-IN-NEW`, `ADDED-IN-NEW`, `MOVED(<from→to layer>)`,
   `WEAKENED`/`STRENGTHENED` (constraint deltas), `DATA-DIFF` (different
   table/column/store or transformation). `DATA-DIFF` always goes in the
   report's top risk section.
4. **Every claim cites** `path:line` (its own repo). UNKNOWN over guess.
5. **Workspace**: open a VS Code multi-root workspace containing the legacy
   docs folder, the Angular repo, and the backend repo(s) so every prompt can
   read the artifacts it needs. If repos can't share a workspace, copy the
   needed workbooks into the repo you're prompting in.
6. Identity/sanitization rules follow the page-deep-dive skill (prose clean;
   `sanitize: true` supported in C4).

## Pipeline

| Prompt | Does | Model | Cap |
|---|---|---|---|
| C1 | Angular page extraction: route, fields, validators, rules, API calls | Sonnet (Opus if the component tree is deep/NgRx-heavy) | 12 |
| C2 | API trace: each endpoint → validations → services → tables/columns (batches of ≤3 endpoints) | **Opus** | 12/run |
| C3 | Matching + parity classification | **Opus** | 0 source |
| C4 | Report + HTML rendering + verification | Sonnet | 0 source |

Full prompts: `PROMPT-SERIES.md`. Templates: `templates/`.
