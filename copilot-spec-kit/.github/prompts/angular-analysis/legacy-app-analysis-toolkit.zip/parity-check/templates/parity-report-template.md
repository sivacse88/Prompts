# Parity Report — {{PAGE_TITLE}}

Legacy: `{{LEGACY_JSP}}` · Modernized: `{{ANGULAR_ROUTE}}` · Generated {{DATE}}
Sources: legacy workbook, angular-workbook, api-workbook (all cited per row).

## Gaps
(C4 verification failures, or "none")

## 1. Verdict
| Classification | Count |
|---|---|
| MATCH | |
| CHANGED | |
| MISSING-IN-NEW | |
| ADDED-IN-NEW | |
| MOVED | |
| WEAKENED / STRENGTHENED | |
| DATA-DIFF | |
| BYPASSABLE-REGRESSION | |
| AMBIGUOUS (needs human) | |

**Accomplished:** 3–6 lines: what the modernization fully covers.

## 2. P1 risks (act before go-live)
Every DATA-DIFF, BYPASSABLE-REGRESSION, MISSING-IN-NEW hidden/key field, and
missing outcome — one row each: item | legacy behaviour | new behaviour |
consequence if shipped | suggested fix.

## 3. Field parity matrix
One row per legacy field + one per ADDED-IN-NEW: F-id | N-id | label |
classification | legacy (control, condition, origin) | new (control,
condition, API field, origin) | notes. AMBIGUOUS rows state the question.

## 4. Validation parity
One row per business rule: rule (plain language) | field(s) | legacy
enforcement (layer, verbatim, cited) | new enforcement (layer, verbatim,
cited) | classification | notes.

## 5. Data-origin parity
Per field with any origin difference: field | legacy terminal origin +
transforms | new terminal origin + transforms | read/write | difference |
risk. Plus page-level: tables only legacy touches; tables only the new stack
touches.

## 6. Action & outcome parity
Per action pair: trigger | legacy outcomes vs new outcomes (side-by-side) |
missing/added outcomes | double-submit protection comparison | side-effect
differences (audit, downstream, state).

## 7. Ambiguous matches — questions for the team
Numbered list; each answerable in one sentence by the page's developer.

## 8. P2 / P3 differences
The remaining classified differences, grouped by priority, briefly.
