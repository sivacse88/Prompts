# Parity Check — prompt series

Prerequisite: legacy artifacts exist at `docs/page-specs/<slug>/workbook.md`
(from the page-deep-dive skill). Open a multi-root VS Code workspace with the
legacy docs, the Angular repo, and the backend repo(s). Copilot Chat, agent
mode, fresh chat per prompt. Replace `<slug>`, `<ROUTE-OR-COMPONENT>`, and
`<BACKEND-REPO>` placeholders.

Setup (no model): create `docs/page-specs/<slug>/parity/`.

---

## C1 — Angular page extraction
*(Sonnet; Opus if the component tree is deep or state is NgRx-managed; cap 12, fresh chat)*

> You are extracting the complete behaviour of one modernized Angular page for
> a parity comparison against its legacy JSP predecessor. Target:
> `<ROUTE-OR-COMPONENT>`. Write findings to
> `docs/page-specs/<slug>/parity/angular-workbook.md`, sections A1–A5.
> Assign ids: fields `N01, N02…`, rules `NR01…`, actions `NA01…`.
> Budget: 12 file opens. Do not open the legacy artifacts — this extraction
> must be independent so the comparison is honest.
>
> **A1 — Route & entry.** Resolve the route: routing config (including lazy
> modules / standalone routes), the component(s) rendered, route params and
> query params consumed, guards (what they check — these are the page's
> preconditions), resolvers (what they pre-fetch, which service/API). Note
> every navigation INTO this route found in the repo (routerLink,
> `router.navigate`) with source component. Note interceptors that affect this
> page's calls (auth headers, error mapping).
>
> **A2 — Fields.** From the template(s) (including child components that
> render form parts — open them): every control and displayed value:
> id | label (resolve i18n keys to text) | control type | bound to
> (formControlName / ngModel / interpolation source) | display condition
> (`*ngIf`/`@if`/`[hidden]`/class logic — verbatim + plain language) |
> disabled/readonly logic | options source for selects/radios (static array,
> enum, service call — name the endpoint) | formatting pipes applied.
> Include hidden state carried in the form model but not rendered.
>
> **A3 — Validations & client rules.** From the form definition (FormBuilder /
> FormControl trees) and template: per control, the sync validators (with
> parameters — `maxLength(10)` not just "maxLength"), async validators (what
> they call), cross-field/group validators, and the exact error messages shown
> per error key. Then behaviour rules: `valueChanges` subscriptions
> (what recalculates/enables/fetches on what change, debounce times), masks/
> directives, submit-disable conditions. Mark each rule with where it lives:
> `template` / `form-def` / `service`.
>
> **A4 — Actions & API calls.** Every button/link/interaction: id | trigger |
> handler method | client gate (which NR rules block it) | the HTTP call(s)
> made — method, URL (resolve environment/base-path tokens), request payload
> type and which N-fields feed it, response type and which N-fields it
> populates | success behaviour (navigation, toast, state update) | error
> behaviour (per status code if handled). Include API calls made on load by
> resolvers/ngOnInit. End with a deduplicated **endpoint inventory** table:
> method | URL | purpose | request DTO | response DTO — this drives C2.
>
> **A5 — State.** Anything held in a store/service between pages (NgRx,
> signals, BehaviorSubjects): what this page reads/writes and who else uses it
> (the modern analogue of legacy session attributes).
>
> Cite `path:line` for everything. UNKNOWN where unresolvable. Reply only:
> field/rule/action counts and the endpoint inventory.

---

## C2 — Backend API trace
*(**Opus**, cap 12 per run, ≤3 endpoints per run, fresh chat each; repeat until the endpoint inventory is done)*

> You are tracing modernized Spring Boot APIs to their underlying data for a
> parity comparison. Read `docs/page-specs/<slug>/parity/angular-workbook.md`
> section A4's endpoint inventory; process the next ≤3 endpoints not yet in
> `docs/page-specs/<slug>/parity/api-workbook.md` (create/append; track
> `PENDING:` list at the top). Backend repo: `<BACKEND-REPO>`.
> Budget 12 opens per run.
>
> Per endpoint, sections B1–B4:
>
> **B1 — Identity.** Controller class#method (match by `@RequestMapping`-family
> path + method), security annotations (`@PreAuthorize` etc. — the new
> authorisation contract), request/response DTO classes.
>
> **B2 — Request side.** Every request DTO field: bean-validation annotations
> WITH parameters (`@NotNull`, `@Size(max=10)`, `@Pattern(…)` verbatim, custom
> validator classes — open them and state the rule), `@Valid` propagation,
> programmatic validations in controller/service (condition + message),
> then the WRITE path: service → repository/DAO → the exact table.column (or
> collection.field) each request field lands in, with transformations applied
> en route (trim/case/format/derive). JPA derived methods: parse the name.
> Dynamic SQL: enumerate branches. Terminal origin required — a service method
> is not an answer.
>
> **B3 — Response side.** Every response DTO field: the READ path back to its
> terminal origin (table.column / collection.field / external API / computed —
> with formula and inputs), plus formatting applied before serialization.
>
> **B4 — Error contract.** What each failure produces: validation failure
> shape (field errors format), business exceptions → status codes/messages
> (check `@ExceptionHandler`/`@ControllerAdvice`), and which the Angular side
> handles (cross-check A4 error behaviour — note unhandled statuses).
>
> Update the PENDING list. Reply only: endpoints traced this run, tables/
> collections touched, PENDING remainder.

---

## C3 — Matching & parity classification
*(**Opus**, cap 0 source files — artifacts only, fresh chat)*

> You are producing the parity comparison for page `<slug>`. Read ONLY:
> the legacy `workbook.md` (and `spec.md`), `parity/angular-workbook.md`,
> `parity/api-workbook.md`. Open no source code — a workbook gap is a finding
> (`UNKNOWN (workbook gap)`), not a research task.
> Write `docs/page-specs/<slug>/parity/comparison.md`.
>
> **Step 1 — Field matching.** Build the master mapping: legacy F-id ↔
> Angular N-id ↔ API DTO field ↔ terminal data origin (both sides). Match by
> label/business meaning FIRST, binding/DTO names second. Rules: one row per
> legacy field plus one row per unmatched new field; a match you are not
> certain of is `AMBIGUOUS — <why>` and excluded from difference
> classification until confirmed; never force-pair.
>
> **Step 2 — Field parity.** Per matched row classify:
> `MATCH` | `CHANGED(control|label|format|condition|options)` — state both
> sides verbatim | `MISSING-IN-NEW` (legacy field with no counterpart —
> include hidden fields; a dropped hidden key or lock-version field is a
> HIGH-risk finding) | `ADDED-IN-NEW`. Compare display conditions
> semantically: legacy state expression vs Angular `*ngIf` — same business
> condition or not?
>
> **Step 3 — Validation parity.** Unify all rules from: legacy client rules
> (P4/R-ids, including BYPASSABLE flags), legacy server rules (P5), Angular
> validators (NR), API bean/programmatic validations (B2). One row per
> distinct business rule per field: where enforced in legacy (client/server/
> both) vs where in new (Angular/API/both) → classify `MATCH`,
> `MOVED(layer→layer)`, `MISSING-IN-NEW`, `ADDED-IN-NEW`,
> `WEAKENED`/`STRENGTHENED` (constraint parameter deltas — maxlength 10→20 is
> WEAKENED with both values shown). Special flags: legacy BYPASSABLE rule now
> API-enforced = STRENGTHENED (good); legacy server rule now Angular-only =
> **BYPASSABLE-REGRESSION** (bad, high risk).
>
> **Step 4 — Data-origin parity.** Per matched field compare terminal origins:
> same table.column read AND written? Differences in store (jdbc→jpa on the
> same column is fine — note it; different column/table/collection is
> `DATA-DIFF`), and transformation deltas (legacy uppercased before persist,
> new does not → `DATA-DIFF(transform)`). Also compare at page level: tables
> legacy touched that no new API touches, and vice versa.
>
> **Step 5 — Action/outcome parity.** Legacy actions (A-ids) vs new (NA-ids):
> match by intent; compare outcome tables — every legacy outcome (validation
> failure, business rejection, exception, navigation) accounted for in the
> new flow? Double-submit protection equivalence (legacy token vs whatever the
> new stack does — if nothing, flag it). Side-effect parity: audit records,
> downstream calls, session/state effects.
>
> **Step 6 — Verdict.** Summary counts per classification; a prioritized gap
> list (P1 = functional loss or DATA-DIFF or BYPASSABLE-REGRESSION,
> P2 = behavioural difference, P3 = cosmetic); the AMBIGUOUS list as questions
> for the team; an "accomplished" summary of what the modernization fully
> covers. Reply only: the verdict counts and the P1 list.

---

## C4 — Report & HTML *(Sonnet, cap 0 source, fresh chat)*

> Read ONLY `parity/comparison.md`, the two parity workbooks (for citation
> lookups), `templates/parity-report-template.md`, and
> `templates/parity-template.html` from the skill folder.
>
> 1. Write `docs/page-specs/<slug>/parity/parity-report.md` per the template.
> 2. Write `docs/page-specs/<slug>/parity/parity.html` by filling the HTML
>    template: self-contained, status chips per the fixed vocabulary,
>    side-by-side legacy/new columns, filter buttons by classification, the
>    P1 risk banner at top. Wire rows with `data-status` as the template's
>    script expects.
> 3. Verify: every legacy F-id appears exactly once in the field matrix;
>    every classification uses the fixed vocabulary; every DATA-DIFF and
>    BYPASSABLE-REGRESSION appears in the risk banner; AMBIGUOUS rows render
>    with the question shown. List failures under `## Gaps` in the report.
> Reply only: file paths, classification counts, gap list.

---

## Model summary

| Prompt | Model | Why |
|---|---|---|
| C1 | Sonnet (Opus for deep component trees/NgRx) | structured extraction |
| C2 | **Opus** | terminal-origin tracing through DTOs/services/JPA is where cheap models stop early |
| C3 | **Opus** | semantic matching and classification is pure judgement — the core of the whole exercise |
| C4 | Sonnet | template rendering + mechanical verification |

Typical page: C1 ×1, C2 ×2–4 (endpoint batches), C3 ×1, C4 ×1 → 5–7 chats.

## Honest limits

- C3 compares what the workbooks contain. If the legacy deep-dive has UNKNOWN
  origins, parity for those fields is `UNKNOWN` too — resolve legacy first.
- Semantic condition comparison ("same business rule?") is a judgement call;
  that is why C3 is Opus and why AMBIGUOUS exists. Have the page's developer
  spend 15 minutes on the AMBIGUOUS list before trusting the report.
- Behaviour that lives in CSS (legacy show/hide via classes) is only caught if
  the legacy P2/P4 captured it — spot-check one known-different field to
  calibrate.
