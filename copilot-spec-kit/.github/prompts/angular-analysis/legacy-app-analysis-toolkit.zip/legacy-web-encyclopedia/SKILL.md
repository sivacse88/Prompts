---
name: legacy-web-encyclopedia
description: Reverse-engineer a legacy Java web application (Struts 1.x/2.x, or an app migrated off Struts that retains its idioms on Spring MVC/Boot) into a complete, evidence-backed "encyclopedia" — page inventory, navigation graph (every inbound path to every page), full-stack field-level data flow (JSP field → form bean → Action → service → DAO → SQL → table.column), a DB-column reverse index, and per-feature modernization packets for an Angular rewrite. Use when asked to analyze, document, map, inventory, or plan the modernization of such a codebase, or when building/updating files under docs/encyclopedia/.
---

# Legacy Web Encyclopedia

## Purpose

Turn a large legacy Java web application (200+ JSPs/routes; Struts-era architecture, whether or not Struts itself is still present) into a documentation
corpus that a developer or an AI agent can use to rebuild the app feature by
feature in Angular — without ever needing to read the legacy source again.

This skill is **process-first**. It never produces a giant document in one shot.
It produces many small, addressable files, built incrementally, each one
verifiable against the source.

## Non-negotiable operating rules

1. **Evidence or `UNKNOWN`.** Every factual claim carries a `path/to/File.java:123`
   citation. If you cannot find evidence, write `UNKNOWN — needs SME` and add a row
   to `docs/encyclopedia/_meta/open-questions.md`. Never infer behaviour from
   naming conventions and present it as fact.
2. **Write to disk, not to chat.** Analysis lives in files. Chat output is limited
   to a short completion report. This is the primary context-window control.
3. **Respect the context budget.** Each phase declares a maximum number of source
   files to open. If the budget is exceeded, stop, write a partial result, record
   the remainder in the ledger, and report `BUDGET_EXCEEDED`.
4. **Stable IDs, forever.** IDs assigned in Phase 1 (`PG-###`, `ACT-###`,
   `FLD-###`, `NAV-###`, `MOD-##`) never change. Everything cross-references by ID.
5. **Resume from the ledger, not from memory.** `docs/encyclopedia/_meta/ledger.md`
   is the single source of truth for what is done. Read it first in every session.
6. **One page = one file.** Never merge page cards. Never rewrite a completed file
   during a later phase; append to its designated section instead.
7. **Mechanical work goes to the script.** Run `scripts/scan_legacy_web.py` for
   anything that is grep-able. Reserve the model for semantics.

## Workflow

Follow the phases in order. Full prompt text for each phase is in
`PROMPT-SERIES.md` — copy them one at a time into Copilot Chat (agent mode).

| Phase | Produces | Budget |
|---|---|---|
| 0 | Mechanical scan → `_raw/*.csv` | 0 source files (script only) |
| 1.1 | Framework detection + request lifecycle + explainer | ≤12 config files |
| 1.2 | Spring/XML-DI wiring map + explainer | ≤12 context files |
| 1.3 | Technical setup (build, deploy, envs, run-locally) | ≤12 files |
| 1.4 | Module partition + ID assignment | 0 source (CSVs only) |
| 2 | Per-module page inventory | ≤12 per module |
| 3 | Per-page deep-dive cards | ≤12 files / 2 pages per prompt |
| 4 | Navigation graph — per-module edge extraction, then merge | reads Phase 3 output only |
| 5 | Field-level data flow + DB reverse index | ≤12 files / 2 pages per prompt |
| 6 | Cross-cutting concerns (auth, session, validation, layout) | ≤20 files per topic |
| 7 | Mechanical audit script + Opus gap reasoning | ≤10 (spot-check only) |
| 8 | Per-feature Angular modernization packets | 0 legacy source |

Phases 3 and 5 are the loops. Everything else runs once.

## Output tree

```
docs/encyclopedia/
  _meta/
    ledger.md              # what is done — read this first, always
    conventions.md         # copy of references/00-conventions.md, repo-local
    glossary.md            # domain terms found in the code
    open-questions.md      # every UNKNOWN, with the file that raised it
    coverage.md            # % of scanned artifacts documented
  _raw/                    # output of scripts/scan_legacy_web.py, never hand-edited
  00-architecture.md       # 1.1: framework, request lifecycle, explainer
  01-module-map.md         # 1.4: MOD-## partition + processing order
  02-spring-wiring.md      # 1.2: DI wiring map, transactions, proxies, explainer
  03-tech-setup.md         # 1.3: build, deps, app server, envs, run-locally
  modules/
    MOD-01-<name>/
      index.md             # module summary + page list
      pages/PG-001-<slug>.md
      flows/FL-01-<slug>.md
  navigation/
    graph.md               # global mermaid graph
    inbound-index.md       # PG-### → every way to reach it
    entrypoints.md         # URLs reachable without navigating from elsewhere
  data/
    field-index.md         # FLD-### → full trace, one row per field
    db-reverse-index.md    # table.column → screens/actions that read or write it
    domain-objects.md      # VOs, DTOs, form beans and their relationships
  cross-cutting/
    security.md  session.md  validation.md  layout-tiles.md
    error-handling.md  i18n.md  integrations.md
  modernization/
    slices.md              # ordered feature slices for the Angular rewrite
    MS-01-<feature>.md     # one packet per slice
```

## References

Load only what the current phase needs.

- `references/00-conventions.md` — ID scheme, front-matter schema, citation format,
  file naming. **Read before Phase 1.**
- `references/01-struts-detection.md` — how to tell Struts 1.x from 2.x and the
  exact artifact map for each. **Read in Phase 1.**
- `references/02-templates.md` — the page card, flow, and packet templates.
  **Read before Phases 3, 5, 8.**
- `references/03-tracing-rules.md` — rules for navigation-edge discovery and
  field tracing, including the hard cases (Tiles, forwards, redirects, JS-driven
  navigation, dynamic action mapping). **Read in Phases 3, 4, 5.**
- `references/04-quality-gates.md` — the checklist each artifact must pass and the
  Phase 7 sweep procedure.
- `references/05-spring-di-primer.md` — legacy Spring XML DI explained (for the
  team) plus extraction spec and traps (for the model). **Read in Phases 1.2 and 5.**
- `references/06-spring-mvc-profile.md` — artifact map for apps migrated off
  Struts onto Spring MVC/Boot while keeping Struts idioms. **When recon selects
  this profile, it replaces 01-struts-detection's artifact map in every phase.**

## Wiring into GitHub Copilot

Copilot does not read `SKILL.md`. To use this in VS Code, copy the folder into
the repo and add thin adapters:

- `.github/copilot-instructions.md` — repo-wide; point it at
  `docs/encyclopedia/_meta/conventions.md` and the ledger, and state rules 1–7 above.
- `.github/instructions/encyclopedia.instructions.md` — with front matter
  `applyTo: "docs/encyclopedia/**"` so the conventions auto-attach whenever
  Copilot edits encyclopedia files.
- `.github/prompts/phase-N-*.prompt.md` — one prompt file per phase, body copied
  from `PROMPT-SERIES.md`. Invoke with `/phase-3-page-card` in chat.

See `WIRING.md` for the exact files.

## Model selection

Sonnet executes procedures; Opus makes judgement calls. The complete per-prompt
table is at the top of `PROMPT-SERIES.md`. Summary: Opus for 1.2, 1.4, 2.Z, 3b,
4.2, 4.3, 5.ZZ, 6.1, 6.2, 7.1, and all of Phase 8; Sonnet for everything else;
escalate any Phase 5 page to Opus when its chain crosses dynamic SQL, stored
procedures, or AOP/transaction proxies.
