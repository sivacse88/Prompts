#!/usr/bin/env python3
"""
Phase 7 mechanical audit. Compares the Phase 0 CSVs against the encyclopedia
and writes docs/encyclopedia/_meta/audit-report.md. No LLM involved — run this
BEFORE the Phase 7 Opus prompt so the model only reasons about the report,
not the whole corpus.

    python3 scripts/audit_coverage.py --enc docs/encyclopedia
"""

import argparse
import csv
import os
import re
from collections import defaultdict

FM_RE = re.compile(r"^---\s*\n(.*?)\n---", re.S)
ID_RES = {k: re.compile(rf"\b{k}-\d+\b")
          for k in ("PG", "ACT", "FRM", "FLD", "NAV", "MOD", "FL", "OQ", "MS")}


def front_matter(text):
    m = FM_RE.match(text)
    if not m:
        return {}
    fm = {}
    for line in m.group(1).splitlines():
        if ":" in line and not line.startswith((" ", "-", "\t")):
            k, v = line.split(":", 1)
            fm[k.strip()] = v.strip()
    return fm


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--enc", default="docs/encyclopedia")
    args = ap.parse_args()
    enc = args.enc
    raw = os.path.join(enc, "_raw")

    # ---- corpus scan
    ids = defaultdict(set)          # prefix -> set of ids seen anywhere
    pages = {}                      # PG id -> {file, fm}
    dup_ids = defaultdict(list)
    sources_cited = set()
    missing_fm, missing_cite = [], []

    for root, dirs, files in os.walk(enc):
        if "_raw" in root:
            continue
        for f in files:
            if not f.endswith(".md"):
                continue
            path = os.path.join(root, f)
            rel = os.path.relpath(path, enc).replace("\\", "/")
            text = open(path, encoding="utf-8", errors="replace").read()
            for k, rx in ID_RES.items():
                for i in rx.findall(text):
                    ids[k].add(i)
            fm = front_matter(text)
            for m in re.finditer(r"`([\w./-]+\.(?:java|jsp|jspf|xml|js|properties))(?::\d+(?:-\d+)?)?", text):
                sources_cited.add(m.group(1))
            if "/pages/" in rel:
                if not fm:
                    missing_fm.append(rel)
                pid = fm.get("id", "")
                if pid:
                    if pid in pages:
                        dup_ids[pid].append(rel)
                    pages[pid] = {"file": rel, "fm": fm}
                # crude citation density check: a page card with <5 citations is suspect
                if len(re.findall(r"`[\w./-]+\.(?:java|jsp|xml|js)", text)) < 5:
                    missing_cite.append(rel)

    # ---- raw CSVs
    def load(name, col):
        p = os.path.join(raw, name)
        if not os.path.exists(p):
            return []
        with open(p, encoding="utf-8") as fh:
            return [r[col] for r in csv.DictReader(fh)]

    raw_jsps = set(load("jsp.csv", "path"))
    raw_actions = load("actions.csv", "path_or_name")
    raw_forms = load("forms.csv", "name")

    # which raw JSPs are accounted for (cited anywhere or listed as fragment)
    frag_file = os.path.join(enc, "cross-cutting", "layout-tiles.md")
    frag_text = open(frag_file, encoding="utf-8").read() if os.path.exists(frag_file) else ""
    cov_file = os.path.join(enc, "_meta", "coverage.md")
    cov_text = open(cov_file, encoding="utf-8").read() if os.path.exists(cov_file) else ""

    unaccounted_jsps = sorted(
        j for j in raw_jsps
        if j not in sources_cited and j not in frag_text and j not in cov_text)

    # ---- ledger
    ledger = os.path.join(enc, "_meta", "ledger.md")
    ledger_text = open(ledger, encoding="utf-8").read() if os.path.exists(ledger) else ""
    pending = re.findall(r"\|\s*(\S+)\s*\|\s*pending", ledger_text)
    partial = re.findall(r"\|\s*(PG-\d+|MOD-\d+|FL-\d+)\s*\|\s*partial", ledger_text)

    # pages whose card exists but phase 5 not done
    no_p5 = sorted(p for p, d in pages.items()
                   if "5" not in re.findall(r"\d+", d["fm"].get("phase_completed", "")))
    low_conf = sorted(p for p, d in pages.items()
                      if d["fm"].get("confidence") == "low")

    # ---- sanitization scan (conventions §8, Gate 5)
    san_file = os.path.join(enc, "_meta", "sanitization.md")
    tokens = []
    if os.path.exists(san_file):
        for line in open(san_file, encoding="utf-8"):
            line = line.strip()
            if line.startswith("- "):
                tokens.append(line[2:].strip().strip("`").lower())
    san_hits = []
    mod_dir = os.path.join(enc, "modernization")
    path_re = re.compile(r"\b[\w-]+/[\w./-]+\.(?:java|jsp|xml|js|properties)\b")
    if os.path.isdir(mod_dir):
        for f in os.listdir(mod_dir):
            if not f.endswith(".md"):
                continue
            text = open(os.path.join(mod_dir, f),
                        encoding="utf-8", errors="replace").read()
            low_text = text.lower()
            for t in tokens:
                if t and t in low_text:
                    san_hits.append(f"{f}: token '{t}'")
            for m in path_re.finditer(text):
                san_hits.append(f"{f}: repo path '{m.group(0)}'")

    # ---- report
    out = os.path.join(enc, "_meta", "audit-report.md")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    L = ["# Mechanical audit report (audit_coverage.py)", ""]
    L += ["| metric | value |", "|---|---|"]
    L += [f"| JSPs in _raw | {len(raw_jsps)} |",
          f"| action mappings in _raw | {len(raw_actions)} |",
          f"| form beans in _raw | {len(raw_forms)} |",
          f"| page cards found | {len(pages)} |",
          f"| PG ids referenced anywhere | {len(ids['PG'])} |",
          f"| ACT ids | {len(ids['ACT'])} | ",
          f"| FLD ids | {len(ids['FLD'])} |",
          f"| NAV ids | {len(ids['NAV'])} |",
          f"| open OQ ids | {len(ids['OQ'])} |",
          f"| distinct source files cited | {len(sources_cited)} |", ""]

    def section(title, items, limit=200):
        L.append(f"## {title} ({len(items)})")
        L.append("")
        L.extend(f"- {x}" for x in items[:limit])
        if len(items) > limit:
            L.append(f"- … and {len(items)-limit} more")
        if not items:
            L.append("- none")
        L.append("")

    section("JSPs not cited by any doc, not a known fragment, not excluded", unaccounted_jsps)
    section("PG ids referenced but with no page card",
            sorted(ids["PG"] - set(pages)))
    section("Duplicate PG ids", [f"{k}: {v}" for k, v in dup_ids.items()])
    section("Page cards missing front matter", missing_fm)
    section("Page cards with suspiciously few citations (<5)", missing_cite)
    section("Pages without Phase 5 field trace", no_p5)
    section("Pages marked confidence: low", low_conf)
    section("Ledger: pending units", sorted(set(pending)))
    section("Ledger: partial units", sorted(set(partial)))
    if not tokens:
        L += ["## Sanitization scan", "",
              "- SKIPPED: _meta/sanitization.md missing or empty — create it "
              "(conventions §8)", ""]
    else:
        section("Sanitization violations in modernization/ (Gate 5 FAIL if any)",
                sorted(set(san_hits)))

    with open(out, "w", encoding="utf-8") as fh:
        fh.write("\n".join(L))
    print(f"wrote {out}")
    print(f"  unaccounted JSPs: {len(unaccounted_jsps)}  "
          f"pending: {len(set(pending))}  partial: {len(set(partial))}  "
          f"no-phase5: {len(no_p5)}")


if __name__ == "__main__":
    main()
