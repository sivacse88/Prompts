#!/usr/bin/env python3
"""
Phase 0 mechanical scanner for a legacy Struts application.

Extracts everything grep-able into CSVs so the LLM phases never have to scan
the repo. Run once at the start; re-run after any source change.

    python3 scripts/scan_legacy_web.py --repo . --out docs/encyclopedia/_raw

Outputs:
    summary.md          counts + framework detection signals
    jsp.csv             every JSP, size, includes, taglibs used, form count
    actions.csv         action mappings (Struts 1 + Struts 2)
    forms.csv           form beans
    forwards.csv        forwards / results
    taglib_links.csv    <html:link>, <s:url>, <a href>, <form action> sites
    js_nav.csv          JS-driven navigation call sites
    session_attrs.csv   HttpSession attribute names with read/write
    sql.csv             SQL statements found in xml maps and java strings
    java_classes.csv    java classes with their superclass and layer guess

No external dependencies. Python 3.8+.
"""

import argparse
import csv
import os
import re
import sys
from collections import defaultdict

# ---------------------------------------------------------------- config

SRC_EXT = {".java", ".jsp", ".jspf", ".tag", ".xml", ".js", ".html", ".htm",
           ".properties", ".tld", ".vm", ".ftl"}

SKIP_DIRS = {".git", ".svn", "node_modules", "target", "build", "dist", "out",
             "bin", ".idea", ".settings", "generated", "gen", ".gradle",
             "docs/encyclopedia"}

SKIP_FILE_RE = re.compile(r"(min\.js|\.min\.css|-sources\.jar)$", re.I)

# ---------------------------------------------------------------- helpers


def walk(repo):
    for root, dirs, files in os.walk(repo):
        rel_root = os.path.relpath(root, repo).replace("\\", "/")
        dirs[:] = [d for d in dirs
                   if d not in SKIP_DIRS
                   and f"{rel_root}/{d}".lstrip("./") not in SKIP_DIRS]
        for f in files:
            ext = os.path.splitext(f)[1].lower()
            if ext not in SRC_EXT or SKIP_FILE_RE.search(f):
                continue
            full = os.path.join(root, f)
            rel = os.path.relpath(full, repo).replace("\\", "/")
            yield rel, full


def read(path):
    for enc in ("utf-8", "latin-1"):
        try:
            with open(path, "r", encoding=enc, errors="strict") as fh:
                return fh.read()
        except (UnicodeDecodeError, LookupError):
            continue
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        return fh.read()


def lineno(text, pos):
    return text.count("\n", 0, pos) + 1


def write_csv(outdir, name, header, rows):
    path = os.path.join(outdir, name)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(header)
        w.writerows(rows)
    return len(rows)


def attrs(tag_text):
    """Parse XML/HTML attributes out of a tag string."""
    return dict(re.findall(r'([\w:-]+)\s*=\s*"([^"]*)"', tag_text))


# ---------------------------------------------------------------- patterns

RE_S1_ACTION = re.compile(r"<action\b([^>]*)>?", re.I)
RE_S1_FORM = re.compile(r"<form-bean\b([^>]*)/?>", re.I)
RE_S1_FORWARD = re.compile(r"<forward\b([^>]*)/?>", re.I)
RE_S2_ACTION = re.compile(r"<action\b([^>]*)>", re.I)
RE_S2_RESULT = re.compile(r'<result\b([^>]*)>\s*([^<]*)', re.I)
RE_S2_PACKAGE = re.compile(r"<package\b([^>]*)>", re.I)
RE_TILES_DEF = re.compile(
    r"<definition\b([^>]*?)(?:/>|>(.*?)</definition>)", re.I | re.S)
RE_TILES_PUT = re.compile(r"<put(?:-attribute)?\b([^>]*)/?>", re.I)

# Spring MVC (post-Struts migration profile)
RE_MVC_CLASS = re.compile(r"@(Controller|RestController)\b")
RE_MVC_MAP = re.compile(
    r"@(RequestMapping|GetMapping|PostMapping|PutMapping|DeleteMapping|PatchMapping)"
    r"\s*(?:\(\s*([^)]*)\))?", re.S)
RE_FORWARD_TO = re.compile(r'\bforwardTo\s*\(\s*"([^"]+)"')
RE_ENTITY = re.compile(r"@Entity\b|@Table\s*\(\s*name\s*=\s*\"([^\"]+)\"|"
                       r"@Document\s*\(\s*collection\s*=\s*\"([^\"]+)\"")
RE_COLUMN = re.compile(r"@Column\s*\(\s*name\s*=\s*\"([^\"]+)\"")
RE_REPO = re.compile(
    r"interface\s+(\w+)\s+extends\s+((?:Jpa|Crud|PagingAndSorting|Mongo|ListCrud)"
    r"Repository\s*<\s*(\w+))")
RE_QUERY_ANN = re.compile(r"@Query\s*\(\s*(?:value\s*=\s*)?\"([^\"]{0,300})\"")

RE_ANNOT_ACTION = re.compile(r'@Action\s*\(\s*(?:value\s*=\s*)?"([^"]+)"')
RE_CLASS = re.compile(
    r"\b(?:public|abstract|final|\s)*class\s+(\w+)"
    r"(?:\s+extends\s+([\w.<>]+))?"
    r"(?:\s+implements\s+([\w.,<>\s]+))?")

RE_INCLUDE = re.compile(
    r'<%@\s*include\s+file\s*=\s*"([^"]+)"|<jsp:include\s+page\s*=\s*"([^"]+)"', re.I)
RE_TAGLIB = re.compile(r'<%@\s*taglib[^%]*prefix\s*=\s*"(\w+)"[^%]*%>', re.I)

RE_LINK_TAGS = re.compile(
    r'<(html:link|html:form|html:frame|html:rewrite|s:url|s:a|s:form|s:submit'
    r'|a|form|iframe|frame)\b([^>]*)>', re.I)

RE_JS_NAV = re.compile(
    r'(window\.location(?:\.href)?\s*=|location\.replace\s*\(|window\.open\s*\('
    r'|document\.forms\[[^\]]*\]\.action\s*=|\.action\s*=\s*["\']'
    r'|\.submit\s*\(\s*\)|\$\.(?:post|get|ajax)\s*\()([^\n;]{0,120})', re.I)

RE_SESSION = re.compile(
    r'(?:session|request\.getSession\(\s*\w*\s*\))\s*\.\s*'
    r'(setAttribute|getAttribute|removeAttribute)\s*\(\s*([^,)]+)')
RE_JSP_SESSION = re.compile(
    r'<(?:c:set|c:out)[^>]*scope\s*=\s*"session"[^>]*var\s*=\s*"(\w+)"'
    r'|sessionScope\.(\w+)', re.I)

RE_SQL_XML = re.compile(
    r'<(select|insert|update|delete|statement|procedure|sql)\b([^>]*)>(.*?)</\1>',
    re.I | re.S)
RE_SQL_JAVA = re.compile(
    r'"\s*(SELECT|INSERT\s+INTO|UPDATE|DELETE\s+FROM|MERGE\s+INTO)\b([^"]{0,300})"',
    re.I)
RE_TABLES = re.compile(
    r'\b(?:FROM|JOIN|INTO|UPDATE)\s+([A-Za-z_][\w$.]*)', re.I)

LAYER_HINTS = [
    (re.compile(r'(Action|Controller)$'), "controller"),
    (re.compile(r'(Service|Manager|Facade|BO|BusinessObject)$'), "service"),
    (re.compile(r'(Dao|DAO|Repository|Mapper|Persist\w*)$'), "persistence"),
    (re.compile(r'(Form|FormBean)$'), "form"),
    (re.compile(r'(VO|DTO|Bean|Entity|Model)$'), "domain"),
    (re.compile(r'(Filter|Listener|Interceptor|Servlet)$'), "infrastructure"),
    (re.compile(r'(Util|Utils|Helper|Constants)$'), "util"),
]


def guess_layer(cls, superclass):
    sup = superclass or ""
    if "Action" in sup or "ActionSupport" in sup:
        return "controller"
    for rx, layer in LAYER_HINTS:
        if rx.search(cls):
            return layer
    return "unknown"


# ---------------------------------------------------------------- scan

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default=".")
    ap.add_argument("--out", default="docs/encyclopedia/_raw")
    args = ap.parse_args()

    repo = os.path.abspath(args.repo)
    outdir = os.path.abspath(args.out)
    os.makedirs(outdir, exist_ok=True)

    jsp_rows, action_rows, form_rows, forward_rows = [], [], [], []
    link_rows, js_rows, sess_rows, sql_rows, class_rows = [], [], [], [], []
    tiles_rows, mvc_rows, entity_rows = [], [], []
    test_skipped = 0
    signals = defaultdict(list)
    file_count = 0

    files = list(walk(repo))
    for rel, full in files:
        # test resources are invisible to the pipeline (e.g. struts-config
        # fixtures under src/test would pollute actions.csv)
        if "/src/test/" in "/" + rel or "/test/resources/" in "/" + rel:
            test_skipped += 1
            continue
        ext = os.path.splitext(rel)[1].lower()
        try:
            text = read(full)
        except OSError as e:
            print(f"skip {rel}: {e}", file=sys.stderr)
            continue
        file_count += 1
        low = text.lower()

        # -------- framework detection signals
        if "org.apache.struts.action.actionservlet" in low:
            signals["struts1"].append(f"{rel} (ActionServlet)")
        if "strutsprepareandexecutefilter" in low or "filterdispatcher" in low:
            signals["struts2"].append(f"{rel} (Struts2 filter)")
        if "tags-html" in low or "struts-html" in low:
            signals["struts1"].append(f"{rel} (html taglib)")
        if "/struts-tags" in low:
            signals["struts2"].append(f"{rel} (s taglib)")
        for m in re.finditer(r'struts[\w-]*?-?(\d+\.\d+(?:\.\d+)?)', rel, re.I):
            signals["version"].append(f"{rel} -> {m.group(1)}")

        # -------- JSPs
        if ext in (".jsp", ".jspf", ".tag"):
            includes = [a or b for a, b in RE_INCLUDE.findall(text)]
            taglibs = sorted(set(RE_TAGLIB.findall(text)))
            jsp_rows.append([
                rel, len(text.splitlines()),
                len(re.findall(r"<%[^@!]", text)),          # scriptlet count
                ";".join(taglibs), ";".join(includes),
                len(re.findall(r"<html:form|<s:form|<form\b", text, re.I)),
                len(re.findall(r"<html:|<s:|<logic:|<bean:", text, re.I)),
            ])

        # -------- Struts config XML
        if ext == ".xml" and ("<action-mappings" in low or "<struts-config" in low):
            for m in RE_S1_ACTION.finditer(text):
                a = attrs(m.group(1))
                if not a.get("path"):
                    continue
                action_rows.append([
                    "struts1", rel, lineno(text, m.start()), a.get("path", ""),
                    a.get("type", ""), a.get("parameter", ""), a.get("name", ""),
                    a.get("scope", ""), a.get("validate", ""), a.get("input", ""),
                    "", ""])
            for m in RE_S1_FORM.finditer(text):
                a = attrs(m.group(1))
                form_rows.append(["struts1", rel, lineno(text, m.start()),
                                  a.get("name", ""), a.get("type", ""), "",
                                  str(text.count(f'name="{a.get("name","")}"'))])
            for m in RE_S1_FORWARD.finditer(text):
                a = attrs(m.group(1))
                forward_rows.append(["struts1", rel, lineno(text, m.start()),
                                     a.get("name", ""), a.get("path", ""),
                                     a.get("redirect", "false"), ""])

        if ext == ".xml" and ("<struts>" in low or "struts-default" in low):
            ns = ""
            for pm in RE_S2_PACKAGE.finditer(text):
                ns = attrs(pm.group(1)).get("namespace", ns)
            for m in RE_S2_ACTION.finditer(text):
                a = attrs(m.group(1))
                if not a.get("name"):
                    continue
                action_rows.append([
                    "struts2", rel, lineno(text, m.start()), a.get("name", ""),
                    a.get("class", ""), a.get("method", ""), "", "", "", "",
                    ns, "wildcard" if "*" in a.get("name", "") else ""])
            for m in RE_S2_RESULT.finditer(text):
                a = attrs(m.group(1))
                forward_rows.append(["struts2", rel, lineno(text, m.start()),
                                     a.get("name", "success"),
                                     (m.group(2) or "").strip(),
                                     a.get("type", "dispatcher"), ""])

        # -------- Tiles definitions
        if ext == ".xml" and ("<tiles-definitions" in low or "<definition" in low
                              and "tiles" in rel.lower()):
            for m in RE_TILES_DEF.finditer(text):
                a = attrs(m.group(1))
                body = m.group(2) or ""
                puts = []
                for pm in RE_TILES_PUT.finditer(body):
                    pa = attrs(pm.group(1))
                    puts.append(f"{pa.get('name','')}={pa.get('value','')}")
                tiles_rows.append([rel, lineno(text, m.start()),
                                   a.get("name", ""),
                                   a.get("extends", ""),
                                   a.get("template", "") or a.get("path", "")
                                   or a.get("page", ""),
                                   ";".join(puts)])

        # -------- Java
        if ext == ".java":
            for m in RE_CLASS.finditer(text):
                cls, sup, impl = m.group(1), m.group(2) or "", m.group(3) or ""
                class_rows.append([rel, lineno(text, m.start()), cls, sup,
                                   " ".join(impl.split()),
                                   guess_layer(cls, sup),
                                   len(re.findall(r"\bpublic\s+[\w<>\[\], ]+\s+\w+\s*\(", text))])
            for m in RE_ANNOT_ACTION.finditer(text):
                action_rows.append(["struts2-annot", rel, lineno(text, m.start()),
                                    m.group(1), "", "", "", "", "", "", "", "annotation"])
            # Spring MVC routes
            is_controller = bool(RE_MVC_CLASS.search(text))
            for m in RE_MVC_MAP.finditer(text):
                mvc_rows.append([rel, lineno(text, m.start()), m.group(1),
                                 " ".join((m.group(2) or "").split())[:160],
                                 "controller" if is_controller else "other"])
            for m in RE_FORWARD_TO.finditer(text):
                forward_rows.append(["code-forwardTo", rel,
                                     lineno(text, m.start()),
                                     m.group(1), "", "", "resolve via forwardMap"])
            # Entities / documents / repositories
            for m in RE_ENTITY.finditer(text):
                kind = ("table" if m.group(1) else
                        "collection" if m.group(2) else "entity")
                entity_rows.append([rel, lineno(text, m.start()), kind,
                                    m.group(1) or m.group(2) or "",
                                    ";".join(RE_COLUMN.findall(text)[:40])])
            for m in RE_REPO.finditer(text):
                entity_rows.append([rel, lineno(text, m.start()), "repository",
                                    f"{m.group(1)} -> {m.group(3)}",
                                    ";".join(q[:80] for q in
                                             RE_QUERY_ANN.findall(text)[:10])])

        # -------- link sites (JSP/HTML)
        if ext in (".jsp", ".jspf", ".tag", ".html", ".htm"):
            for m in RE_LINK_TAGS.finditer(text):
                tag, raw = m.group(1), m.group(2)
                a = attrs(raw)
                target = (a.get("action") or a.get("forward") or a.get("href")
                          or a.get("page") or a.get("src") or a.get("value") or "")
                if not target:
                    continue
                link_rows.append([rel, lineno(text, m.start()), tag.lower(),
                                  target, a.get("onclick", ""),
                                  a.get("namespace", ""), raw.strip()[:160]])

        # -------- JS navigation
        if ext in (".js", ".jsp", ".jspf", ".html", ".htm", ".tag"):
            for m in RE_JS_NAV.finditer(text):
                js_rows.append([rel, lineno(text, m.start()),
                                m.group(1).strip(),
                                m.group(2).strip()[:160]])

        # -------- session attributes
        if ext in (".java", ".jsp", ".jspf", ".tag"):
            for m in RE_SESSION.finditer(text):
                sess_rows.append([rel, lineno(text, m.start()), m.group(1),
                                  m.group(2).strip().strip('"')])
            for m in RE_JSP_SESSION.finditer(text):
                name = m.group(1) or m.group(2)
                sess_rows.append([rel, lineno(text, m.start()), "jspAccess", name])

        # -------- SQL
        if ext == ".xml" and re.search(r"sqlMap|mapper|hibernate-mapping", text, re.I):
            for m in RE_SQL_XML.finditer(text):
                a = attrs(m.group(2))
                body = " ".join(m.group(3).split())
                tables = sorted(set(t.upper() for t in RE_TABLES.findall(body)))
                sql_rows.append([rel, lineno(text, m.start()), m.group(1).lower(),
                                 a.get("id", ""), a.get("parameterClass", "")
                                 or a.get("parameterType", ""),
                                 a.get("resultClass", "") or a.get("resultMap", "")
                                 or a.get("resultType", ""),
                                 ";".join(tables),
                                 "dynamic" if re.search(r"<(isNotNull|isNotEmpty|if|choose|where)\b", m.group(3), re.I) else "static",
                                 body[:300]])
        if ext == ".java":
            for m in RE_SQL_JAVA.finditer(text):
                body = " ".join((m.group(1) + m.group(2)).split())
                tables = sorted(set(t.upper() for t in RE_TABLES.findall(body)))
                sql_rows.append([rel, lineno(text, m.start()),
                                 m.group(1).split()[0].lower(), "", "", "",
                                 ";".join(tables), "inline-java", body[:300]])

    # ---------------------------------------------------------------- write
    counts = {}
    counts["jsp.csv"] = write_csv(outdir, "jsp.csv",
        ["path", "lines", "scriptlets", "taglibs", "includes", "forms", "struts_tags"],
        sorted(jsp_rows))
    counts["actions.csv"] = write_csv(outdir, "actions.csv",
        ["flavor", "config_file", "line", "path_or_name", "class", "method_or_param",
         "form_name", "scope", "validate", "input", "namespace", "note"],
        sorted(action_rows, key=lambda r: (r[0], r[3])))
    counts["forms.csv"] = write_csv(outdir, "forms.csv",
        ["flavor", "config_file", "line", "name", "type", "scope", "ref_count"],
        sorted(form_rows, key=lambda r: r[3]))
    counts["forwards.csv"] = write_csv(outdir, "forwards.csv",
        ["flavor", "config_file", "line", "name", "target", "redirect_or_type", "note"],
        sorted(forward_rows, key=lambda r: (r[1], r[2])))
    counts["taglib_links.csv"] = write_csv(outdir, "taglib_links.csv",
        ["file", "line", "tag", "target", "onclick", "namespace", "raw"],
        sorted(link_rows))
    counts["js_nav.csv"] = write_csv(outdir, "js_nav.csv",
        ["file", "line", "construct", "context"], sorted(js_rows))
    counts["session_attrs.csv"] = write_csv(outdir, "session_attrs.csv",
        ["file", "line", "op", "attribute"], sorted(sess_rows, key=lambda r: (r[3], r[0])))
    counts["sql.csv"] = write_csv(outdir, "sql.csv",
        ["file", "line", "kind", "id", "param", "result", "tables", "shape", "snippet"],
        sorted(sql_rows))
    counts["spring_mvc.csv"] = write_csv(outdir, "spring_mvc.csv",
        ["file", "line", "annotation", "args", "class_kind"], sorted(mvc_rows))
    counts["entities.csv"] = write_csv(outdir, "entities.csv",
        ["file", "line", "kind", "name_or_mapping", "columns_or_queries"],
        sorted(entity_rows, key=lambda r: (r[2], r[3])))
    counts["tiles.csv"] = write_csv(outdir, "tiles.csv",
        ["file", "line", "definition", "extends", "template", "puts"],
        sorted(tiles_rows, key=lambda r: r[2]))
    counts["java_classes.csv"] = write_csv(outdir, "java_classes.csv",
        ["path", "line", "class", "extends", "implements", "layer_guess", "public_methods"],
        sorted(class_rows, key=lambda r: (r[5], r[2])))

    # ---------------------------------------------------------------- summary
    sess_names = sorted({r[3] for r in sess_rows if r[3]})
    tables = sorted({t for r in sql_rows for t in r[6].split(";") if t})
    layers = defaultdict(int)
    for r in class_rows:
        layers[r[5]] += 1

    s1, s2 = len(signals["struts1"]), len(signals["struts2"])
    n_mvc = len([r for r in mvc_rows if r[4] == "controller"])
    if n_mvc and not action_rows:
        verdict = ("Spring MVC (post-Struts migration profile) — use "
                   "references/06-spring-mvc-profile.md")
    elif s1 and not s2:
        verdict = "Struts 1.x" + (
            f" + Spring MVC ({n_mvc} mapped methods) — check for migration"
            if n_mvc else "")
    elif s2 and not s1:
        verdict = "Struts 2.x"
    elif s1 and s2:
        verdict = "HYBRID / ambiguous — inspect manually"
    else:
        verdict = "UNDETECTED — check web.xml / Spring Boot entry point manually"

    lines = [
        "# Phase 0 scan summary", "",
        f"Repo: `{repo}`", f"Files scanned: {file_count}",
        f"Test-resource files skipped: {test_skipped}", "",
        "## Framework detection", "",
        f"**Verdict: {verdict}**", "",
        f"- Struts 1 signals: {s1}",
    ]
    lines += [f"  - {x}" for x in signals["struts1"][:8]]
    lines += [f"- Struts 2 signals: {s2}"]
    lines += [f"  - {x}" for x in signals["struts2"][:8]]
    if signals["version"]:
        lines += ["- Version hints:"] + [f"  - {x}" for x in sorted(set(signals["version"]))[:10]]
    lines += ["", "## Counts", "", "| artifact | count |", "|---|---|"]
    for k, v in counts.items():
        lines.append(f"| {k} | {v} |")
    lines += ["", "## Class layer distribution", "", "| layer | classes |", "|---|---|"]
    for k in sorted(layers, key=lambda x: -layers[x]):
        lines.append(f"| {k} | {layers[k]} |")
    lines += ["", f"## Distinct session attributes ({len(sess_names)})", ""]
    lines += ["- " + ", ".join(sess_names[:80])] if sess_names else ["- none found"]
    lines += ["", f"## Distinct tables referenced ({len(tables)})", ""]
    lines += ["- " + ", ".join(tables[:120])] if tables else ["- none found"]
    lines += ["", "## Next step", "",
              "Run Phase 1 Prompt 1.1 from `PROMPT-SERIES.md`.", ""]

    with open(os.path.join(outdir, "summary.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines))

    print(f"Scanned {file_count} files -> {outdir}")
    for k, v in counts.items():
        print(f"  {k:20s} {v}")
    print(f"  framework verdict: {verdict}")


if __name__ == "__main__":
    main()
