# legacy-web-encyclopedia

A skill + prompt series for reverse-engineering a large legacy Java web app
(Struts 1.x/2.x, or post-Struts migrations that kept the idioms)
into an evidence-backed encyclopedia, then converting that into per-feature
modernization packets for an Angular rewrite.

```
SKILL.md            the skill definition and operating rules
PROMPT-SERIES.md    the incremental prompts — this is what you actually run
WIRING.md           how to plug it into GitHub Copilot in VS Code
references/
  00-conventions.md      ID scheme, front matter, citations, context budgets
  01-struts-detection.md Struts 1 vs 2 detection + artifact map + gotchas
  02-templates.md        page card, flow, field index, reverse index, packet
  03-tracing-rules.md    9 navigation-discovery sources, 8 field-trace hops
  04-quality-gates.md    per-artifact checklist + the Phase 7 audit
  05-spring-di-primer.md legacy Spring XML DI: primer for the team,
                         extraction spec + traps for the model
scripts/
  scan_legacy_web.py         Phase 0 mechanical scan → CSVs (no LLM context used)
  audit_coverage.py      Phase 7.0 mechanical audit → _meta/audit-report.md
```

## Quick start

```bash
# 1. copy this folder into the legacy repo
cp -r legacy-web-encyclopedia <legacy-repo>/.copilot-skills/

# 2. Phase 0 — mechanical scan
cd <legacy-repo>
python3 .copilot-skills/legacy-web-encyclopedia/scripts/scan_legacy_web.py \
        --repo . --out docs/encyclopedia/_raw
cat docs/encyclopedia/_raw/summary.md    # tells you Struts 1.x vs 2.x

# 3. seed the conventions
mkdir -p docs/encyclopedia/_meta
cp .copilot-skills/legacy-web-encyclopedia/references/00-conventions.md \
   docs/encyclopedia/_meta/conventions.md

# 4. add the Copilot adapters from WIRING.md, then run Phase 1
```

Then work through `PROMPT-SERIES.md` one prompt per fresh chat.

## The design in one paragraph

Context windows are the binding constraint, so nothing is held in the model:
a script extracts everything grep-able up front, every prompt names the exact
files it may open (hard cap 12) and writes its findings to disk, and an
append-only ledger — not chat history — carries state between runs. Stable IDs
let ~270 small documents cross-reference each other without ever being merged.
Every claim carries a `file:line` citation or is explicitly marked `UNKNOWN`,
because a confident wrong fact gets encoded into the Angular rewrite while a
gap gets asked about.
