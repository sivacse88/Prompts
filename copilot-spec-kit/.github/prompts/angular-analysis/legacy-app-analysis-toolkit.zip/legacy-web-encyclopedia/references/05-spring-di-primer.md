# Spring XML dependency-injection primer

Two audiences: (a) a developer who has never worked with pre-annotation Spring —
read Part 1 as background; (b) the model during Phases 1–5 — Part 2 tells it what
to extract and how to resolve wiring, Part 3 lists the traps.

---

## Part 1 — How old Spring DI works (background reading)

Modern Spring uses `@Component`/`@Autowired` and component scanning. Legacy
Spring (1.x–2.x era, still common under Struts apps) declares **every bean in
XML**. Nothing is discovered; everything is written down. That is bad for
authoring but excellent for reverse-engineering — the XML is a complete wiring
diagram.

### The core pattern

```xml
<!-- applicationContext.xml -->
<bean id="invoiceService" class="com.acme.billing.service.InvoiceServiceImpl">
    <property name="invoiceDao" ref="invoiceDao"/>          <!-- setter injection -->
    <property name="maxResults" value="500"/>               <!-- literal config -->
</bean>

<bean id="invoiceDao" class="com.acme.billing.dao.IbatisInvoiceDao">
    <constructor-arg ref="sqlMapClient"/>                   <!-- constructor injection -->
</bean>
```

Read it as: "`invoiceService` is an `InvoiceServiceImpl` whose `setInvoiceDao()`
was called with the `invoiceDao` bean, and whose `setMaxResults()` was called
with 500." When Java code calls `invoiceService.search(...)`, the concrete class
is whatever the XML says — **you cannot know the implementation from the Java
code alone**; the interface in the code and the class in the XML are the pair
that matters.

### Things you'll see and what they mean

| XML | Meaning |
|---|---|
| `<property name="x" ref="y"/>` | setter injection of another bean |
| `<constructor-arg ref=.../>` | constructor injection |
| `<bean ... parent="baseDao">` | inherits property values from an abstract parent bean |
| `<bean ... abstract="true">` | template only, never instantiated |
| `<bean ... factory-bean=... factory-method=...>` | created by calling a method on another bean |
| `<bean ... init-method="init">` | lifecycle hook called after wiring |
| `<bean ... scope="prototype">` (or `singleton="false"`) | new instance per lookup — default is singleton |
| `<alias name="a" alias="b"/>` | two ids, one bean |
| `<import resource="dao-context.xml"/>` | context is split across files; follow the chain |
| `${jdbc.url}` + `PropertyPlaceholderConfigurer` | value comes from a `.properties` file at boot |
| `<bean class="...ProxyFactoryBean">` with `target` + `interceptorNames` | AOP proxy — calls to this bean pass through interceptors first |
| `TransactionProxyFactoryBean` with `transactionAttributes` | **this is where transaction boundaries live** — e.g. `save*=PROPAGATION_REQUIRED` means every method starting with `save` opens a transaction |
| `<tx:advice>` + `<aop:config pointcut=...>` | later-style declarative transactions; same idea, regex/AspectJ pointcut instead of method-name match |
| `JndiObjectFactoryBean` | the bean (usually the DataSource) comes from the app server via JNDI, not from this XML |

### How Spring connects to Struts

There are three patterns; identify which one this app uses, because it changes
where the "real" action logic is:

1. **`ContextLoaderPlugIn` + `DelegatingActionProxy`** (Struts 1): the
   `struts-config.xml` action `type` is `DelegatingActionProxy`, and the *actual*
   Action class is a Spring bean whose **name = the action path** in
   `action-servlet.xml`. To find the real class for `/billing/invoiceSearch`,
   look up `<bean name="/billing/invoiceSearch" class=...>` in the Spring file —
   not in struts-config.
2. **`ActionSupport` base class / `WebApplicationContextUtils`** (Struts 1):
   Actions fetch beans manually: `getWebApplicationContext().getBean("invoiceService")`.
   Wiring is in code, so grep `getBean(` — each call site is a dependency edge.
3. **`struts2-spring-plugin`** (Struts 2): action classes are created by Spring;
   `class=` in `struts.xml` may be a **bean id, not a class name**. Check
   `struts.objectFactory=spring` in `struts.properties`.

### Two-context gotcha

Legacy apps usually have **two** Spring contexts: the root context
(`applicationContext*.xml`, loaded by `ContextLoaderListener` in `web.xml`) and a
web/action context (`action-servlet.xml` or `<servlet-name>-servlet.xml`). The web
context can see root beans; not vice versa. When a bean id appears twice, the web
context wins for web requests. Record which file wins.

---

## Part 2 — What to extract (model instructions)

When Phase 1.2 builds `02-spring-wiring.md`, produce:

1. **Context inventory** — every XML context file, how it is loaded
   (`web.xml` listener/servlet, `<import>`, plug-in), and the parent/child
   relationship between contexts.
2. **Bean catalogue** — table: bean id | class | scope | layer
   (controller/service/dao/infra) | injected deps (ids) | injected config values |
   defined in. Skip pure infrastructure beans (property configurers, message
   sources) into a separate short table.
3. **Struts↔Spring bridge** — which of the three patterns above, with evidence;
   for pattern 1, the full action-path → bean → class resolution table.
4. **Transaction map** — every transactional proxy/advice, the method patterns it
   matches, and the propagation behaviour. This defines the unit-of-work
   boundaries the Angular-era API must reproduce.
5. **AOP/interceptor map** — any other proxies (security, audit, caching) and
   which beans they wrap. A call to a wrapped bean is not a plain method call.
6. **Externalised config** — every `${placeholder}`, which properties file feeds
   it, and per-environment differences if multiple files exist.
7. **Dependency diagram** — mermaid, service→dao level, per module.

When tracing in Phase 5, resolve every service/DAO call through this file:
interface in code → bean id → concrete class in XML → then open the concrete
class. Never open an interface and stop.

---

## Part 3 — Traps

- **The XML overrides the code.** A default set in a setter can be overwritten by
  a `<property>`. Config values in XML/properties beat constants in Java.
- **Method-name-based transactions are load-bearing.** `save*` vs `find*` naming
  is not style — it decides transactional behaviour. A method renamed in the
  rewrite silently changes semantics. Record the patterns verbatim.
- **Proxies change `this` semantics.** A transactional bean calling its own
  method internally bypasses the proxy — a classic legacy bug/feature. If seen
  (self-invocation inside a transactional class), flag it in §13 of the page card.
- **Singleton beans + mutable fields = shared state.** Any instance field on a
  singleton service that is not a dependency is effectively a global variable
  shared across all users. Flag every one; these are concurrency bugs waiting
  and must not be copied into the new backend.
- **`getBean("...")` string lookups** hide dependencies from the XML diagram —
  grep for them (Phase 0's `java_classes.csv` + a targeted grep) and add them as
  edges.
- **JNDI resources** mean part of the config lives in the app server
  (`context.xml`, `server.xml`, WebSphere/WebLogic console). Record what is
  expected from JNDI and raise an `OQ` if the server config is not in the repo.
