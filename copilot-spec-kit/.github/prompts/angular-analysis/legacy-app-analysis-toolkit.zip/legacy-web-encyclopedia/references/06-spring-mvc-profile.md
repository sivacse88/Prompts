# Post-migration profile: Struts idioms on Spring MVC / Spring Boot

Use this profile when reconnaissance shows the app was migrated off Struts but
kept its architecture: Spring Boot + embedded container, JSP views composed by
Tiles 3, and a custom controller hierarchy that reproduces Struts patterns
(prepare/process action pairs, forward maps, form beans, token-based
double-submit guards, `.do` URL conventions). **This profile replaces
`01-struts-detection.md`'s artifact map** — the detection reference remains
useful only for recognising the residue.

## Where the truth lives now

| Question | Read |
|---|---|
| What URLs exist? | `@Controller`/`@RestController` classes + `@RequestMapping`/`@GetMapping`/`@PostMapping` annotations (scanner: `_raw/spring_mvc.csv`); PLUS the URL-rewrite config (e.g. tuckey `urlrewrite.xml`) that maps legacy `.do` URLs onto controllers; PLUS any `SimpleUrlHandlerMapping`/bean-name mappings in the Spring XML. A page's public URL and its handler method may be linked only through the rewrite rules — always resolve both directions. |
| What renders a page? | Tiles 3 definitions in the ACTIVE tiles file (the one referenced from the Spring config). If a legacy duplicate tiles file exists (old DTD), verify it is inert once, record the evidence, and never read it again. |
| The action pair | One page is typically served by a **Prepare** controller (GET: loads data, saves the double-submit token, seeds the form) and a **Process** controller (POST: validates token, runs `findForwardAndUpdate()`-style logic, forwards). Each member of the pair gets its own `ACT-###`; the page card §3 lists both and names the pattern. |
| Where does an action go next? | The base controller's **forward map**: `forwardTo("<name>")` call sites (scanner: rows in `_raw/forwards.csv` flagged `code-forwardTo`) resolved against the map's definition (Spring XML bean or code). Plus `CURRENT_PAGE`/`TARGET_PAGE`-style navigation parameters — treat these as data-driven edges and document the dispatch table that interprets them. |
| Form beans | Spring XML `<bean>` definitions and/or session attributes; the Struts-era lifecycle (reset/populate/validate) is reproduced in the base form classes — document where. |
| Validation | Commons-validator `validation.xml` still keyed by form name, plus any custom input-sanitisation filter (document in `cross-cutting/validation.md` and `security.md`). |
| Messages/errors | The Struts-replacement message classes (`ActionMessages`-alikes) and the custom error taglib. Map message keys to bundles as before. |

## Persistence: three paths, no SQL maps

There is no iBATIS/MyBatis XML. Phase 5 hop 7 (Persist) follows whichever of
these the service uses — a single page may use all three:

1. **JPA** — repository interfaces (`extends JpaRepository/CrudRepository`).
   The query is either a **derived method name** (`findByStatusAndCustomerId`
   → parse the name into predicates), a `@Query` annotation, or a named query.
   Column resolution goes through the entity: `@Table(name=)`, `@Column(name=)`;
   if `@Column` is absent, the column is the field name per the naming strategy —
   record which strategy and mark `confidence: medium`.
2. **JdbcTemplate / raw JDBC** — inline SQL strings in DAOs (scanner:
   `_raw/sql.csv`, `inline-java` rows). Trace as before.
3. **MongoDB** — `@Document(collection=)` classes + `MongoRepository`
   interfaces. The "table.column" in Template C/D becomes
   `collection.field`; keep them in the same reverse index but tag the store:
   `store: mongo | jdbc | jpa` — an extra column in Templates C and D under
   this profile. Every reverse-index row needs the store tag so the Angular
   API design knows which backend it is fronting.

## Extra rules for this profile

- **Exclude test resources.** Any config under `src/test/` (e.g. old
  struts-config fixtures) is invisible to the pipeline. The scanner skips them;
  if one is cited anywhere, that is a Gate 1 failure.
- **Backup/legacy files are evidence of history, not of behaviour.** Files like
  a `web-bkp.xml` or an old-DTD tiles duplicate may be read ONCE in Phase 1 to
  understand the migration, must be labelled `LEGACY REFERENCE — not deployed`
  wherever mentioned, and are never valid citations for current behaviour.
- **Dual UI generations.** If a feature-flag utility routes users to an
  alternate UI path (an "opted-in" check), then: (a) the flag check is a
  navigation precondition on every affected edge; (b) each affected page card
  §5 documents the states of BOTH generations or cites the sibling page; (c)
  the modernization slice plan must decide which generation is the parity
  target — raise it as a top-level decision, not a footnote.
- **Grid/table component forks.** A vendored table library (grids, sorting,
  paging, export) is a cross-cutting component: document its column-definition,
  paging, and export semantics once in `cross-cutting/layout-tiles.md`, and
  have page cards reference it instead of re-describing every grid.
- **Declared-but-unused frameworks.** For any UI/framework dependency in the
  build with no discovered usage (no subclass, no config, no import): run one
  targeted verification (grep imports + config), record the verdict in
  `00-architecture.md`, and keep an OQ open until a human confirms. Phase 3
  coverage cannot be declared complete while an unresolved UI framework OQ
  exists — it may mean pages exist outside the JSP inventory.
- **Monster JSPs are the norm, not the exception.** With inline `<%! %>`
  declarations, session reads, and business logic in scriptlets, apply the
  >1,500-line rule aggressively: batch of one, targeted section reads,
  and expect the Phase 5 trace for such pages to need 2–3 prompt runs each —
  plan the ledger rows accordingly (`PG-###/part1`, `part2`).

## What carries over unchanged

The ID scheme, ledger, id-counters, page-card template, nine navigation
discovery sources, eight field-trace hops, quality gates, and the phase
structure all apply as written. Only the artifact map above and the
persistence tracing rules replace their Struts-era equivalents.
