# Framework detection and artifact map

Run this in Phase 1. It answers "which Struts is this?" and tells every later
phase which files carry the truth.

## Detection decision tree

Check in this order and stop at the first match. Record the result in
`00-architecture.md` under "Framework".

| Signal | Verdict |
|---|---|
| `web.xml` maps `org.apache.struts.action.ActionServlet` | **Struts 1.x** |
| `web.xml` maps `org.apache.struts2.dispatcher.filter.StrutsPrepareAndExecuteFilter` or `.ng.filter.StrutsPrepareAndExecuteFilter` or `FilterDispatcher` | **Struts 2.x** |
| `struts-config*.xml` present with `<action-mappings>` | **Struts 1.x** |
| `struts.xml` / `struts.properties` present with `<package extends="struts-default">` | **Struts 2.x** |
| Classes extend `org.apache.struts.action.Action` / `DispatchAction` / `LookupDispatchAction` | **Struts 1.x** |
| Classes extend `ActionSupport` or implement `com.opensymphony.xwork2.Action` | **Struts 2.x** |
| `<%@ taglib uri="http://struts.apache.org/tags-html" %>` | Struts 1.x taglibs |
| `<%@ taglib prefix="s" uri="/struts-tags" %>` | Struts 2 taglibs |
| Both present | **Hybrid** — document the boundary explicitly; it is usually a migration that stalled. Record which modules use which. |

Also record the version precisely: check `pom.xml` / `build.xml` / `WEB-INF/lib/struts*.jar`
filenames. Version matters — Struts 1.3 vs 1.2 differ in `ActionRedirect`, and
Struts 2.3 vs 2.5 differ in namespace/wildcard handling and OGNL restrictions.

## Struts 1.x artifact map

| Question | Read |
|---|---|
| What URLs exist? | `struts-config*.xml` → `<action path=... type=... name=... input=... scope=... validate=...>` |
| Where does an action go next? | `<forward name= path= redirect=>` inside the action, plus `<global-forwards>` |
| What is the form's shape? | `<form-bean name= type=>` → the `ActionForm` subclass, or `<form-property>` for `DynaActionForm` |
| Validation rules | `validation.xml` + `validator-rules.xml`, keyed by form-bean name; plus `ActionForm.validate()` overrides |
| Page composition | `tiles-defs.xml` / `tiles.xml` → `<definition name= extends= template=>` and `<put name= value=>` |
| Which JSP renders | The forward `path`, resolved through Tiles definitions if the path is a definition name, not a `.jsp` |
| Multi-method actions | `DispatchAction` (`parameter=` attribute on the mapping selects the method), `LookupDispatchAction` (`getKeyMethodMap()`), `MappingDispatchAction` (`parameter=` is the method name) |
| Request→form binding | Automatic by JavaBean property name matching request parameter names |
| Labels / i18n | `ApplicationResources*.properties` via `<bean:message key=>` |
| Exception routing | `<exception key= type= path=>` global and per-action |
| Plugins | `<plug-in className=>` — often Tiles, Validator, or a Spring `ContextLoaderPlugIn` |

**Struts 1 gotchas to look for explicitly:**

- `DispatchAction` with `parameter="method"` means one mapping = N logical actions.
  Each dispatch method gets its own `ACT-###`.
- `scope="session"` form beans persist state across pages — a major source of
  hidden data flow. Flag every one.
- `<html:link forward="...">` and `<html:link action="...">` are navigation edges
  that never appear as a literal URL.
- `input="..."` is the validation-failure return path — an edge that only fires
  on error.
- `redirect="true"` loses request attributes; `redirect="false"` (default) keeps them.
  This distinction changes what data the target page can see.

## Struts 2.x artifact map

| Question | Read |
|---|---|
| What URLs exist? | `struts.xml` and any `<include file=>` chain → `<package namespace=>` + `<action name= class= method=>` |
| Annotation-configured actions | `@Action`, `@Actions`, `@Namespace`, `@Result`, `@ResultPath` on action classes (Convention plugin) |
| Convention-based actions | Convention plugin: `struts.convention.action.packages`; class `FooAction` → `/foo`; results resolved from `WEB-INF/content/` by naming |
| Where does an action go next? | `<result name= type=>` — types: `dispatcher`, `redirect`, `redirectAction`, `chain`, `tiles`, `stream`, `json` |
| Form binding | Action properties directly, or `ModelDriven<T>.getModel()`, or `@Autowired` params. OGNL expressions in `<s:textfield name="user.address.city">` create nested objects. |
| Validation | `<ActionName>-validation.xml`, `<ActionName>-<alias>-validation.xml`, `@Validations` annotations, `validate()` override, and the `validation` interceptor's position in the stack |
| Interceptors | `<interceptor-stack>` definitions and `<default-interceptor-ref>`. `params`, `prepare`, `token`, `workflow`, `fileUpload` all change data flow. |
| Wildcards | `<action name="*Invoice" method="{1}">` — one mapping = many URLs. Enumerate them. |
| Labels / i18n | `package.properties`, `<ActionName>.properties`, `global.properties` via `<s:text name=>` / `getText()` |
| Exception routing | `<global-exception-mappings>` and `<exception-mapping>` |

**Struts 2 gotchas to look for explicitly:**

- Wildcard mappings and namespaces mean the URL set is generated, not listed.
  Expand every wildcard against the actual method set of the action class.
- `chain` results carry the whole ValueStack forward — a hidden data-flow edge.
- `redirectAction` vs `redirect` vs `dispatcher` changes both the URL bar and the
  surviving data.
- `ModelDriven` hides the real field owner; the JSP names look like action
  properties but bind to the model.
- Interceptor stack order determines whether validation runs before or after
  `prepare()`. Read the stack, don't assume the default.

## Common to both — surrounding stack to identify in Phase 1

Record each of these with the evidence file, because they define the layers the
field trace must walk:

- **Persistence**: raw JDBC / iBATIS / MyBatis (`sqlmap*.xml`, `*Mapper.xml`) /
  Hibernate (`*.hbm.xml`, `@Entity`) / Spring JdbcTemplate / stored procedures.
- **Service layer**: Spring beans (`applicationContext*.xml`), EJB (`ejb-jar.xml`),
  or plain singletons/static helpers.
- **Security**: container `<security-constraint>` in `web.xml`, a custom Filter,
  Spring Security, or role checks inline in Actions/JSPs.
- **Session/state**: `HttpSession` attribute names — grep them; they are the
  invisible data bus of most Struts apps.
- **Client-side navigation**: `window.location`, `form.action=`, `form.submit()`,
  `<a href>` built in JS. These are navigation edges invisible to config parsing.
- **Legacy inclusions**: `<jsp:include>`, `<%@ include file>`, scriptlets, iframes,
  frameset pages.
- **Reporting/exports**: Jasper, POI, servlet-written CSV/PDF — these are pages
  with no JSP.
- **Async/batch**: quartz jobs, servlet timers, message listeners that write the
  same tables the screens read. Needed for the DB reverse index to be honest.

## Output of Phase 1 detection

Write to `00-architecture.md`:

```markdown
## Framework
- Struts **1.3.10** `WEB-INF/lib/struts-core-1.3.10.jar`, `web.xml:22-31`
- Config split across 6 files `conf/struts-config.xml (<include>)`
- Tiles: yes, `conf/tiles-defs.xml`, 41 definitions
- Validator: yes, `conf/validation.xml`
- Persistence: iBATIS 2.3 `conf/sqlmap-config.xml`
- Service layer: Spring 2.5 `conf/applicationContext.xml`
- Security: container-managed + custom `AuthFilter` `src/.../AuthFilter.java:40`
- Client-side nav: 118 `form.submit()` call sites (see `_raw/js_nav.csv`)
```
