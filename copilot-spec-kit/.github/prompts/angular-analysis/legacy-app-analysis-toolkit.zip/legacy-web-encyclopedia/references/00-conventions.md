# Conventions

Copy this file to `docs/encyclopedia/_meta/conventions.md` in the target repo at
the start of Phase 1. It is the contract every later phase depends on.

## 1. ID scheme

IDs are assigned once and never reused, renumbered, or deleted. If an artifact
turns out to be dead code, keep the ID and mark `status: dead`.

| Prefix | Applies to | Assigned in | Example |
|---|---|---|---|
| `MOD-##` | Functional module / bounded area | Phase 1 | `MOD-03` |
| `PG-###` | A distinct user-visible screen | Phase 2 | `PG-047` |
| `ACT-###` | A Struts action mapping | Phase 2 | `ACT-112` |
| `FRM-###` | A form bean (ActionForm / POJO) | Phase 2 | `FRM-031` |
| `FLD-#####` | One field on one page | Phase 5 | `FLD-00412` |
| `NAV-###` | One directed navigation edge | Phase 4 | `NAV-208` |
| `FL-##` | A named business flow (multi-page) | Phase 3 | `FL-07` |
| `SVC-###` | Service / business-logic class | Phase 5 | `SVC-022` |
| `DAO-###` | Persistence class | Phase 5 | `DAO-018` |
| `MS-##` | Modernization slice | Phase 8 | `MS-04` |
| `OQ-###` | Open question | any | `OQ-055` |

**A "page" is a screen the user perceives, not a JSP file.** One JSP included by
Tiles into three layouts is one page if the user sees one screen. One JSP that
renders three mutually exclusive states via `<logic:equal>` is one page with three
documented states. A Tiles fragment reused by many pages is **not** a page — it is
a component, documented in `cross-cutting/layout-tiles.md`.

## 2. File naming

- Page card: `modules/MOD-03-billing/pages/PG-047-invoice-search.md`
- Slug = lowercase kebab-case of the page's business name, not the JSP filename.
- Never rename a file after creation. If the name is wrong, add
  `title:` front matter with the correct name and leave the file where it is.

## 3. Front matter

Every generated markdown file starts with YAML front matter:

```yaml
---
id: PG-047
type: page
title: Invoice Search
module: MOD-03
status: draft | reviewed | dead
phase_completed: [2, 3]
sources:
  - web/billing/invoiceSearch.jsp
  - src/com/acme/billing/action/InvoiceSearchAction.java
  - conf/struts-config-billing.xml
confidence: high | medium | low
last_updated: 2026-08-01
---
```

`phase_completed` is how Phase 7 finds unfinished work. Append to it; never
overwrite.

## 4. Citation format

Inline, immediately after the claim, in backticks:

> The `customerId` parameter is trimmed and upper-cased before lookup
> `src/com/acme/billing/action/InvoiceSearchAction.java:88-91`.

Rules:

- Path is repo-relative, always forward slashes.
- Line ranges use a hyphen. Single lines have no range.
- XML config cites the file plus the `path`/`name` attribute value, since line
  numbers in generated config are unstable: `conf/struts-config.xml (path=/invoiceSearch)`.
- SQL in `.xml` mapper files cites the statement id:
  `conf/sqlmap/Invoice.xml (id=selectInvoicesByCustomer)`.

## 5. UNKNOWN protocol

When evidence is missing, write exactly:

```
UNKNOWN — <what is unknown> — OQ-###
```

and append a row to `_meta/open-questions.md`:

| OQ | Question | Raised by | Blocking | Owner | Status |
|---|---|---|---|---|---|
| OQ-055 | Is `flagB` ever set outside batch job? | PG-047 | MS-04 | — | open |

Never guess. A wrong fact in the encyclopedia is more expensive than a gap,
because the Angular rewrite will encode it.

## 6. Ledger format

`_meta/ledger.md` — append-only, one row per completed unit of work:

```
| ts | phase | unit | status | output | notes |
|---|---|---|---|---|---|
| 2026-08-01T10:12 | 3 | PG-047 | done | modules/MOD-03-billing/pages/PG-047-invoice-search.md | 2 UNKNOWNs |
| 2026-08-01T10:31 | 3 | PG-048 | partial | ... | BUDGET_EXCEEDED, DAO layer not traced |
```

Every prompt begins with "read the ledger" and ends with "append to the ledger".

## 6b. ID counters

The ledger tracks *work*; `_meta/id-counters.md` tracks *numbering*. It is the
only source of truth for the next free ID:

```
| prefix | next |
|---|---|
| PG | 048 |
| ACT | 114 |
| FLD | 00413 |
| NAV | 213 |
| OQ | 056 |
```

Every prompt that assigns IDs must: read this table first, take the numbers it
needs, and rewrite the rows it consumed before finishing. Never derive the next
ID by scanning output files. The series assumes a **single operator running
prompts sequentially** — if the team parallelises, partition ID ranges per
person up front (e.g. person A gets FLD-00001–09999) and note it here.

## 7. Context budget discipline

- Never use `@workspace` for Phases 2–6. It pulls unbounded context. Attach
  explicit files (`#file:`) only.
- Hard cap: **12 source files open per prompt** (Phase 6 topics may use 20 —
  each prompt states its own cap, which wins). The cap is always **per prompt,
  never per page**: if a 2-page batch can't fit, do one page and mark the other
  pending. If a single page needs more, split it into `PG-047` (UI + action) and
  a continuation prompt (service + DAO).
- Never paste source code into the output document. Cite it. Exception: a SQL
  statement or a validation rule may be quoted if it is ≤10 lines and is the
  answer itself.
- Never re-read a file that a previous phase already summarised. Read the
  summary.
- **Oversized files count double.** A JSP or class over ~1,500 lines: process it
  alone (batch of 1), and read it in targeted sections (forms, then links, then
  scriptlets — the `_raw` CSVs give the line numbers), not top to bottom.
- **Append-only shared files.** Files that many prompts contribute to
  (`db-reverse-index-MOD-##.md`, `domain-objects-MOD-##.md`, ledger, counters)
  are appended without reading their existing content. Deduplication happens
  once, in the consolidation prompts — never in the loop prompts.
- If the model starts summarising prior chat turns, the session is over. Start a
  fresh chat and resume from the ledger.

## 8. Sanitization (identity-free deliverables)

The corpus has two tiers with different rules:

**Tier 1 — internal encyclopedia** (everything except `modernization/`):
citations use real repo paths and class names, because evidence must resolve.
But **prose, titles, ids, and file names** never contain the organisation name,
application registry identifiers, or internal application codenames. Refer to
the system as "the application"; refer to features by business function
("contribution entry", "grant search"), never by internal branding.

**Tier 2 — modernization packets** (`modernization/*.md`): fully identity-free.
These are the hand-off deliverables. No repo paths, no package or class names,
no organisation/app tokens anywhere. All references to legacy artifacts go
through IDs only (`PG-###`, `ACT-###`, `FLD-#####`) — the ID→artifact mapping
already lives in the Tier 1 page cards, so nothing is lost.

The banned-token list lives in `_meta/sanitization.md` (one token per line as a
list item; case-insensitive substring match). Seed it in Phase 1 with: the
organisation name and abbreviations, application registry ids (e.g. `ap` /
`PR` + digits patterns), the deployment context path, internal codenames, and
the corporate package root. `scripts/audit_coverage.py` scans `modernization/`
against this list; any hit is a Gate 5 failure.

## 9. Terminology to keep consistent

- **Entry point** — a URL a user can hit without first visiting another app page
  (bookmark, email link, external system, menu, portal).
- **Inbound path** — one distinct way of arriving at a page, including the
  originating page, the trigger, and the preconditions.
- **State** — a visually/functionally distinct rendering of the same page
  (create vs. edit vs. read-only vs. error).
- **Field** — one input, output, or hidden data element bound to a page state.
