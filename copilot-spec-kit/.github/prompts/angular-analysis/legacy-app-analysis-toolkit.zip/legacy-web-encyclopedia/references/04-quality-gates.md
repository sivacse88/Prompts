# Quality gates

## Gate 1 — Per-artifact checklist (apply before writing the ledger row)

A page card passes only if all are true:

- [ ] Front matter complete; `sources` lists every file actually read.
- [ ] Every section present (`n/a` with a reason counts as present).
- [ ] Every factual claim has a citation, or says `UNKNOWN — … — OQ-###`.
- [ ] §8 inbound paths states which of the nine discovery sources were checked.
- [ ] Every action in §3 has an outbound edge in §9 for each of its forwards/results.
- [ ] Every field in §6 has a `FLD-` id, and the ids are contiguous with the last
      assigned id.
- [ ] §13 has at least one entry, or explicitly states "no non-obvious behaviour".
- [ ] No source code pasted beyond the 10-line exception.
- [ ] Every `UNKNOWN` has a matching row in `_meta/open-questions.md`.

## Gate 2 — Phase 4 graph consistency

- [ ] Every `PG-###` appears in `navigation/inbound-index.md`, even if the inbound
      list is empty (empty = orphan, flag it).
- [ ] Every edge is bidirectionally consistent: if PG-A lists an outbound to PG-B,
      PG-B's card lists the corresponding inbound.
- [ ] Orphans reported: pages with no inbound edge and not in `entrypoints.md`.
      Likely dead code — verify before deleting from the rewrite scope.
- [ ] Unreachable actions reported: `ACT` with no edge pointing at it.
- [ ] Cycles identified and labelled (self-loop on validation error is normal;
      others need a note).

## Gate 3 — Phase 5 data consistency

- [ ] Every `FLD` row has a non-empty **Bind** and **Type/format**.
- [ ] Column set in `field-index.md` == column set in `db-reverse-index.md`.
- [ ] Every table in the reverse index has at least one writer, or is marked
      `read-only / populated externally`.
- [ ] Every session attribute in any page card §12 appears in
      `cross-cutting/session.md`.
- [ ] Every form bean has a documented scope and reset behaviour.

## Gate 4 — Phase 7 gap sweep (the audit)

Run these mechanically, then reconcile:

1. **Coverage.** Count JSPs in `_raw/jsp.csv` vs pages documented. Every JSP is
   either a `PG`, a fragment listed in `layout-tiles.md`, or in the "excluded"
   list in `coverage.md` with a reason. No JSP is unaccounted for.
2. Same for action mappings, form beans, and DAO methods.
3. **Citation spot-check.** Sample 10 random citations across the corpus; open the
   file and confirm the cited lines say what the document claims. Report the
   error rate. If >10%, re-run the affected phase.
4. **Contradiction scan.** Search for the same field or table described
   differently in two files. Reconcile or raise an `OQ`.
5. **Confidence audit.** List every artifact with `confidence: low` and every open
   `OQ`, grouped by the modernization slice they block. This becomes the SME
   interview agenda.
6. **Freshness.** Any file whose `sources` include a file modified after
   `last_updated` is stale — re-run it.

Write the result to `_meta/coverage.md` as a table, plus a top-level pass/fail.

## Gate 5 — Phase 8 packet readiness

A modernization packet is ready to hand to a developer only if:

- [ ] Zero open `OQ`s marked `blocking: MS-##` for this slice.
- [ ] Every page in scope has `status: reviewed`.
- [ ] Every inbound path in scope maps to a planned Angular route, including
      deep links and external bookmarks.
- [ ] Acceptance tests cover every state in §5 and every rule in §7 of each page.
- [ ] The API contract covers every action in scope, with request/response shapes.
- [ ] The traceability table maps every `PG`, `ACT`, and `FLD` in scope to its
      replacement, or explicitly drops it with a reason.
- [ ] Sanitization: the packet contains zero tokens from `_meta/sanitization.md`
      and zero repo paths / package / class names (conventions §8 Tier 2).
      Verified mechanically by `scripts/audit_coverage.py`.

## Anti-patterns to reject in review

- "This action probably handles X" — no citation, no claim.
- A page card that describes the JSP's HTML structure instead of the user's task.
- Field tables that stop at the form bean.
- Navigation lists built only from `struts-config.xml` (misses JS, misses menus).
- A single `encyclopedia.md` file. It will exceed the context window and become
  unmaintainable — the whole design is many small files.
- Renaming or renumbering IDs "for tidiness". Never.
