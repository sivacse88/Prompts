# Tracing rules

The two hard problems are (a) finding *every* way to reach a page and (b) following
a field all the way to a column. These are the rules that make both complete.

---

## Part 1 — Navigation edge discovery

A page's inbound list is complete only when all nine sources below have been
checked. Record which sources were checked in the page card, so Phase 7 can
verify. An unchecked source is a silent gap.

### Source 1 — Config forwards
Struts 1: every `<forward path="X">` where `X` resolves to this page, including
`<global-forwards>`. Struts 2: every `<result>` whose value resolves here,
including `redirectAction` and `chain`.
Grep the JSP path *and* its Tiles definition name *and* the action path that
renders it — a forward may target any of the three.

### Source 2 — Taglib links
- Struts 1: `<html:link forward=|action=|page=|href=>`, `<html:form action=>`,
  `<html:frame>`, `<html:rewrite>`.
- Struts 2: `<s:url>`, `<s:a>`, `<s:form action= namespace=>`, `<s:submit action=>`.
Note that `<s:submit action="foo">` produces `method:foo` semantics — one button
per logical action.

### Source 3 — Raw HTML
`<a href>`, `<form action>`, `<iframe src>`, `<frame src>`, `<meta refresh>`,
`<area href>` in image maps. Old apps hide navigation in framesets.

### Source 4 — JavaScript
`window.location(.href)=`, `window.open(`, `location.replace(`,
`document.forms[..].action=` followed by `.submit()`, `form.submit()`,
jQuery `.attr('action',` / `$.post(` / `$.ajax({url:`.
This is where the *conditional* navigation lives: `if (rows>0) go to A else B`.
Capture the condition, not just the target — it is a precondition on the edge.

### Source 5 — Server-side redirects
`response.sendRedirect(`, `RequestDispatcher.forward(`, `ActionRedirect`,
`ServletActionRedirectResult`. Grep the Java and the JSP scriptlets.

### Source 6 — Error and validation routing
The `input=` attribute (S1) / `input` result (S2), `<exception path=>` /
`global-exception-mappings`, and `web.xml` `<error-page>`. These edges only fire
on failure, so they are missed by happy-path reading, but the Angular app must
reproduce them.

### Source 7 — Menu, portal, and security config
Menu definition files (XML, DB table, properties), site maps, role→menu tables,
external portal links, and `web.xml` `<welcome-file-list>`. Also check whether
the menu is data-driven — if so, the DB table *is* part of the navigation graph.

### Source 8 — Direct URL / deep links
Any action with `validate="false"` and no referer check is reachable by URL.
Determine and record: does the page function correctly when entered directly,
or does it depend on session state set by a predecessor? This single fact
decides whether the Angular route needs resolvable route params.

### Source 9 — Non-UI callers
Batch jobs, scheduled tasks, other applications, and email templates that link
into the app. Grep for the app's context path in `.properties`, `.sql`, and
templates.

### Edge record — required attributes
Every `NAV-###` records: **from**, **to**, **trigger** (what the user does),
**mechanism** (which of the nine sources, with citation), **precondition**
(role, state, data), **data carried** (params, request attrs, session keys),
and **redirect vs forward** (does the URL change; do request attributes survive).

### Hard cases

| Case | Rule |
|---|---|
| `DispatchAction` | Each dispatch method is a separate `ACT`. Edges point at the method, not the mapping. |
| Wildcard mapping (S2) | Expand against the action class's public no-arg methods. Enumerate every resulting URL. |
| Tiles | A forward to a Tiles definition name is an edge to the page the definition renders. Resolve `extends` chains before deciding. |
| Frameset pages | The frameset is a page; each frame's initial `src` is an edge from it. |
| Same JSP, many actions | Still one page, many `ACT`s, many edges. |
| Same action, many JSPs | Multiple forwards → the action is a router. Document the branch condition per forward. |
| Chained/`chain` result | An edge *and* a data-flow edge — the ValueStack survives. |
| Popup windows | Edge with `mechanism: window.open`, and note the opener/child data exchange (`window.opener.document...`). Angular will need a dialog or a route with a return value. |
| Browser back / re-post | Note token-based double-submit guards (`<html:form>` + `saveToken`/`isTokenValid`, or the S2 `token` interceptor). |

---

## Part 2 — Field-level data flow

### The eight hops

For each field, walk and record every hop. Stop only at a table column, an
external system, or a proven dead end.

1. **Render** — where the value on screen comes from on initial display
   (form bean prefill, request attribute, session, lookup query, hardcoded).
2. **Control** — the HTML control, its constraints (maxlength, readonly,
   disabled, hidden), and its client-side formatting/masking JS.
3. **Bind** — the request parameter name → form property. Note type conversion
   (String→Date via `DateConverter`, locale-sensitive number parsing) and what
   happens on conversion failure.
4. **Validate** — declarative rules, `validate()` code, and server-side business
   checks in the Action. Record the message key and the failure destination.
5. **Transform in** — trim, case, pad, default, derive, encrypt, concatenate.
   Cite each transformation site in order.
6. **Service** — the parameter it becomes on the service call; any further
   derivation or defaulting; any cross-field rule that consumes it.
   **Resolve the concrete class through `02-spring-wiring.md`** — the interface
   in the Java code is not the implementation; the Spring XML decides. Note when
   the call crosses a transaction or AOP proxy (the wiring map's method-name
   patterns tell you), because that is a semantic boundary the new API must keep.
7. **Persist** — the DAO method and the SQL. Record the exact column, and whether
   the write is insert/update/conditional. For dynamic SQL, cite the builder and
   enumerate the reachable column set.
8. **Transform out** — formatting on the return trip (date pattern, currency,
   truncation, masking of sensitive values, null→blank).

### Classify every field
`input` · `display-only` · `hidden-state` · `derived` · `lookup-driven` ·
`transient` (never persisted) · `audit` (set by framework/trigger, not user).

Hidden fields deserve extra care: they usually carry the primary key or an
optimistic-lock version, and they are the most commonly missed data flow.

### Dynamic SQL
When the column set depends on runtime conditions (iBATIS `<isNotNull>`,
MyBatis `<if>`, string-concatenated SQL), do **not** guess. Enumerate every
branch and list the union of columns, marking each with its condition. If the
SQL is built by string concatenation across methods, record the builder location
and mark `confidence: low`.

### Stored procedures and triggers
If a write goes through a proc or a table has triggers, the column list from the
SQL is incomplete. Note it, add an `OQ`, and — if DDL is available — read it.

### Cross-field and cross-page rules
Record rules that involve more than one field (`dateFrom ≤ dateTo`, "if type=X
then Y is required") on the page card §7, and reference them from each
participating field row. The Angular form will need them as form-group validators.

### Session-carried fields
Any field whose value survives via `HttpSession` is a data flow the config does
not show. For each session attribute: who writes it, who reads it, when it is
cleared, and what breaks if it is absent. Session-scoped `ActionForm`s in Struts 1
are the single biggest source of surprise behaviour — enumerate them all in
`cross-cutting/session.md`.

### Reverse index construction
While tracing, append to `data/db-reverse-index.md` immediately — one row per
`table.column` touched, with the `PG-###`/`ACT-###` and read/write. Building the
reverse index at the end from memory is not possible; build it incrementally.
After Phase 5, run a consistency check: every column referenced in
`field-index.md` must exist in the reverse index and vice versa.

---

## Part 3 — What to deliberately ignore

To protect the budget, do not document:

- Struts framework internals, taglib implementations, or library source.
- CSS, images, static assets — except where CSS classes encode behaviour
  (conditional show/hide).
- Generated code and vendor directories.
- Commented-out blocks — unless a block is the only explanation for a mystery,
  in which case cite it and mark it commented.
- Log statements, unless a log line reveals a branch that is otherwise invisible.

Record anything skipped in `_meta/coverage.md` so the omission is a decision,
not an accident.
