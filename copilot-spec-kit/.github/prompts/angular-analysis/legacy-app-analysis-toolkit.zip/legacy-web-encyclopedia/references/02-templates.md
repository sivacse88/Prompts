# Output templates

Fill every section. If a section does not apply, write `n/a` and why. Never
delete a section — Phase 7 checks for their presence.

---

## Template A — Page card (`modules/MOD-##-x/pages/PG-###-slug.md`)

```markdown
---
id: PG-047
type: page
title: Invoice Search
module: MOD-03
status: draft
phase_completed: [2, 3]
sources: []
confidence: high
last_updated: 2026-08-01
---

# PG-047 — Invoice Search

## 1. Purpose
Two or three sentences, in business language, on what a user accomplishes here.
No framework vocabulary.

## 2. Renders
| Artifact | Path | Note |
|---|---|---|
| JSP | `web/billing/invoiceSearch.jsp` | |
| Tiles definition | `billing.invoiceSearch` `conf/tiles-defs.xml` | extends `base.twoColumn` |
| Fragments included | `web/common/pagingBar.jsp` | shared, see layout-tiles.md |

## 3. Actions bound to this page
| ACT | URL | Class#method | HTTP | Purpose |
|---|---|---|---|---|
| ACT-112 | `/billing/invoiceSearch.do?method=display` | `InvoiceSearchAction#display` | GET | initial render |
| ACT-113 | `/billing/invoiceSearch.do?method=search` | `InvoiceSearchAction#search` | POST | run search |

## 4. Form bean / model
| FRM | Class | Scope | Populated by | Reset behaviour |
|---|---|---|---|---|
| FRM-031 | `InvoiceSearchForm` | session | request params + `display()` prefill | `reset()` clears checkboxes only `...Form.java:44` |

## 5. States
| State | Trigger | Visible difference | Fields affected |
|---|---|---|---|
| Initial | first entry, no results | result grid hidden | — |
| Results | search returned ≥1 row | grid + paging bar | `resultList`, `totalCount` |
| Empty | search returned 0 | "no records" message | — |
| Error | validation failure | field-level errors | see §7 |

## 6. Fields (summary — full trace in `data/field-index.md`)
| FLD | Label | Type | Bound to | Required | Source of values | Persisted to |
|---|---|---|---|---|---|---|
| FLD-00412 | Customer ID | text | `FRM-031.customerId` | Y | user | not persisted (query only) |
| FLD-00413 | Status | select | `FRM-031.statusCode` | N | `REF_STATUS` lookup `DAO-018` | — |

## 7. Validation and business rules
| Rule | Where enforced | Message key | Effect on failure |
|---|---|---|---|
| customerId required | `validation.xml (form=invoiceSearchForm)` | `errors.required` | return to `input` = this page |
| dateFrom ≤ dateTo | `InvoiceSearchAction.java:120-128` | `errors.dateRange` | same |

## 8. Inbound paths (all ways to reach this page)
| NAV | From | Trigger | Mechanism | Preconditions | Data carried in |
|---|---|---|---|---|---|
| NAV-208 | PG-002 Main Menu | click "Invoice Search" | `<html:link forward="invoiceSearch">` | role BILLING_VIEW | none |
| NAV-209 | PG-051 Customer Detail | button "Invoices" | `form.submit()` in `custDetail.js:88` | customer selected | `customerId` request param |
| NAV-210 | external | bookmark / email link | direct URL | authenticated session | full query string |
| NAV-211 | PG-047 itself | validation failure | `input=` forward | — | full form, session-scoped |

## 9. Outbound paths
| NAV | To | Trigger | Mechanism | Data carried out |
|---|---|---|---|---|
| NAV-212 | PG-052 Invoice Detail | click row link | `<html:link action="/invoiceDetail">` | `invoiceId` |

## 10. Backend call chain
```
ACT-113 InvoiceSearchAction#search
  → SVC-022 InvoiceService.search(InvoiceCriteria)   `InvoiceService.java:61`
    → DAO-018 InvoiceDao.findByCriteria()            `InvoiceDao.java:143`
      → SQL  `conf/sqlmap/Invoice.xml (id=selectInvoicesByCriteria)`
        → reads INVOICE, CUSTOMER, REF_STATUS
```

## 11. Security
Roles required, how enforced, and any field-level or button-level authorisation.

## 12. Session read/written
| Attribute | Read | Written | Removed | Purpose |
|---|---|---|---|---|
| `USER_CTX` | ✓ | | | current user, org filter |
| `invoiceSearchForm` | ✓ | ✓ | on logout | sticky search criteria |

## 13. Behaviours a rewrite must preserve
Bullet list of non-obvious behaviour: sticky filters, default sort, implicit
org-level row filtering, max result cap, browser-back tolerance, double-submit
token, export limits.

## 14. Known issues / dead code
## 15. Open questions
| OQ-055 | ... |
```

---

## Template B — Flow (`modules/MOD-##-x/flows/FL-##-slug.md`)

For multi-page business processes (wizards, approval chains).

```markdown
# FL-07 — Create and Approve Invoice

## Participants
Roles and systems involved.

## Page sequence
```mermaid
graph LR
  PG002[PG-002 Menu] --> PG047[PG-047 Search]
  PG047 --> PG052[PG-052 Detail]
  PG052 -->|Submit| PG060[PG-060 Approval]
  PG060 -->|Reject| PG052
```

## Step table
| # | Page | Actor | Action | State change | Persisted |
|---|---|---|---|---|---|

## State machine
Entity + status column + legal transitions + who may perform each.

## Data accumulated across steps
Where partial data lives between steps (session, staging table, hidden fields).

## Abandonment / timeout behaviour
## Concurrency behaviour (two users, same record)
## Transaction boundaries
```

---

## Template C — Field index row (`data/field-index.md`)

One row per field per page. Wide table; keep it a single file per module if it
grows beyond ~500 rows (`data/field-index-MOD-03.md`).

```markdown
| FLD | Page | Label | UI control | Form property | Type/format | Req | Validation | Transform in | Service param | DAO/SQL | Table.Column | Transform out | Notes |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| FLD-00412 | PG-047 | Customer ID | text(10) | `InvoiceSearchForm.customerId` | String, `^[A-Z0-9]{4,10}$` | Y | required + mask `validation.xml` | `trim().toUpperCase()` `Action:88` | `InvoiceCriteria.customerId` | `selectInvoicesByCriteria` | `CUSTOMER.CUST_CD` | — | read-only filter |
```

Column meanings:

- **Transform in** — every mutation between the browser and the DB, in order.
- **Transform out** — formatting applied on the way back to the screen
  (date patterns, currency, masking, truncation).
- **Table.Column** — `UNKNOWN` if the SQL is dynamic; then cite the builder.

---

## Template D — DB reverse index (`data/db-reverse-index.md`)

```markdown
## CUSTOMER
| Column | Type | Read by | Written by | Business meaning | Notes |
|---|---|---|---|---|---|
| CUST_CD | VARCHAR2(10) | PG-047, PG-051, PG-060 | PG-051 (ACT-140) | Customer code, natural key | also written by batch `NightlySyncJob.java:77` |
```

Every column that appears in any traced SQL gets a row, including columns only
touched by batch jobs — mark those `no screen`.

---

## Template E — Modernization packet (`modernization/MS-##-feature.md`)

This is the artifact handed to whoever builds the Angular feature.

```markdown
# MS-04 — Invoice Search & Detail

## Scope
Pages: PG-047, PG-052. Flows: FL-07 (steps 1-3).
Out of scope: approval (MS-05).

## Why this slice, why now
Dependencies on other slices, and what unblocks after it.

## Behavioural specification
The full set of "must preserve" behaviours, lifted from §13 of each page card,
restated as testable statements.

## Screen specification
Per page: purpose, states, layout intent (not pixel layout), field list with
type/format/required/validation, actions and their outcomes, empty/error states.

## API contract needed
| Endpoint | Method | Request | Response | Replaces | Notes |
|---|---|---|---|---|---|
| `/api/invoices/search` | POST | `InvoiceSearchRequest` | `Page<InvoiceSummary>` | ACT-113 | server-side paging, cap 500 |

Include the JSON shapes. Derive field names from business meaning, not legacy
column names, but keep a mapping table back to `FLD-###`.

## Data contract
Tables/columns touched, read vs write, and the transformations that must move
to the API layer.

## Navigation contract
Inbound paths that must still work (including deep links and external bookmarks)
and the Angular route that serves each.

## Authorisation
Roles, and what each role can see/do at field and action granularity.

## Acceptance tests
Given/When/Then derived from §5 states, §7 rules, and §13 behaviours.

## Parity risks
Behaviour that is expensive or undesirable to replicate; decision needed.

## Traceability
| Legacy | New |
|---|---|
| PG-047 | `/billing/invoices` |
| ACT-113 | `POST /api/invoices/search` |
| FLD-00412 | `searchForm.customerCode` |
```

**Sanitization rule for Template E (see conventions §8):** packets are
identity-free. Legacy artifacts appear as IDs only — never as repo paths,
package names, class names, or any organisation/application token. If a fact
needs legacy detail, cite the page card ID; the reader with repo access
resolves it there.
