# Prompt series — incremental legacy-app encyclopedia (v3)

> **Active profile: post-Struts Spring MVC** (set by reconnaissance). The app
> was migrated from Struts 1.x to Spring Boot but kept Struts idioms:
> prepare/process controller pairs, forward maps, form beans, token guards,
> `.do` URLs, Tiles 3, JSP views. Wherever a prompt below references
> `01-struts-detection.md`'s artifact map, **`06-spring-mvc-profile.md`
> replaces it**. Persistence is JPA + JdbcTemplate + MongoDB (no SQL maps);
> Templates C and D gain a `store` column. Test resources are excluded from
> everything. Sanitization rules (conventions §8) apply: internal docs keep
> real citations, `modernization/` packets are identity-free.

Copy one prompt at a time into Copilot Chat (**agent mode**). One chat = one
prompt. Start a fresh chat for every prompt unless stated otherwise.

## Model assignment (complete table)

| Prompt | Model | Why |
|---|---|---|
| 0 (scan), 7.0 (audit script) | none | scripts |
| 1.1 architecture & lifecycle | **Sonnet** | checklist-driven inventory |
| 1.2 Spring/DI wiring map | **Opus** | resolving indirection (proxies, two contexts, bridges) is where cheap models guess |
| 1.3 technical setup | **Sonnet** | inventory work |
| 1.4 module partition | **Opus** | judgement call that everything downstream inherits |
| 2.N module inventory | **Sonnet** | template filling from config |
| 2.Z inventory reconcile | **Opus** | cross-file consistency reasoning |
| 3.N page cards | **Sonnet** | high-volume; the templates + rules do the thinking |
| 3b.N flows | **Opus** | state machines and concurrency semantics |
| 4.1.N edge extraction per module | **Sonnet** | mechanical extraction from page cards |
| 4.2 graph merge + gates | **Opus** | global consistency, orphan/asymmetry reasoning |
| 4.3 asymmetry reconcile | **Opus** | adjudicating contradictions against source |
| 5.N field traces | **Sonnet** | but escalate a page to **Opus** if it has dynamic SQL, stored procs, or Spring AOP proxies in the chain |
| 5.Z.N per-module data consolidation | **Sonnet** | sort/merge |
| 5.ZZ global reverse-index merge | **Opus** | cross-module conflict resolution, hot-table analysis |
| 6.1 security, 6.2 session | **Opus** | subtle, high blast-radius if wrong |
| 6.3–6.6 validation/layout/errors/i18n | **Sonnet** | catalogue building |
| 7.1 audit reasoning | **Opus** | reads the script's report, judges, samples citations |
| 7.2 gap closure | same model as the phase being re-run | |
| 7.3 glossary | **Sonnet** | |
| 7.4 review & promotion | **Opus** + human | grants `status: reviewed`; Gate 5 depends on it |
| 8.1 slice plan | **Opus** | sequencing/risk trade-offs |
| 8.2.N packets | **Opus** | the deliverable the rewrite is built from — do not economise here |

Rule of thumb: Sonnet executes procedures; Opus makes judgement calls. If a
Sonnet run produces hedged or citation-thin output, re-run that unit on Opus.

## Context rules (apply to every prompt)

- **File cap is per prompt**, stated in each prompt header. Default 12. If
  exceeded: write partial output, mark `partial` in the ledger, report
  `BUDGET_EXCEEDED`, and split the unit next run.
- **Attach explicitly** (`#file:`). `@workspace` is banned in all phases —
  Phase 0 CSVs replace workspace search.
- **Output goes to disk.** Chat reply = short completion report only.
- **The ledger is the memory** (`_meta/ledger.md`): read first, append last.
- **IDs come from `_meta/id-counters.md`**, never from scanning output files.
  Read the counter table, take what you need, rewrite the consumed rows.
- **Shared files are append-only in loop prompts.** Reverse index and domain
  objects are per-module shards appended blindly; dedup happens only in the
  consolidation prompts.
- If Copilot starts summarising earlier turns or "remembering" prior pages,
  the context is polluted — discard the chat and restart from the ledger.

## Run a pilot before mass execution

After Phase 1, run Phases 2 → 3 → 3b → 4.1 → 5 → 5.Z **end-to-end on the
smallest module only** (~10–15 prompts). Then review the outputs yourself:
are the page cards useful? Are §13 behaviours real findings or filler? Did the
budgets hold? Adjust the templates and batch sizes based on what you see, log
the changes in the ledger, and only then start the remaining modules. A template
flaw found after the pilot costs one module; found after Phase 3 it costs ~115
re-runs.

---

## Prompt R — Reconnaissance (run FIRST, before any setup) *(Sonnet, agent mode)*

Self-contained: needs no scanner, no skill folder, no conventions file. Run it
on the raw repo to confirm what you are dealing with before investing in the
pipeline. Sonnet is the right model — this is checklist-driven marker-file
detection, not judgement. Escalate to Opus ONLY if the verdict comes back
hybrid/ambiguous, and re-run just the ambiguous sections.

> You are doing read-only reconnaissance on an unfamiliar legacy Java web
> application repository. Goal: identify what kind of application this is, how
> it is structured, and every framework/technology in use — so a documentation
> pipeline can be configured correctly. You must NOT modify any file.
>
> Budget: open at most 25 files. Prefer small marker/config files. Do not read
> JSP or Java file bodies except where explicitly instructed below (max 5
> samples). Use directory listings and filename searches for everything else.
>
> Work through these steps in order:
>
> 1. **Repo shape.** List the top 2 levels of directories. Identify: source
>    roots, web content root(s), config dirs, test dirs, and anything unexpected
>    (multiple WARs? an EAR? embedded second project? generated code dirs?).
> 2. **Build system.** Find and open `pom.xml` / `build.xml` /
>    `build.gradle` / `ivy.xml` (and parents). Record: build tool + version,
>    Java source/target version, packaging (war/ear/jar), modules if
>    multi-module, and the declared dependency list with versions.
> 3. **Web descriptor.** Open every `web.xml`. Record servlets, filters (in
>    order), listeners, welcome files, error pages, security constraints,
>    session timeout.
> 4. **Framework detection.** Check for each marker below by filename search
>    first, opening the file only to confirm version/usage. For every HIT,
>    record the evidence path.
>    - Struts 1.x: `ActionServlet` in web.xml; `struts-config*.xml`;
>      `struts-*.jar` names; `tags-html` taglib in JSPs (search, don't read).
>    - Struts 2.x: `StrutsPrepareAndExecuteFilter`/`FilterDispatcher`;
>      `struts.xml`/`struts.properties`; `/struts-tags` taglib.
>    - Spring: `applicationContext*.xml`, `*-servlet.xml`,
>      `ContextLoaderListener`/`ContextLoaderPlugIn`; note Spring version from
>      jars/pom, and whether config is XML-only or mixed with annotations.
>    - View composition: `tiles*.xml`; SiteMesh `decorators.xml`; framesets
>      (search JSPs for `<frameset`).
>    - Validation: `validation.xml` + `validator-rules.xml`; commons-validator.
>    - Persistence: `sqlmap*.xml`/`*Mapper.xml` (iBATIS/MyBatis), `*.hbm.xml`
>      or `@Entity` (Hibernate/JPA), `JdbcTemplate`, raw `DriverManager`,
>      stored-proc calls (`{call`), `ejb-jar.xml` (EJB/CMP).
>    - Other: Quartz (`quartz.properties`, `*Job.java`), JMS listeners, web
>      services (`*.wsdl`, JAX-WS/Axis), reporting (Jasper `*.jrxml`, POI),
>      security frameworks (Spring Security/Acegi, custom filters), JS
>      libraries in the web root (jQuery? Dojo? YUI? version?).
> 5. **Application type.** Answer explicitly: single WAR or EAR with modules?
>    Server-rendered page-per-request, frameset-based, or partial-AJAX? Any
>    evidence of a second UI generation (e.g. some newer module using a
>    different stack)? Any REST/JSON endpoints already present?
> 6. **Scale estimate.** WITHOUT reading them, count via filename search: JSPs,
>    Java files, Struts config files, SQL map files, properties files. Give
>    counts per top-level directory.
> 7. **Sample check.** Open exactly 3 JSPs (pick one large, one mid, one small)
>    and 2 Action classes. Note: taglib style, scriptlet density, inline SQL or
>    business logic in JSPs, and whether Actions delegate to services or do the
>    work inline. This calibrates how hard deeper analysis will be.
> 8. **Surprises and risks.** Anything that contradicts the assumption
>    "standard Struts web app": multiple frameworks side by side, code
>    generation, unusual class loading, JNI, applets, portlets, vendor
>    frameworks, non-English identifiers/comments.
>
> Write the full findings to `docs/encyclopedia/_meta/recon.md` (create the
> directory) with sections: Verdict (framework + version + app type, one
> paragraph) · Repo structure map · Build & toolchain · Technology radar (table:
> tech | version | role | evidence path) · Scale estimates · Sample-check
> observations · Surprises & risks · Open questions.
>
> Every claim carries its evidence path. Write `UNKNOWN` where you could not
> confirm — do not guess versions. Do not paste file contents.
>
> Reply in chat with only: the one-paragraph verdict, the technology radar
> table, and the top 5 surprises/risks.

Use the recon verdict to configure the pipeline: it decides the Struts profile
(1.x/2.x/hybrid) for Phase 1.1, warns of extra stacks the scanner should cover,
and gives the counts that set batch sizes. Then proceed to Phase 0.

---

## Phase 0 — Mechanical scan (script, no model)

```bash
python3 scripts/scan_legacy_web.py --repo . --out docs/encyclopedia/_raw
```

Then sanity-check `docs/encyclopedia/_raw/summary.md`: framework verdict, JSP
count, action count. Fix scanner globs if counts look wrong. Also seed:

```bash
mkdir -p docs/encyclopedia/_meta
cp .copilot-skills/legacy-web-encyclopedia/references/00-conventions.md \
   docs/encyclopedia/_meta/conventions.md
```

---

## Phase 1 — Orientation (four prompts, run once each)

### Prompt 1.1 — Architecture & request lifecycle *(Sonnet, cap 12 files)*

> You are documenting a legacy Java web application (migrated from Struts 1.x
> to Spring Boot, retaining Struts idioms) so it can be rebuilt in Angular,
> feature by feature. This is Phase 1.1.
>
> Read first: `docs/encyclopedia/_meta/conventions.md` (including §8
> sanitization — never put the organisation name or application ids in prose
> or titles), `.copilot-skills/legacy-web-encyclopedia/references/06-spring-mvc-profile.md`,
> `docs/encyclopedia/_meta/recon.md`, `docs/encyclopedia/_raw/summary.md`.
>
> Open only (≤12 files): the Spring Boot entry class, the active Spring MVC
> config XMLs (main + any sub-context servlets), the active Tiles file, the
> URL-rewrite config, `validation.xml`, the WAR module's build file, and the
> container/Docker entry file. You MAY open the legacy backup web descriptor
> once — label everything from it `LEGACY REFERENCE — not deployed`. Do NOT
> open JSPs or controller classes in this prompt.
>
> Write `docs/encyclopedia/00-architecture.md`:
> 1. **Framework** — the migrated stack precisely (boot parent/BOM, servlet
>    container, view stack, Jakarta namespace), plus a "Struts residue" list:
>    each retained idiom (action-pair controllers, forward map, token guard,
>    message classes, `.do` URLs) with one evidence citation each.
> 2. **Request lifecycle** — numbered walkthrough of one `.do` request: URL →
>    rewrite rule → dispatcher → controller pair → forward map → Tiles
>    definition → JSP, naming THIS app's actual classes, filters in order.
> 3. **Configuration inventory** — every ACTIVE config file, purpose, counts
>    (from `_raw`); a separate short table of legacy/backup/test-fixture files
>    marked inert, so nobody documents from them later.
> 4. **Dual-UI check** — find the feature-flag utility from the recon (the
>    "opted-in" fork); state what it switches, and raise the parity-target
>    decision as an OQ.
> 5. **Unused-framework check** — for each dependency declared but with no
>    found usage (per recon), do ONE targeted verification (search imports/
>    subclasses; this does not count against the file cap) and record the
>    verdict or an OQ.
> 6. **Plain-language explainer** (~30 lines) for a developer who knows modern
>    Spring but not Struts idioms: what the prepare/process pair, form bean,
>    forward map, and token guard each do, using one concrete example from
>    THIS codebase per concept.
>
> Also create `_meta/sanitization.md`: seed the banned-token list per
> conventions §8 from the recon report (organisation tokens, registry-id
> patterns, context path, codenames, corporate package root).
>
> Cite `path:line` everywhere; `UNKNOWN — … — OQ-###` where evidence is missing
> (create `_meta/open-questions.md`). No pasted source. ≤350 lines.
> Append to `_meta/ledger.md`. Reply only: files written, UNKNOWN count,
> residue list.

### Prompt 1.2 — Dependency wiring map *(Opus, cap 12 files, fresh chat)*

> This is Phase 1.2. The team is not familiar with XML-based Spring DI, so this
> document is both a wiring map and a teaching document.
>
> Read first: `_meta/conventions.md`,
> `.copilot-skills/legacy-web-encyclopedia/references/05-spring-di-primer.md`
> (follow its Part 2 output spec exactly), and `00-architecture.md`.
>
> Open only (≤12 files): the Spring Boot entry class (its `@Enable*` and scan
> annotations ARE wiring config), every active Spring XML context and its
> `<import>` chain, and the properties files referenced by placeholder
> configurers. This app mixes XML beans with annotation config — document
> both and state which layer uses which. If more than 12 files, cover the
> root context fully, list the rest, and mark `partial`.
>
> Write `docs/encyclopedia/02-spring-wiring.md` with the seven sections from the
> primer's Part 2: context inventory, bean catalogue, controller-registration model
> (under the post-migration profile there is no Struts bridge — instead
> document how controllers are registered: component scan vs XML beans, and
> how the legacy action-pair base-class hierarchy is wired and injected), transaction
> map, AOP/interceptor map, externalised config, dependency diagram (mermaid,
> per layer).
>
> Additionally:
> - **Explainer**: for each mechanism found (e.g. `TransactionProxyFactoryBean`,
>   parent beans, JNDI datasource), add 2–3 plain-language sentences on what it
>   does, using the app's own beans as the example.
> - **Singleton-state audit**: list every singleton bean with mutable non-dependency
>   instance fields — flag as shared-state risk.
> - **`getBean(` call sites**: grep count from `_raw/java_classes.csv` context;
>   list the classes doing manual lookups (edges the XML doesn't show).
>
> Same citation/UNKNOWN/ledger rules. Reply only: bridge pattern found,
> transaction mechanism found, count of beans catalogued, UNKNOWNs.

### Prompt 1.3 — Technical setup *(Sonnet, cap 12 files, fresh chat)*

> This is Phase 1.3: document how this application is built, configured, and run.
>
> Read `_meta/conventions.md`, `00-architecture.md`, `02-spring-wiring.md`
> (externalised-config section).
>
> Open only (≤12): `pom.xml`/`build.xml`/`build.properties` and parents,
> `MANIFEST.MF`, app-server descriptors present in the repo (`context.xml`,
> `jboss-web.xml`, `weblogic.xml`, `ibm-web-bnd.xml`…), log config
> (`log4j*.xml|properties`), environment properties files, any
> `Dockerfile`/CI scripts if present.
>
> Write `docs/encyclopedia/03-tech-setup.md`:
> 1. **Toolchain** — JDK version (from build config, not guessed), build tool +
>    version, packaging (WAR/EAR), artifact layout.
> 2. **Dependencies** — direct libraries with versions, grouped by purpose
>    (framework/persistence/util), flagging any known-EOL components.
> 3. **App server** — which server(s) the descriptors target; JNDI resources
>    expected FROM the server (datasources, mail, JMS) vs configured in-app.
> 4. **Environments** — per-env property files, what differs, how the build
>    selects them (profiles, filtering, manual).
> 5. **How to run it locally** — best-effort reconstruction: prerequisites,
>    build command, deploy step, URL. Mark every assumption `UNKNOWN`/OQ.
> 6. **Logging & monitoring** — appenders, files, levels; anything that parses
>    logs downstream.
> 7. **Explainer** — plain-language notes for a developer who has not deployed
>    WAR/EAR apps to an app server before (~15 lines, using this app's names).
>
> Citations, UNKNOWNs, ledger, short reply — as always.

### Prompt 1.4 — Module partition & ID assignment *(Opus, cap 0 source files, fresh chat)*

> This is Phase 1.4. Read `_meta/conventions.md`, `00-architecture.md`,
> `02-spring-wiring.md`, `03-tech-setup.md`, and from `_raw/`: `jsp.csv`,
> `actions.csv`, `forms.csv`. Open no other source files. Also read the
> attached high-level architecture document: `#file:<ARCH_DOC>`.
>
> Partition the app into 6–15 modules by **business capability**, using action
> path prefixes, JSP dirs, form naming, Spring bean grouping, and the
> architecture document. Modules must be mutually exclusive and jointly
> exhaustive over the action mappings.
>
> Write `docs/encyclopedia/01-module-map.md`:
> - Table: `MOD-##` | name | business purpose | action path prefixes | JSP dirs |
>   ~pages | ~actions | depends-on modules.
> - Mermaid module-dependency diagram.
> - "Shared / cross-module" section for what resists assignment.
> - **Processing order** for Phases 2–5: fewest-dependency modules first;
>   among leaves, put the module we most want to modernize first.
> - **Discrepancies** between the architecture document and the code, citing both.
>
> Create the `docs/encyclopedia/modules/MOD-…/` skeleton, initialise the
> ledger with one `pending` row per module, and create `_meta/id-counters.md`
> (see conventions §6b) with all prefixes at their starting values.
> Reply only: module table + order.

---

## Phase 2 — Module inventory (loop per module, Sonnet, cap 12, fresh chat each)

### Prompt 2.N — Inventory MOD-##

> Read `_meta/conventions.md`, `_meta/ledger.md`, `_meta/id-counters.md`,
> `01-module-map.md`, `references/06-spring-mvc-profile.md` (artifact map),
> and the rows of `_raw/jsp.csv`, `spring_mvc.csv`, `forwards.csv` (including
> `code-forwardTo` rows), `tiles.csv` matching module **MOD-##**. Resolve
> Tiles from `_raw/tiles.csv` — do not open the tiles XML.
>
> The route inventory comes from THREE sources, all required: (a) this
> module's `@RequestMapping`-family annotations from `spring_mvc.csv`;
> (b) the URL-rewrite rules that map legacy `.do` URLs onto those handlers;
> (c) the forward-map names used by this module's `forwardTo` call sites.
> Pair Prepare/Process controllers explicitly: one page usually = one pair =
> two `ACT` rows cross-referenced to each other.
>
> Open only (≤12): the URL-rewrite config section for this module, the
> forward-map definition, and — only if a JSP's role is unclear — at most 8
> JSPs. No controller/service Java bodies.
>
> Write `docs/encyclopedia/modules/MOD-##-<name>/index.md`:
> 1. Module purpose (3–5 sentences, business language).
> 2. Page inventory: `PG-###` | business title | JSP(s) | Tiles def | primary
>    action | one-line purpose | entry point? | complexity S/M/L | suspected dead?
> 3. Action inventory: `ACT-###` | public URL(s) incl. `.do` aliases | real
>    class#method | HTTP | pair (prepare/process + partner ACT) | form bean |
>    forward names used | validate? | notes.
> 4. Form beans: `FRM-###` | class | how scoped (Spring bean / session attr) |
>    pages | notes. **Flag every session-persisted form.**
> 5. Fragments (includes/tiles pieces — no PG id; feed to layout-tiles.md later).
> 6. Candidate flows: `FL-##` + page sequence, no detail yet.
> 7. Unclassified leftovers.
>
> IDs come from `_meta/id-counters.md` (read, assign, update — conventions §6b);
> never reuse. Cite config for every row.
> Ledger: one row for the module + one `pending` row per PG. Reply: counts +
> unclassified list only.

### Prompt 2.Z — Reconcile inventory *(Opus, cap 0, after all modules)*

> Read all `modules/*/index.md` and `_raw/jsp.csv` + `actions.csv`. Verify:
> every JSP is a page, fragment, or explicitly excluded; every mapping has an
> ACT id; no duplicate ids; no overlapping module claims. Write findings to
> `_meta/coverage.md`. Fix collisions by appending corrections — never renumber.
> Reply: discrepancy list only.

---

## Phase 3 — Page cards (loop, Sonnet, **cap 12 files/prompt**, fresh chat each)

**Batch size: 2 pages** (3 only when the pages share an Action class or form
bean — the overlap keeps the total under the cap). Never mix modules. For a
250-page app expect ~110–125 runs; this is the volume phase.

### Prompt 3.N — Page cards for PG-###, PG-###

> Read `_meta/conventions.md`, `references/02-templates.md` (Template A),
> `references/03-tracing-rules.md` Parts 1 and 3, and this module's `index.md`.
>
> Document: **PG-###, PG-###**.
>
> Open only (≤12 total for the whole prompt): each page's JSP + directly
> included fragments, its real Action class(es) (per the module index — already
> resolved through Spring), its form bean, its validation entries, its
> page-specific JS. Resolve Tiles from `_raw/tiles.csv`, not the XML. Do NOT
> open services or DAOs (Phase 5).
> Use `_raw/taglib_links.csv` and `_raw/js_nav.csv` for edges instead of grepping.
> If 12 files can't cover both pages, do one page, mark the other `pending`,
> report `BUDGET_EXCEEDED`. If a JSP exceeds ~1,500 lines, that page is a batch
> of one: read the JSP in targeted sections using the line numbers in the CSVs.
> NAV/FLD ids come from `_meta/id-counters.md` (read, assign, update).
>
> Write one file per page: `modules/MOD-##-<name>/pages/PG-###-<slug>.md`,
> Template A exactly — all 15 sections, in order.
>
> Emphases:
> - §5 States: every JSTL/scriptlet branch that changes what the user sees —
>   including scriptlet `if` blocks, not just tags. If the page participates in
>   the dual-UI feature-flag fork (see `00-architecture.md`), document both
>   generations' states or cite the sibling page, and record the flag as a
>   precondition on every affected edge.
> - Grids rendered by the shared table component: reference its entry in
>   `cross-cutting/layout-tiles.md` for mechanics; document only this page's
>   column set, filters, and export behaviour.
> - §8 Inbound: work all nine discovery sources; end §8 with
>   `Sources checked: …` listing any you could not check and why.
> - §13 Behaviours to preserve: sticky filters, default sort, implicit org/row
>   filtering, result caps, double-submit tokens, session-driven behaviour.
> - §6 Fields: assign FLD ids + summary columns only (trace is Phase 5).
>
> Verify Gate 1 (`references/04-quality-gates.md`). Ledger row per page.
> Reply per page: `PG-### done, N fields, M inbound, K UNKNOWNs`.

---

## Phase 3b — Flows (loop per flow, Opus, cap 5, fresh chat each)

### Prompt 3b.N — Flow FL-##

> Read Template B and attach the page cards of this flow's pages. Open source
> (≤5 files) only where a card says UNKNOWN on something the flow needs.
> Write `modules/MOD-##-<name>/flows/FL-##-<slug>.md`: entity state machine,
> where partial data lives between steps (session? staging table? hidden
> fields?), abandonment/timeout, concurrency, transaction boundaries (check
> `02-spring-wiring.md`'s transaction map — cite the matching method patterns).
> Ledger. Reply: mermaid diagram only.

---

## Phase 4 — Navigation graph (per-module extraction, then one merge)

### Prompt 4.1.N — Edge extraction for MOD-## *(Sonnet, cap 0 source, fresh chat each)*

> Attach the page cards of `modules/MOD-##-*/pages/` — **at most 20 cards per
> run**; for larger modules run this prompt in batches and append to the same
> output file. Open no source files.
> Extract §8 and §9 of each card into
> `docs/encyclopedia/navigation/edges-MOD-##.md`: one table, one row per NAV —
> `NAV` | from PG | to PG | trigger | mechanism | precondition | data carried |
> redirect/forward. Include cross-module edges (target outside this module) in a
> separate "outbound cross-module" table. Ledger. Reply: edge count only.

### Prompt 4.2 — Merge, entrypoints, gates *(Opus, cap 0 source, fresh chat)*

> Read every `navigation/edges-MOD-##.md` (small tables — all fit) plus
> `_raw/actions.csv` for the full action list. Open no source.
>
> Write:
> - `navigation/inbound-index.md` — for every PG-### (every one, from the
>   ledger's page list): all inbound edges; mark zero-inbound pages `ORPHAN`.
> - `navigation/entrypoints.md` — pages reachable cold (menus, welcome files,
>   deep links, external links, error pages); for each, whether it works when
>   entered directly or what session state it silently needs (cite the card).
> - `navigation/graph.md` — mermaid per module (≤60 nodes each) + one
>   module-level graph.
>
> Run Gate 2 and append findings to `graph.md`: orphans, unreachable ACTs,
> asymmetric edges, cycles. Reply: Gate 2 findings only.

### Prompt 4.3 — Reconcile asymmetries *(Opus, cap 4 per edge batch, fresh chat)*

> For each asymmetric edge from Gate 2: open the two page cards + minimum
> source (≤4 files) to decide which side is right. Append the correction to the
> wrong card's §8/§9 — touch nothing else. Ledger per correction.
> Reply: corrections table.

---

## Phase 5 — Field traces (loop, Sonnet, **cap 12/prompt**, fresh chat each)

**Batch: 2 pages** (1 if the page is L-complexity or its chain crosses an AOP
proxy). **Escalate to Opus** when the chain includes dynamic SQL, stored
procedures, or transaction/AOP proxies from `02-spring-wiring.md`.

### Prompt 5.N — Trace PG-###, PG-###

> Read `_meta/conventions.md`, Templates C+D, `references/03-tracing-rules.md`
> Part 2, the two page cards, and the relevant sections of
> `02-spring-wiring.md` (to resolve interface → bean → concrete class, and to
> know which calls pass through transaction/AOP proxies).
>
> Open only (≤12): the controller pair, the CONCRETE service class(es)
> (resolved via the wiring map — never stop at an interface), and the
> persistence classes per `06-spring-mvc-profile.md`'s three paths: JPA
> repository + its `@Entity` (column mapping), JdbcTemplate DAO (locate SQL
> via `_raw/sql.csv`), or Mongo repository + its `@Document`. Use
> `_raw/entities.csv` to find mappings before opening anything.
> Derived JPA method names ARE queries — parse `findBy…` names into
> predicates; `@Column`-less fields resolve via the naming strategy (mark
> `confidence: medium`). Tag every field-index and reverse-index row with
> `store: jpa | jdbc | mongo`.
>
> For every FLD on these pages, walk all eight hops (Part 2) and append a row
> to `data/field-index-MOD-##.md` (Template C — per-module file).
> Simultaneously append every touched column as a new row to
> `data/db-reverse-index-MOD-##.md` (Template D) — **append only; do not read
> or deduplicate the existing file**, that happens in 5.ZZ. Append new VOs/DTOs
> to `data/domain-objects-MOD-##.md` the same way.
> FLD ids come from `_meta/id-counters.md` (read, assign, update).
>
> Rules: dynamic SQL → enumerate every branch + condition, never guess columns.
> Procs/triggers → mark incomplete + OQ. Hidden fields and session-carried
> values are fields. Same field on another page → new row; note transformation
> differences between pages. Note which hops run inside a transaction (from the
> wiring map's method patterns).
> Update the page card §10 with the resolved chain (including proxy hops) and
> append 5 to `phase_completed`. Change nothing else.
>
> Gate 3 self-check. Ledger. Reply: `PG-###: N fields, M columns, K UNKNOWNs`.

### Prompt 5.Z.N — Consolidate module MOD-## *(Sonnet, cap 0, per module)*

> Read `data/field-index-MOD-##.md` only. Sort by PG then FLD; merge exact
> duplicates; verify FLD ids are unique and every row has Bind + Type/format
> filled (Gate 3 rows). Fix formatting only — never change traced facts.
> Reply: row count + Gate 3 violations.

### Prompt 5.ZZ — Global reverse index *(Opus, cap 0, fresh chat, once)*

> Attach every `data/db-reverse-index-MOD-##.md` shard (they are raw
> append-only tables). Merge them into a single `data/db-reverse-index.md`:
> sort by table/column; collapse duplicate rows, unioning the reader/writer
> page sets; per table add business meaning and flag no-screen-writer tables
> (batch/external). Do the same merge for `domain-objects-MOD-##.md` →
> `domain-objects.md`. Add a **hot tables** section (most-touched tables —
> these constrain the Angular API design most). Run Gate 3 cross-checks
> against the per-module field indexes' Table.Column values; report failures.
> If the shards together are too large for one run, merge module-by-module
> into the global file across several runs, then do a final dedup pass.

---

## Phase 6 — Cross-cutting (one prompt per topic, cap 20, fresh chat each)

Shared shape:

> Read `00-architecture.md`, `02-spring-wiring.md`, and relevant `_raw/*.csv`.
> Open ≤20 files — the IMPLEMENTATION of the concern, not its call sites (call
> sites come from the CSVs and page cards). Write
> `docs/encyclopedia/cross-cutting/<file>.md`. Cite everything. Ledger.
> Reply: 5-line summary.

| Prompt | Model | File | Must answer |
|---|---|---|---|
| 6.1 | **Opus** | `security.md` | Authentication mechanism; role model location; where authorisation is checked (filter/action/JSP/AOP — check the wiring map's proxies); role-gated pages/fields/buttons; unauthorised-access behaviour; silent row-level (org/tenant) filtering in SQL. |
| 6.2 | **Opus** | `session.md` | Every session attribute from `_raw/session_attrs.csv`: writer, readers, lifetime, clearing; every session-scoped form bean; what breaks on session loss; timeout; clustering assumptions. |
| 6.3 | Sonnet | `validation.md` | Full rule catalogue by form bean; client-side-only (bypassable) rules; message catalogue; error display mechanism. |
| 6.4 | Sonnet | `layout-tiles.md` | Definition hierarchy; every shared fragment + consumers; header/footer/menu components; stateful fragments. (= Angular shared-component inventory.) |
| 6.5 | Sonnet | `error-handling.md` | Exception mappings, error pages, user-visible vs logged vs swallowed. |
| 6.6 | Sonnet | `i18n.md`, `integrations.md` | Locales, bundles, date/number formats; every outbound system, protocol, payload, failure mode, retries. |

---

## Phase 7 — Verification

### Step 7.0 — Mechanical audit *(script, no model)*

```bash
python3 scripts/audit_coverage.py --enc docs/encyclopedia
```

Writes `_meta/audit-report.md`: unaccounted JSPs, missing/duplicate ids,
citation-thin cards, pages without Phase 5, pending/partial ledger units.

### Prompt 7.1 — Audit reasoning *(Opus, cap 10, fresh chat)*

> Read `_meta/audit-report.md` and `references/04-quality-gates.md` Gate 4.
> The mechanical checks are done — do the judgement checks:
> 1. Citation spot-check: pick 10 random citations across the corpus, open those
>    files (≤10, your whole budget), verify the cited lines support the claim.
>    Report the error rate; >10% ⇒ name the phase to re-run.
> 2. Contradiction scan across the summary docs (same field/table described
>    differently) — reconcile or raise OQs.
> 3. Group every open OQ by the modernization slice it will block.
> Write conclusions into `_meta/coverage.md` with overall PASS/FAIL.
> Reply: coverage verdict + gap list.

### Prompt 7.2 — Close gaps *(model per originating phase)*

> Re-run the matching Phase 2/3/5 prompt for each gap unit. Nothing new.

### Prompt 7.3 — Glossary *(Sonnet, cap 0)*

> Read page cards' §1 + field index labels. Write `_meta/glossary.md`: domain
> terms, meaning, UI locations, backing table/column; flag inconsistent usage.

### Prompt 7.4 — Review & promotion *(Opus, cap 6, per module, fresh chat each)*

Gate 5 requires `status: reviewed` on every page in a slice; this is the step
that grants it. It is deliberately a mix of model verification and human
sign-off — do not skip the human half.

> For each `status: draft` page card in MOD-## that has Phase 5 complete:
> 1. Re-check Gate 1 mechanically.
> 2. Verify 3 randomly chosen citations per card against source (total budget
>    6 files per run — batch cards accordingly).
> 3. Confirm zero blocking OQs for the card.
> If all pass, set `status: reviewed` and append `reviewed-by: model` to the
> front matter. If not, list what failed and leave it `draft`.
> Reply: promoted list + failed list.

Then the human step: the team lead (or the developer who knows that module)
skims each promoted card's **§13 behaviours** and **§7 rules** — the two
sections a rewrite lives or dies on — and adds `reviewed-by: <name>` on
sign-off. Cards a human has flagged go back to `draft` with a note. Only
human-signed cards should feed Phase 8 packets for high-risk slices.

---

## Phase 8 — Modernization packets

### Prompt 8.1 — Slice plan *(Opus, cap 0, fresh chat)*

> Read `01-module-map.md`, `navigation/graph.md`, `navigation/entrypoints.md`,
> `data/db-reverse-index.md` (hot tables), every `modules/*/index.md`, and
> `cross-cutting/security.md` + `session.md` summaries. No source files.
>
> Write `modernization/slices.md`: ordered `MS-##` slices — pages, flows,
> tables, dependencies, shared components needed, size, risk. Sequencing rules:
> independently shippable behind a route; minimise dual-write tables with
> un-migrated slices (call each out); first slice = low-risk read-only page that
> exercises the shell (auth/layout/nav); high-value screens early; dead pages
> in a "do not migrate" list with justification.
> Plus a **coexistence note**: how users cross between legacy and Angular while
> both run, and how session/auth is shared — grounded in the legacy auth
> mechanism (cite `security.md`) and the session inventory (`session.md`).
> Reply: ordered slice table.

### Prompt 8.2.N — Packet MS-## *(Opus, cap 0 legacy source, fresh chat each)*

> Read Template E. Attach: the slice's page cards, flow docs, its rows from the
> per-module field index, its tables' rows from the reverse index, and the
> relevant parts of `security.md`, `session.md`, `02-spring-wiring.md`
> (transaction boundaries for in-scope actions). Open NO legacy source — a doc
> gap here is a finding: raise an OQ and continue.
>
> Write `modernization/MS-##-<feature>.md` per Template E. Requirements:
> - API contract covers every in-scope ACT with concrete JSON request/response
>   shapes; field names by business meaning; mapping table back to FLD ids;
>   transaction boundaries stated per endpoint (from the wiring map).
> - Navigation contract lists every inbound path from `inbound-index.md` for
>   in-scope pages — including deep links/bookmarks — each mapped to an Angular
>   route + params.
> - Acceptance tests: Given/When/Then for every state (§5), rule (§7), and
>   preserved behaviour (§13).
> - Parity risks with recommendations, marked "decision needed".
> - **Sanitization (conventions §8 Tier 2):** the packet is identity-free.
>   No organisation/application tokens (check `_meta/sanitization.md`), no
>   repo paths, no package or class names. Legacy artifacts appear as
>   `PG-###`/`ACT-###`/`FLD-#####` ids only; name endpoints and fields by
>   business meaning. State which backend store each endpoint fronts
>   (`jpa | jdbc | mongo` from the reverse index) — without naming legacy
>   classes.
> Run Gate 5 (including the sanitization check); put `READY` or
> `BLOCKED BY: OQ-…` at the top.
> Reply: Gate 5 result + endpoint table.

---

## Run-count estimate (250-page app)

| Phase | Runs | Model |
|---|---|---|
| 0, 7.0 | 2 scripts | — |
| 1 | 4 | 2 Sonnet, 2 Opus |
| 2 | ~12 + 1 | Sonnet + 1 Opus |
| 3 | ~115 | Sonnet |
| 3b | ~15 | Opus |
| 4 | ~12 + 2 | Sonnet + 2 Opus |
| 5 | ~125 + ~13 | Sonnet (escalations Opus) |
| 6 | 6 | 2 Opus, 4 Sonnet |
| 7 | 2 + ~12 review + gaps | Opus (+ human sign-off) |
| 8 | ~13 | Opus |
| | **~320 prompts** | ~85% Sonnet by volume |

Phases 3, 4.1, and 5 are mechanical enough to drive from a script that reads
pending units off the ledger and emits the prompt text per unit.

## Resuming after a break

New chat, any model:

> Read `docs/encyclopedia/_meta/ledger.md`. List the next 5 pending units in
> order, each with its phase and prompt number. Do nothing else.
