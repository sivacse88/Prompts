# Wiring into GitHub Copilot (VS Code)

Copilot does not read `SKILL.md`. Copy this skill folder into the legacy repo at
`.copilot-skills/legacy-web-encyclopedia/`, then add the three adapters below.

Repository-wide instructions live in `.github/copilot-instructions.md`;
path-scoped instructions live in `.github/instructions/*.instructions.md` with an
`applyTo` glob; reusable prompts live in `.github/prompts/*.prompt.md` and are
invoked in chat as `/<filename>`.

---

## 1. `.github/copilot-instructions.md`

```markdown
# Repository instructions

This is a legacy Java web application being documented for a feature-by-feature
Angular rewrite. Documentation work follows the process in
`.copilot-skills/legacy-web-encyclopedia/`.

When asked to analyze, document, map, or inventory any part of this application:

1. Read `docs/encyclopedia/_meta/ledger.md` first. It is the source of truth for
   what has already been done. Never redo completed work.
2. Read `docs/encyclopedia/_meta/conventions.md` before writing any encyclopedia
   file. IDs, front matter, and citation format are fixed by it.
3. Every factual claim needs a `path/to/File.java:123` citation. If evidence is
   missing, write `UNKNOWN — <what> — OQ-###` and add a row to
   `docs/encyclopedia/_meta/open-questions.md`. Never infer from naming and
   present it as fact.
4. Write findings to files. Chat replies are limited to a short completion report.
5. Never open more than 12 source files in one turn. If the task needs more,
   write a partial result, mark it `partial`, and report `BUDGET_EXCEEDED`.
6. Never renumber or reuse an ID. Never rewrite a completed section — append.
7. Do not paste source code into documentation. Cite it.
8. Append a row to `docs/encyclopedia/_meta/ledger.md` when finished.

Do not use `@workspace` for documentation tasks; attach specific files.
```

---

## 2. `.github/instructions/encyclopedia.instructions.md`

```markdown
---
applyTo: "docs/encyclopedia/**"
---

When creating or editing files under `docs/encyclopedia/`:

- Use the templates in `.copilot-skills/legacy-web-encyclopedia/references/02-templates.md`
  exactly. All sections must be present; use `n/a` with a reason rather than
  deleting a section.
- YAML front matter is mandatory: id, type, title, module, status,
  phase_completed, sources, confidence, last_updated.
- `sources` must list every file actually read for that document.
- Append to `phase_completed`; never overwrite it.
- Before finishing, check the artifact against Gate 1 in
  `.copilot-skills/legacy-web-encyclopedia/references/04-quality-gates.md`.
```

Optional second scoped file for source analysis:

```markdown
---
applyTo: "**/*.java,**/*.jsp,**/*.xml"
---

When reading legacy source for documentation purposes, apply the tracing rules in
`.copilot-skills/legacy-web-encyclopedia/references/03-tracing-rules.md`:
navigation edges must be checked against all nine discovery sources, and field
traces must walk all eight hops to a table column or a stated dead end.
```

---

## 3. `.github/prompts/*.prompt.md`

One file per phase. Body = the corresponding prompt from `PROMPT-SERIES.md`.

```
.github/prompts/
  phase1-1-framework.prompt.md        (Sonnet)
  phase1-2-spring-wiring.prompt.md    (Opus)
  phase1-3-tech-setup.prompt.md       (Sonnet)
  phase1-4-modules.prompt.md          (Opus)
  phase2-module-inventory.prompt.md   (Sonnet)  phase2-reconcile (Opus)
  phase3-page-card.prompt.md          (Sonnet)
  phase3b-flow.prompt.md              (Opus)
  phase4-1-edges.prompt.md            (Sonnet)
  phase4-2-graph-merge.prompt.md      (Opus)
  phase4-3-reconcile.prompt.md        (Opus)
  phase5-field-trace.prompt.md        (Sonnet; Opus for dynamic-SQL/proxy pages)
  phase5-consolidate.prompt.md        (Sonnet per module; Opus for global merge)
  phase6-crosscutting.prompt.md       (Opus for security+session, else Sonnet)
  phase7-audit.prompt.md              (Opus — run scripts/audit_coverage.py first)
  phase8-slice-plan.prompt.md         (Opus)
  phase8-packet.prompt.md             (Opus)
```

Select the model in the Copilot Chat model picker before invoking the prompt —
the per-prompt assignment table is at the top of `PROMPT-SERIES.md`.

Example — `phase3-page-card.prompt.md`:

```markdown
---
mode: agent
description: Produce encyclopedia page cards for the given PG ids
---

Pages to document: ${input:pages:e.g. PG-047, PG-048}

<paste Prompt 3.N body from PROMPT-SERIES.md here>
```

Invoke with `/phase3-page-card` and supply the page ids.

---

## 4. Daily loop

```
new chat
  → /phase3-page-card  PG-047, PG-048, PG-049
  → verify the ledger row appeared
  → new chat
  → /phase3-page-card  PG-050, PG-051
  → ...
```

When Copilot starts referring to things it "documented earlier" without opening
the file, the context is polluted — discard the chat and restart from the ledger.

---

## 5. Also usable from Claude Code / Cowork

The folder is already a valid Agent Skill. Drop it in `.claude/skills/` and the
`SKILL.md` front matter makes it discoverable; the phase prompts work unchanged.
Phases 3 and 5 are the ones worth scripting into an agent loop that reads pending
units from the ledger and issues one prompt per unit.
