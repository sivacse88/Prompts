# page-deep-dive

Deep-research analysis of ONE JSP page in a legacy Java web app (Spring Boot +
JSP/Tiles with Struts-era idioms). Input: a JSP path. Output, per page, in
`docs/page-specs/<slug>/`:

- `workbook.md` — raw evidence, built incrementally by prompts P1–P5
- `spec.md` — the structured specification (from `templates/spec-template.md`)
- `page.html` — self-contained, searchable reference page for distributed
  developers (from `templates/page-spec-template.html`; no external resources,
  works from a file share or repo browser)

## Why 6 prompts instead of 1

A large JSP (some exceed 200KB) plus a repo-wide inbound search plus per-field
lineage tracing cannot fit one context window. Each prompt does one concern
with a hard file budget and appends findings to the workbook; P6 compiles the
deliverables from the workbook alone. State lives on disk, so runs are
resumable and parallel pages never conflict.

| Prompt | Concern | Model |
|---|---|---|
| P1 | How the page is called (render chain + every inbound path) | Sonnet |
| P2 | States, fields, display conditions, static content | Sonnet / Opus if >1,500 lines |
| P3 | True origin of every field (table.column / collection.field / API / session / computed) | Opus |
| P4 | Client-side rules and their exact triggers | Sonnet |
| P5 | Every action and its end-to-end outcomes incl. writes | Opus |
| P6 | Compile spec.md + page.html; verify | Sonnet |

## Quick start

1. Copy this folder into the repo: `.copilot-skills/page-deep-dive/`
2. VS Code → Copilot Chat → Agent mode → model per the table
3. Open `PROMPT-SERIES.md`, paste P1 with your JSP path and a chosen slug
4. Fresh chat per prompt, P1→P6; P3 may need 2–3 runs on big pages
5. Spot-check 5 citations in `spec.md`, then share `page.html`

Works standalone. If `docs/encyclopedia/_raw/*.csv` exists (from the
legacy-web-encyclopedia skill), P1/P4/P5 run faster using those CSVs.
Identity tokens never appear in prose; set `sanitize: true` in the workbook
header for fully identity-free spec/HTML exports.
