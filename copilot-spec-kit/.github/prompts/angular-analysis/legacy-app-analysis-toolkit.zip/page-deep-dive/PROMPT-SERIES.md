# Page Deep-Dive — prompt series

Run in Copilot Chat, **agent mode**, one prompt per **fresh chat**, in order.
Replace `<JSP>` with the JSP path (e.g. `src/main/webapp/contrib/pgModify.jsp`)
and `<slug>` with a kebab-case business name you choose (e.g.
`modify-contribution`). All output goes to `docs/page-specs/<slug>/`.

If `docs/encyclopedia/_raw/*.csv` exists, prompts say how to use it; otherwise
follow the fallback searches. Never use `@workspace`; use targeted search and
explicit `#file:` attachments.

---

## P1 — Identity & entry map *(Sonnet, cap 12 files, fresh chat)*

> You are starting a deep-dive analysis of one page in a legacy Java web
> application (Spring Boot serving JSPs via Tiles, with Struts-era idioms:
> prepare/process controller pairs, forward maps, `.do` URLs, token guards).
> Target JSP: `<JSP>`. Working file: `docs/page-specs/<slug>/workbook.md` —
> create it with the header below, then append section 1 and 2.
>
> Header:
> ```
> # Workbook — <business page name>
> jsp: <JSP>
> slug: <slug>
> sanitize: false
> status: P1
> ```
>
> **Step 1 — Resolve the render chain.**
> Find how this JSP becomes a page: search the active Tiles XML for a
> definition whose template/attribute references `<JSP>` (or whether the JSP is
> itself a fragment used by definitions — if it is ONLY a fragment, say so and
> list consumer definitions instead). Then find every controller/forward-name
> that resolves to that definition: search Java for the definition name and for
> `forwardTo("...")` values that map to it (open the forward-map definition to
> resolve). Then find the public URL(s): the `@RequestMapping`-family
> annotations on those controllers AND any URL-rewrite rules mapping legacy
> `.do` paths to them. Record the full chain:
> `URL(s) → rewrite rule → controller#method (prepare) / (process) → forward
> name → Tiles definition → JSP + fragments`, each hop cited.
> With encyclopedia CSVs: `_raw/tiles.csv`, `_raw/spring_mvc.csv`,
> `_raw/forwards.csv` give you all of this without searching.
>
> **Step 2 — Every way the page is called.** Search the whole repo for each of:
> (1) links/redirects to any of its URLs or forward names (`href=`, `action=`,
> `sendRedirect`, `redirect:` view names); (2) JSP/taglib links to it;
> (3) JavaScript navigation (`location.href`, `window.open`,
> `form.action=`+`submit()`, AJAX that loads it); (4) menu/navigation config
> (XML, DB-driven menus, properties); (5) validation-failure and error routes
> that RETURN to it; (6) direct entry (is it bookmarkable? does it work
> without session state set by a predecessor — check what the prepare
> controller assumes exists in session); (7) other apps/emails (search
> properties/templates for its URL). With CSVs: `_raw/taglib_links.csv`,
> `_raw/js_nav.csv` filtered to its URLs.
> For every inbound path record: from-where | user trigger | mechanism (cite) |
> preconditions (role, session state, flags) | parameters/data carried in.
>
> Append to the workbook:
> `## 1. Identity & render chain` (the chain + fragments list + controller
> pair) and `## 2. Inbound paths` (one table row per path, plus a
> `Direct-entry verdict:` line). Cap: 12 file opens (searches are free; opens
> are not). If the budget runs out, write what you have and add
> `INCOMPLETE: <what remains>`. Reply in chat with only: the render chain,
> inbound path count, and any INCOMPLETE markers.

---

## P2 — Content inventory: states, fields, display conditions
*(Sonnet; **Opus if the JSP exceeds 1,500 lines**; cap 10, fresh chat)*

> Continue the deep-dive. Read `docs/page-specs/<slug>/workbook.md` (sections
> 1–2 tell you the JSP, fragments, and controller pair). Now analyze the page
> content. Open: the JSP and its included fragments/tag files, and the message
> bundle(s) its label keys come from. Nothing else. If the JSP is >1,500
> lines, read it in passes — (a) `<%@ include`/taglib header + top scriptlet
> block, (b) form and input markup, (c) conditional structure, (d) inline
> scripts — citing line ranges as you go.
>
> **A. Page states.** Enumerate every visually/functionally distinct rendering.
> A state = any conditional that changes what the user sees: JSTL
> (`<c:if>/<c:choose>`), scriptlet `if/else` around markup, feature-flag
> forks, mode attributes (create/edit/view), role checks, empty-vs-results,
> error rendering. For each state: name | the EXACT condition expression
> (verbatim, cited) | plain-language meaning | what appears/disappears.
> Also record the DEFAULT state on first entry.
>
> **B. Field inventory.** Walk the markup top-to-bottom and register EVERY
> content element, assigning sequential ids F01, F02…:
> - inputs (text/select/radio/checkbox/textarea/file/date), with control
>   attributes (maxlength, readonly, disabled) and the `name`/`path`/property
>   it binds to;
> - hidden fields (these carry keys/state — never skip);
> - display-only dynamic values (EL expressions, `<bean:write>`-alikes,
>   scriptlet `out.print`, formatted dates/amounts);
> - select/radio OPTION SOURCES (static list in JSP? model attribute? lookup?)
>   — the option list is itself a traceable data source;
> - grid/table components: the column set, what each column binds to, sorting/
>   paging/export config;
> - static content: headings, instructional text, labels — resolve every
>   message-bundle key to its actual text; note hardcoded vs bundled;
> - images/links whose target or visibility is dynamic.
> For each: id | label (resolved) | kind | control | binds-to | shown-in-which
> states (reference section A) | display condition if field-level (verbatim +
> plain language) | citation. Do NOT trace origins yet — leave an empty
> `origin:` slot per field for P3.
>
> **C. Static structure.** One short subsection: layout skeleton (which Tiles
> slots/fragments render header/menu/body), plus anything in HTML comments
> that reveals intent or dead markup.
>
> Append `## 3. States`, `## 4. Fields`, `## 5. Static structure` to the
> workbook, update `status: P2`. Reply only: state count, field count, and the
> 3 most complex display conditions.

---

## P3 — Field lineage: the true origin of every field
*(**Opus**, cap 12 per run, may need 2–3 runs for big pages, fresh chat each)*

> Continue the deep-dive. Read the workbook; section 4 lists fields with empty
> `origin:` slots; section 1 gives the controller pair. Your job: fill
> `origin:` for every field, walking to the TERMINAL source. A service method
> is not an origin. Acceptable terminals: `table.column` (JDBC/JPA — resolve
> JPA via the `@Entity`'s `@Table`/`@Column`, or the naming strategy, marked
> medium-confidence), `collection.field` (Mongo `@Document`), an external
> API/WS response field (name the integration point), a session attribute
> (AND find who writes it — search the setter), a request parameter carried in
> from a referring page (say which, using section 2), a constant/config value
> (cite the properties file), or `computed:` with the formula and its input
> fields.
>
> Method: group fields by their backing model attribute (the prepare
> controller's `model.addAttribute`/form-bean population tells you the
> grouping — one read serves many fields). For each group open, in order: the
> prepare controller method → the concrete service class (resolve interfaces
> through Spring wiring — never stop at an interface) → the repository/DAO →
> the entity/SQL. Record the chain compactly per field:
> `origin: TABLE.COL ← Dao.findX `path:line` ← Service.loadY `path:line` ←
> prepare() `path:line`` — plus transformations applied on the way to the
> screen (formatting, masking, defaulting, concatenation), each cited.
> For derived JPA query methods, parse the `findBy…` name into its predicate.
> For select/radio fields, trace the OPTION LIST origin too (`options-origin:`).
> Also fill, for each INPUT field, `submit-target:` — where the value goes on
> POST (form property → which handler consumes it; full persistence tracing of
> writes happens in P5).
>
> Budget 12 opens per run. When the budget is spent, mark remaining fields
> `origin: PENDING`, update `status: P3-partial`, and reply with the count
> remaining — the next P3 run continues from the PENDING list. When all fields
> are done set `status: P3`. Never guess: unresolvable = `UNKNOWN — <why>`.
> Reply only: fields resolved / pending / UNKNOWN counts, plus the list of
> distinct tables/collections touched.

---

## P4 — Client-side rules *(Sonnet, cap 10, fresh chat)*

> Continue the deep-dive. Read the workbook (sections 3–4). Open: the JSP's
> inline `<script>` blocks (cite line ranges), every page-specific `.js` file
> it references, and the shared JS functions it calls (open the shared file
> ONLY for the called functions). With CSVs, `_raw/js_nav.csv` locates
> navigation calls.
>
> Catalogue, with an id per rule (R01, R02…):
> - **Validation rules**: what is checked (verbatim condition + plain
>   language), which fields (use F-ids), the EXACT trigger (form onsubmit /
>   field onchange / onblur / keyup / page load / timer), the user-visible
>   message, and whether the same rule exists server-side (check the
>   validation config / controller — if client-only, flag `BYPASSABLE`).
> - **Behaviour rules**: show/hide/enable/disable/recalculate logic — which
>   fields drive which, on what event.
> - **Formatting/masks**: input restriction, auto-formatting, focus control.
> - **AJAX**: endpoint, trigger, request params, what part of the DOM it
>   updates, error behaviour.
> - **Navigation JS**: confirm dialogs, popups (`window.open` + what the
>   opener/child exchange), double-submit guards, back-button handling,
>   unload warnings.
> - **Framework-generated JS**: anything emitted by taglibs/validator plugins
>   rather than hand-written — say which config generates it.
>
> Order rules by trigger so a developer can answer "what runs when I leave
> this field / press submit?" Append `## 6. Client-side rules` (+ a
> trigger-order summary table), update `status: P4`. Reply only: rule count by
> category and the BYPASSABLE list.

---

## P5 — Actions and end-to-end outcomes *(**Opus**, cap 12, fresh chat)*

> Continue the deep-dive. Read the workbook (all sections). Enumerate every
> ACTION a user can take on this page: every submit button, action link, grid
> row click/sort/export, AJAX trigger, and popup launcher (sections 4 and 6
> already list the triggers — consolidate, assign A01, A02…).
>
> For EACH action document the full chain, citing every hop:
> 1. **Trigger** — element (F-id), label, state(s) where available.
> 2. **Client gate** — which R-rules run first and what blocks submission.
> 3. **Request** — URL, method, parameters actually sent (including hidden
>    fields and tokens).
> 4. **Server handling** — handler method; token/double-submit check;
>    server-side validation (which rules, failure destination); the service
>    call sequence; **persistence effects**: every table/collection written,
>    insert/update/delete, key fields — this completes the write-side of P3's
>    `submit-target` slots.
> 5. **Outcomes** — EVERY exit: success (forward name → next page/state,
>    what flash/session data carries over), each validation failure (what the
>    user sees, what is preserved), business-rule rejections (messages),
>    exceptions (error page/mapping), concurrent-edit behaviour if any.
>    Present as an outcome table: condition → destination → user sees.
> 6. **Side effects** — session attributes written/cleared, audit records,
>    emails/downstream calls, cache effects.
>
> Open only: the process controller(s), the concrete services, and the
> DAOs/repositories for the write paths (≤12; prefer files already cited in
> the workbook). Append `## 7. Actions`, update `status: P5`. Reply only: the
> action list with one-line outcomes and any UNKNOWNs.

---

## P6 — Compile spec.md and page.html *(Sonnet, cap 0 source files, fresh chat)*

> Finish the deep-dive. Read ONLY `docs/page-specs/<slug>/workbook.md`,
> `templates/spec-template.md`, and `templates/page-spec-template.html` from
> the skill folder. Do not open any source file — if the workbook lacks
> something, write `UNKNOWN (workbook gap)`; do not improvise.
>
> **1. Write `docs/page-specs/<slug>/spec.md`** following the spec template:
> every workbook fact organised into the template's sections, keeping F/R/A
> ids and citations. Add a 10-line executive summary in business language at
> the top (what the page is for, who uses it, what it can change in the
> system).
>
> **2. Write `docs/page-specs/<slug>/page.html`** by filling the HTML
> template: single self-contained file, no external resources, all CSS/JS
> inline as the template already provides. Populate: overview card, "how you
> get here" table, states, the fields table (with origin chain rendered as a
> breadcrumb: `screen ← service ← DAO ← TABLE.COL`), client-rules grouped by
> trigger, one collapsible panel per action with its outcome table, and the
> data-sources summary (distinct tables/collections/APIs with which fields
> use them). Preserve the template's search box and filter behaviour — wire
> the field table rows with `data-*` attributes as the template's script
> expects. Citations render as `<code>` (they are reference text, not links).
> If the workbook header says `sanitize: true`, strip all repo paths and
> class names from BOTH outputs, leaving F/R/A ids and workbook section
> references.
>
> **3. Verify before finishing**: every field has origin or UNKNOWN; every
> rule has a trigger; every action has ≥2 outcomes (success + at least one
> failure) or a note why not; every state referenced by a field exists in the
> states section. List verification failures at the top of spec.md under
> `## Gaps`. Update workbook `status: DONE`.
> Reply only: file paths written, field/rule/action counts, gap list.

---

## Running order & practical notes

- Total: 6 chats for a normal page; 7–8 for a monster JSP (extra P3 runs).
- P1 needs only the JSP path. Everything else reads the workbook first, so
  you can pause days between prompts.
- If two developers analyze different pages in parallel, they never conflict —
  each page has its own folder.
- After P6, spot-check 5 random citations in spec.md against the source
  before circulating page.html to the team. If more than one is wrong, re-run
  the producing prompt (the workbook shows which section it came from).
