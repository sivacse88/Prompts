---
name: page-deep-dive
description: Given one JSP page in a legacy Java web application (Spring Boot serving JSPs via Tiles, Struts-era idioms), produce a complete deep-research analysis — how the page is reached, every field with its display condition and true data origin, all client-side rules and when they fire, every user action and its end-to-end outcome — delivered as a spec document plus a self-contained HTML page for distributed developers. Use when asked to analyze, explain, document, or deep-dive a specific JSP/page/screen.
---

# Page Deep-Dive

## Purpose

Turn ONE legacy JSP into three artifacts a distributed developer can use
without opening the codebase:

1. `workbook.md` — the raw evidence file (intermediate, kept for audit)
2. `spec.md` — the structured specification
3. `page.html` — a self-contained, styled, collapsible reference page

## Operating rules

1. **The workbook is the memory.** Prompts P1–P5 each append one section to
   `docs/page-specs/<slug>/workbook.md`. P6 compiles the deliverables from the
   workbook ONLY — it never opens source. Every prompt starts by reading the
   workbook to see what is already done.
2. **Evidence or UNKNOWN.** Every claim cites `path:line`. A field whose origin
   cannot be traced gets `UNKNOWN — <why>` — never a guess. The spec's value is
   that a developer can trust it blindly.
3. **Budgets are hard.** Each prompt states its file cap (default 12). A JSP
   over ~1,500 lines is read in targeted sections (forms → conditionals →
   scriptlet blocks → JS), never top-to-bottom.
4. **Fresh chat per prompt.** State lives in the workbook, not the chat.
5. **Terminal origin required.** "Underlying source" means the end of the
   chain: a `table.column`, a Mongo `collection.field`, an external API field,
   a session attribute (plus who wrote it), a constant, or a computed
   expression (plus its inputs). A service method name is NOT an origin —
   keep walking.
6. **All content counts.** Static text, labels from message bundles (resolve
   the key to the bundle text), images/links, hidden fields, HTML comments
   that reveal intent, and dynamically generated markup (scriptlets, tag
   files, grid components) are all in scope.
7. **Sanitization** — prose and titles never contain organisation/application
   identity tokens. Citations keep real paths (these are internal docs). If an
   identity-free export is required, set `sanitize: true` in the workbook
   header and P6 will strip paths/class names from `spec.md` and `page.html`,
   keeping only workbook references.

## Pipeline (one page = 6 prompts, ~7 for monster JSPs)

| Prompt | Does | Model | Cap |
|---|---|---|---|
| P1 | Identity & entry map — every way the page is called | Sonnet | 12 |
| P2 | Content inventory — states, fields, display conditions | Sonnet (Opus if JSP >1,500 lines) | 10 |
| P3 | Field lineage — true origin of every field (may need 2 runs) | **Opus** | 12/run |
| P4 | Client-side rules — what fires, when, on what | Sonnet | 10 |
| P5 | Actions — end-to-end outcome of every user action | **Opus** | 12 |
| P6 | Compile spec.md + page.html from workbook | Sonnet | 0 source |

Full prompt text: `PROMPT-SERIES.md`. Templates: `templates/`.

## Accelerator

If the repo already has `docs/encyclopedia/_raw/*.csv` (from the
legacy-web-encyclopedia skill), P1/P4/P5 use those CSVs instead of searching.
If not, each prompt's fallback grep instructions apply. The two skills are
compatible: a deep-dive workbook can seed an encyclopedia page card later.
