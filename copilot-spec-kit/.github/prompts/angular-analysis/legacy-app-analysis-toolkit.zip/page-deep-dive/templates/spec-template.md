# Page Specification — {{PAGE_TITLE}}

> Generated from `workbook.md` — every claim cites `path:line` or is marked
> UNKNOWN. Do not edit by hand; re-run the pipeline instead.

## Gaps
(verification failures from P6, or "none")

## 1. Executive summary
~10 lines, business language: what the page is for, who uses it, what it can
read and change in the system, where it sits in the user journey.

## 2. Identity
| | |
|---|---|
| JSP | |
| Fragments included | |
| Tiles definition | |
| Prepare handler | |
| Process handler(s) | |
| Public URL(s) | |
| Legacy `.do` aliases | |

## 3. How this page is reached
One row per inbound path: # | from | user trigger | mechanism (cited) |
preconditions | data carried in. End with the **direct-entry verdict**: what
happens on a cold bookmark hit and which session state is silently required.

## 4. Page states
One row per state: name | condition (verbatim, cited) | plain-language meaning
| what changes visually. State the default state.

## 5. Fields
The full F-table: id | label | kind | control | binds-to | shown in states |
display condition | **origin chain** (terminal source ← hops, cited) |
options-origin (for selects) | transformations | submit-target.
Group by page section. Hidden fields get their own subsection — they carry
keys and state.

## 6. Client-side rules
Grouped by trigger (on load / on field events / on submit / timers).
Per rule: id | fields (F-ids) | check (verbatim + plain) | message |
server-side twin or **BYPASSABLE** flag. Then: behaviour rules
(show/hide/enable), formatting/masks, AJAX calls, navigation JS.

## 7. Actions
One subsection per action A##: trigger | client gate (R-ids) | request (URL,
method, params) | server flow (validation → services → persistence writes,
tables listed) | **outcome table** (condition → destination → what the user
sees) | side effects (session, audit, downstream).

## 8. Data sources summary
Distinct tables / collections / external APIs touched, each with: read or
written | by which fields/actions | store type (jdbc/jpa/mongo/api/session).

## 9. Notes for the rewrite
Non-obvious behaviours a reimplementation must preserve (sticky state,
implicit filters, token guards, ordering, browser-back tolerance), and
BYPASSABLE client-only rules that must become server-side.

## 10. Open questions
Everything marked UNKNOWN, with what would resolve it.
